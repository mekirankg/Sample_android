package com.example.quest.fragment_example.view;

import android.app.Fragment;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.example.quest.fragment_example.R;
import com.example.quest.fragment_example.contract.SecondFragmentContract;
import com.example.quest.fragment_example.presenter.SecondFragmentPresenter;


public class SecondFragment extends Fragment implements SecondFragmentContract.SecondView{
    View view;
    Button secondButton;
    SecondFragmentContract.SecondPresenter mPresenter;
    @Override
    public View onCreateView (LayoutInflater inflater, ViewGroup container,
                              Bundle savedInstanceState) {
// Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_second, container, false);

        mPresenter=new SecondFragmentPresenter(this);
        return view;
    }

    @Override
    public void initView () {
        // get the reference of Button
        secondButton = (Button) view.findViewById(R.id.secondButton);
        // perform setOnClickListener on first Button
        secondButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View v) {
                mPresenter.onClickFragmentBtn();
            }
        });
    }

    @Override
    public void showNotification (String message) {
        // display a message by using a Toast
        Toast.makeText(getActivity(), message, Toast.LENGTH_LONG).show();

    }
}
