package com.example.quest.fragment_example.contract;

public interface FirstFragmentContract {
    interface View {
        void initView ();
        void showNotification(String message);
    }

    interface Presenter{
        void onClickFragmentBtn();
    }

    interface Model{

    }
}
