package com.example.quest.fragment_example.presenter;

import android.view.View;
import android.widget.Toast;

import com.example.quest.fragment_example.contract.FirstFragmentContract;
import com.example.quest.fragment_example.model.FirstFragmentModel;

public class FirstFragmentPresenter implements FirstFragmentContract.Presenter {

    private FirstFragmentContract.View mView;
    private FirstFragmentContract.Model mModel;

    public FirstFragmentPresenter (FirstFragmentContract.View view) {
        mView = view;
        initPresenter();
    }

    private void initPresenter () {
        mModel=new FirstFragmentModel();
        mView.initView();
    }

    @Override
    public void onClickFragmentBtn () {
        mView.showNotification("First Fragment shown");
    }
}
