package com.example.quest.fragment_example.contract;

import android.app.Fragment;

public interface MainActivityContract {

    interface View {
        void initView ();

        void loadFragment (Fragment fragment);

    }

    interface Model {

    }

    interface Presenter {
        void onClickFragment1 ();

        void onClickFragment2 ();
    }
}
