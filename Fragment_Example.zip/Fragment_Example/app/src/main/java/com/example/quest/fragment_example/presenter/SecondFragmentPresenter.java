package com.example.quest.fragment_example.presenter;

import com.example.quest.fragment_example.contract.FirstFragmentContract;
import com.example.quest.fragment_example.contract.SecondFragmentContract;
import com.example.quest.fragment_example.model.FirstFragmentModel;
import com.example.quest.fragment_example.model.SecondFragmentModel;

public class SecondFragmentPresenter implements SecondFragmentContract.SecondPresenter {

    private SecondFragmentContract.SecondView mView;
    private SecondFragmentContract.SecondModel mModel;

    public SecondFragmentPresenter (SecondFragmentContract.SecondView view) {
        mView = view;
        initPresenter();
    }

    private void initPresenter () {
        mModel = new SecondFragmentModel();
        mView.initView();
    }

    @Override
    public void onClickFragmentBtn () {
        mView.showNotification("Second fragment");
    }
}
