package com.example.quest.fragment_example.model;

import com.example.quest.fragment_example.contract.FirstFragmentContract;

public class FirstFragmentModel implements FirstFragmentContract.Model {
}
