package com.example.quest.fragment_example.presenter;



import com.example.quest.fragment_example.view.FirstFragment;
import com.example.quest.fragment_example.view.SecondFragment;
import com.example.quest.fragment_example.contract.MainActivityContract;
import com.example.quest.fragment_example.model.MainActivityModel;

public class MainActivityPresenter implements MainActivityContract.Presenter {
    private MainActivityContract.View mView;
    private MainActivityContract.Model mModel;

    public MainActivityPresenter (MainActivityContract.View view) {
        mView = view;
        initPresenter();
    }

    private void initPresenter () {
        mModel = new MainActivityModel();
        mView.initView();
    }

    @Override
    public void onClickFragment1 () {
        mView.loadFragment(new FirstFragment());
    }

    @Override
    public void onClickFragment2 () {
        mView.loadFragment(new SecondFragment());
    }
}
