package com.example.quest.fragment_example.view;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.example.quest.fragment_example.R;
import com.example.quest.fragment_example.contract.FirstFragmentContract;
import com.example.quest.fragment_example.presenter.FirstFragmentPresenter;


public class FirstFragment extends Fragment implements FirstFragmentContract.View {
    View view;
    Button firstButton;
    FirstFragmentContract.Presenter mPresenter;

    @Override
    public View onCreateView (LayoutInflater inflater, ViewGroup container,
                              Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_first, container, false);

        mPresenter = new FirstFragmentPresenter(this);
        return view;
    }

    @Override
    public void initView () {

        // get the reference of Button
        firstButton = (Button) view.findViewById(R.id.firstButton);
        // perform setOnClickListener on first Button
        firstButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View v) {
                mPresenter.onClickFragmentBtn();
            }
        });
    }

    @Override
    public void showNotification (String message) {
        // display a message by using a Toast
        Toast.makeText(getActivity(), message, Toast.LENGTH_LONG).show();

    }

}
