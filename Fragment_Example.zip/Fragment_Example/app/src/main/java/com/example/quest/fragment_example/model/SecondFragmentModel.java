package com.example.quest.fragment_example.model;

import com.example.quest.fragment_example.contract.FirstFragmentContract;
import com.example.quest.fragment_example.contract.SecondFragmentContract;

public class SecondFragmentModel implements SecondFragmentContract.SecondModel {
}
