package com.example.quest.fragment_example.contract;

public interface SecondFragmentContract {

    interface SecondView {
        void initView ();
        void showNotification(String message);
    }

    interface SecondPresenter{
        void onClickFragmentBtn();
    }

    interface SecondModel{

    }

}
