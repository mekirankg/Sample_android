package com.example.quest.fragment_example.model;

import com.example.quest.fragment_example.contract.MainActivityContract;

public class MainActivityModel implements MainActivityContract.Model {
}
