properties {
    $componentName = "VxPlayer"
    $branch = "master"
    $majorVersion = "2" 
    $minorVersion = "2" 
    $patchVersion = "0"
    $CurrentPath = resolve-path .
    $baseDir = Split-Path -Path $CurrentPath -Parent
    $toolsDir = "$baseDir\tools"
    $nugetPackageDir = "$baseDir\packages"
    $nugetConfigPath = "$baseDir\.nuget\NuGet.config"
    $nugetPath = "$toolsDir\NuGet.exe"
    $GlobalAssembyInfo = "$baseDir\VxPlayerInstaller\ExportPlayerCustomInstaller\Properties\AssemblyInfo.cs"
    $config = "Debug"
    $platform = "Mixed Platforms"
    $msbuildVerbosity = "minimal" # quiet, minimal, normal, detailed, diagnostic
    $msbuildParallel = $true
    if ([System.Environment]::ProcessorCount -gt 1) {
        $msbuildCpuCount = [System.Environment]::ProcessorCount - 1
    } else {
        # needed for Windows 7 VM
        $msbuildCpuCount = 1
    }

    $env:OldProductVersion = $null
    $env:NewProductVersion = "2.2.0.0"
    if(!$env:BRANCH)
    {
        $env:BRANCH = "master"
    }    

    #.Net
    $dotNetUri = "http://nebulous.pelco.org/artifactory/simple/ext-releases-local/com/microsoft/dotnet/4.6.1/NDP461-KB3102436-x86-x64-AllOS-ENU.exe"
    $dotNetPath = "$baseDir\Resources\dotNET\redist\NDP461-KB3102436-x86-x64-AllOS-ENU.exe"

    #VxPlayer Assemblies
    $nugetVxPlayerFeedURL = "http://nebulous.pelco.org/artifactory/api/nuget/vms-exportplayer-nuget-release-local"
    $nugetVxPlayerPackageURL = "http://nebulous.pelco.org/artifactory/vms-exportplayer-nuget-release-local/VxPlayer.UI."
    $nugetVxPlayerPath = "$baseDir\VxPlayerInstaller\Resources\VxPlayerReleaseBuild.zip"
    #Version filter is used to filter the latest nuget package available with major version 2 and minor version 2 
    $nugetVxPlayerVersionFilter = "VxPlayer.UI.2.2"

    #Vxplayer.Installer nugetpkg properties
    $vxplayerInstallernugetSpec = "$baseDir\VxPlayerInstaller\VxPlayerInstaller.nuspec"
    $vxplayernugetuploadurl = "http://nebulous.pelco.org/artifactory/api/nuget/vms-vxplayer.installer-nuget-snapshot/"

    $nugetPelcoToolsFeedUser = "vxintbuild"
    $nugetPelcoToolsFeedPass = "Dyhoahypvoc7"
    $timeoutSeconds = 1200

    $CommonViewsProjFile = "$baseDir\CommonWrapper\CommonViews\Installer.Views.Common.csproj"
    $CustomWrapperProjFile = "$baseDir\CommonWrapper\CustomWrapper\Installer.Core.csproj"
    $ExportPlayerBootstrapperProjFile = "$baseDir\VxPlayerInstaller\ExportPlayerBootstrapper\ExportPlayerBootstrapper.wixproj"

    $AssemblyFileVersionPattern = '(AssemblyFileVersion\()"(\d{1,6}).(\d{1,6}).(\d{1,6}).(\d{1,6})'
    $AssemblyVersionPattern = '(AssemblyVersion\()"(\d{1,6}).(\d{1,6}).(\d{1,6}).(\d{1,6})'


}

# include utility functions
include ".\..\util.ps1"

task Default -depends DebugBuild

task InstallDependencies {
    $packageConfigFiles = @(get-childitem . -include packages.config -recurse)
    Write-Host loop through each package configuration file and install 
    foreach($packageConfig in $packageConfigFiles)
    {
        $nugetArgs = "install", "-output", "$nugetPackageDir", "-configfile", "$nugetConfigPath", "$packageConfig"
        exec-and-wait -target $nugetPath -arguments $nugetArgs 
    }
    #Download-File $dotNetUri $dotNetPath
    Write-Host $GlobalAssembyInfo
    $env:OldProductVersion = Get-ProductVersion $GlobalAssembyInfo
    Write-Host "Detected previous ProductVersion: " $env:OldProductVersion -foregroundcolor "Yellow"

    $baseVersion = "$majorVersion.$minorVersion.$patchVersion"
    $buildNumber = GetBuildNumber $componentName $baseVersion $env:BRANCH
    Write-Host "Build Number : "$buildNumber -foregroundcolor "Yellow"
    Update-GlobalAssemblyInfo $patchVersion $buildNumber $GlobalAssembyInfo

    #Update-GlobalAssemblyInfo $env:SVN_REVISION $env:BUILD_NUMBER $GlobalAssembyInfo
    $env:NewProductVersion = Get-ProductVersion $GlobalAssembyInfo
    Write-Host "Updating to ProductVersion to: " $env:NewProductVersion -foregroundcolor "Green"  

    $nugetPackage = exec-and-wait-and-getoutput -target $nugetPath -outputPath $baseDir -arguments "list", $nugetVxPlayerVersionFilter, "-Source", "$nugetVxPlayerFeedURL", "-NonInteractive"	
    Write-Host "Nuget package found - $nugetPackage"
    $version = Replace-Substring $nugetPackage "VxPlayer.UI " ""
    $env:nugetVxPlayerPackageURL = $nugetVxPlayerPackageURL + $version + ".nupkg"
    Write-Host "Nuget package URL - $env:nugetVxPlayerPackageURL"
}

#Task to download .Net package 
task InstallReleaseDependencies -depends InstallDependencies {
    # Get .Net
    Download-File $dotNetUri $dotNetPath
    Download-File "$env:nugetVxPlayerPackageURL" "$nugetVxPlayerPath"
    Extract-Files "$baseDir\VxPlayerInstaller\Resources\VxPlayerReleaseBuild.zip" "$baseDir\VxPlayerInstaller\Resources\VxPlayerReleaseBuild"
}

#Task build common views and wrapper components 
task ReleaseBuildCommonComponent -depends InstallReleaseDependencies {
    # Build configuration release
    $script:config = "Release"
    #run-msbuild -solution $solutionFile -target Build -configuration $script:config -platform $platform -productVersion $env:NewProductVersion -signOutput true
    run-msbuild -solution $CommonViewsProjFile -target Build -configuration $script:config -platform $platform -productVersion $env:NewProductVersion -signOutput true
    run-msbuild -solution $CustomWrapperProjFile -target Build -configuration $script:config -platform $platform -productVersion $env:NewProductVersion -signOutput true
}

task DebugBuildCommonComponent -depends InstallReleaseDependencies {
    # Build configuration debug
    $script:config = "Debug"
    #run-msbuild -solution $solutionFile -target Build -configuration $script:config -platform $platform -productVersion $env:NewProductVersion -signOutput true
    run-msbuild -solution $CommonViewsProjFile -target Build -configuration $script:config -platform $platform -productVersion $env:NewProductVersion -signOutput true
    run-msbuild -solution $CustomWrapperProjFile -target Build -configuration $script:config -platform $platform -productVersion $env:NewProductVersion -signOutput true
}

#Task build installer project which includes msi, customInstaller and bootstrapper 
task ReleaseBuild -depends ReleaseBuildCommonComponent {
    # Build configuration release
    $script:config = "Release"
    Extract-Files "$baseDir\VxPlayerInstaller\Resources\VxPlayerReleaseBuild\VxPlayerReleaseBuild.zip" "$baseDir\VxPlayerInstaller\Resources\ExportPlayer"
    #run-msbuild -solution $solutionFile -target Build -configuration $script:config -platform $platform -productVersion $env:NewProductVersion -signOutput true -solutiondir $script:$baseDir
    run-msbuild -solution $ExportPlayerBootstrapperProjFile -target Build -configuration $script:config -platform $platform -productVersion $env:NewProductVersion -signOutput true -solutiondir $baseDir\
}

task DebugBuild -depends DebugBuildCommonComponent {
    # Build configuration debug
    $script:config = "Debug"
    Extract-Files "$baseDir\VxPlayerInstaller\Resources\VxPlayerReleaseBuild\VxPlayerReleaseBuild.zip" "$baseDir\VxPlayerInstaller\Resources\ExportPlayer"
    #run-msbuild -solution $solutionFile -target Build -configuration $script:config -platform $platform -productVersion $env:NewProductVersion -signOutput true -solutiondir $script:$baseDir
    run-msbuild -solution $ExportPlayerBootstrapperProjFile -target Build -configuration $script:config -platform $platform -productVersion $env:NewProductVersion -signOutput true -solutiondir $baseDir\
}

task CreateNuGetPackage {
    $name = Get-ChildItem "$baseDir\VxPlayerInstaller\ExportPlayerBootstrapper\bin\Release\*.exe" |
            Sort-Object |
            Select-Object -Last 1 -ExpandProperty Name

    $env:NewProductVersion =[System.Diagnostics.FileVersionInfo]::GetVersionInfo("$baseDir\VxPlayerInstaller\ExportPlayerBootstrapper\bin\Release\$name").FileVersion
    Write-Host "Found file Version- $env:NewProductVersion"
    Copy-Item "$baseDir\VxPlayerInstaller\ExportPlayerBootstrapper\bin\Release\$name" "$baseDir\VxPlayerInstaller\ExportPlayerBootstrapper\bin\VxPlayerBundle.exe"
    #create the nuget package.Package will be created in the root directory.
    exec-and-wait -target $nugetPath -arguments "pack", $vxplayerInstallernugetSpec, "-Properties", "version=$env:NewProductVersion"

}

task PublishNuGetPackage -depends CreateNuGetPackage {   
   #upload the created nuget package.
   exec-and-wait -target $nugetPath -arguments "push", "VxPlayer.Installer.$env:NewProductVersion.nupkg", "-Source", "$vxplayernugetuploadurl", "-ApiKey", "${nugetPelcoToolsFeedUser}:${nugetPelcoToolsFeedPass}", "-NonInteractive"
}