﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

namespace ExportPlayerCustomInstaller.Constants
{
    public static class InstallerConstants
    {
        #region GUID Constants

        // Application ID
        public const string AppId = "Global\\{E3354AB0-4B20-440F-AFCF-93646162113F}";
        // Shared memory name (Id)
        public const string SharedMemId = "Update-C82A383C-751A-43B8-90BF-A250F7BC2863";

        #endregion

        #region String Constants

        public const string PROCESS_NAME = "VideoXpert VxPlayer";
        public const string VXPLAYER_INSTALLED = "VxPlayerInstalled";
        public const string APP_NAME = "VxPlayer";
        public const string DBG_PROCESS = "Dbg";
        public const string CFGMGR_PROCESS = "CfgMgr";
        public const string VXPLAYER_LICENSE_FILE = "LicenseTerms.txt";
        public const string VXPLAYER_INSTALL_FOLDER = "VxPlayerInstallFolder";
        public const string SHOULD_INSTALL_VXPLAYER = "ShouldInstallVxPlayer";
        public const string VXPLAYER_DIR = "INSTALLDIR";
        public const string REGISTRY_KEYNAME_PATH = "Path";
        public const string CURRENT_VER_TEXT = "CurrentVersion";

        #endregion

        #region Numeric Constants

        public const int RESTART_INITIATED = 1641;
        public const int RESTART_REQUIRED = 3010;
        public const int FAILED_NOACTION_REBOOT = 350;

        #endregion

        #region Icon Path

        public const string HOME_PAGE_ICON = "pack://application:,,,/ExportPlayerCustomInstaller;component/Resources/vx-installer-header-lg.png";
        public const string INSTALLER_PAGE_ICON = "pack://application:,,,/ExportPlayerCustomInstaller;component/Resources/vx-installer-header-sm.png";

        #endregion
    }
}
