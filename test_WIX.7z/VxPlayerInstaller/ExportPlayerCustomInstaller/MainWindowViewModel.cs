﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */

#region Namespaces

using Installer.Core.Core.Events;
using Prism.Events;
using Prism.Mvvm;
using System;
using System.ComponentModel.Composition;
using Installer.Core.Enums;
using Installer.Core.Interfaces;
using Installer.Core.Core;
using Installer.Core.Core.Handler;
using Installer.Views.Common.Views;
using ExportPlayerCustomInstaller.Model;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using ExportPlayerCustomInstaller.Constants;
using Microsoft.Win32;

#endregion

namespace ExportPlayerCustomInstaller
{
    /// <summary>
    /// Main window ViewModel class.
    /// </summary>
    [Export]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public class MainWindowViewModel : BindableBase, IDisposable
    {
        #region Private Members

        private bool versionVisible = true;
        private string version = null;
        private string windowTitle = null;
        private ObservableCollection<ProcessAttributes> appProcesses;

        #endregion

        #region Constructor
        [ImportingConstructor]
        public MainWindowViewModel(BundleModel model,
                                   EventAggregator eventAgg,
                                   ViewNavigatorHandler viewNav,
                                   ApplicationHandler appManager,
                                   IUIInteractionService uiService)
        {
            UIService = uiService;
            ViewNavigator = viewNav;
            EventingService = eventAgg;
            InstallerVersion = model.BundleInfo.Version.ToString();

            AppManager = appManager;
            Model = model;
            InitializeApplicationManager();
            RegisterForPageEvents();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets and set the registry path for VxPlayer
        /// </summary>
        public string RegistryPath { get; set; } = Resources.ResourceStrings.Resources.regPath;

        /// <summary>
        /// Gets or sets the Bundle model handle.
        /// </summary>
        public BundleModel Model { get; set; }

        /// <summary>
        /// Gets and sets the window title
        /// title bar.
        /// </summary>
        public ObservableCollection<ProcessAttributes> AppProcesses
        {
            get
            {
                return appProcesses;
            }

            set
            {
                if (appProcesses != value)
                {
                    SetProperty(ref appProcesses, value);
                }
            }
        }

        /// <summary>
        /// Gets or sets the Application manager handle.
        /// </summary>
        public ApplicationHandler AppManager { get; set; }

        /// <summary>
        /// Gets and sets the window title
        /// title bar.
        /// </summary>
        public string WindowTitle
        {
            get
            {
                return windowTitle;
            }

            set
            {
                if (windowTitle != value)
                {
                    SetProperty(ref windowTitle, value);
                }
            }
        }

        /// <summary>
        /// Gets and sets the installer's version
        /// </summary>
        public string InstallerVersion
        {
            get
            {
                return version;
            }

            set
            {
                if (version != value)
                {
                    SetProperty(ref version, value);
                }
            }
        }

        /// <summary>
        /// Gets and sets the installer's version visibility
        /// </summary>
        public bool VersionVisibility
        {
            get
            {
                return versionVisible;
            }

            set
            {
                if (versionVisible != value)
                {
                    SetProperty(ref versionVisible, value);
                }
            }
        }

        /// <summary>
        /// Gets and sets the eventing service used to receive install state events.
        /// </summary>
        private EventAggregator EventingService { get; set; }

        /// <summary>
        /// Gets and sets the view navigator used to request the installer's initial page.
        /// </summary>
        private ViewNavigatorHandler ViewNavigator { get; set; }

        /// <summary>
        /// Gets and sets the service used to interact with the UI.
        /// </summary>
        private IUIInteractionService UIService { get; set; }

        #endregion

        #region IDisposable

        public void Dispose()
        {
            UnRegisterFromPageEvents();
        }

        #endregion

        #region Private methods

        private void InitializeApplicationManager()
        {

            List<string> InstallingApps = new List<string>();
            AppProcesses = new ObservableCollection<ProcessAttributes>();
            AppProcesses.Add(new ProcessAttributes
            {
                ProcessName = Constants.InstallerConstants.PROCESS_NAME,
                AppName = InstallerConstants.APP_NAME
            });
            InstallingApps.Add(InstallerConstants.APP_NAME);
            AppManager.Init(AppProcesses, InstallingApps);
            Model.KillProcess(InstallerConstants.DBG_PROCESS);
            Model.KillProcess(InstallerConstants.CFGMGR_PROCESS);
        }

        private void CustomConfigPageNotificationRecieved(string applicationInstallPath)
        {
            Model.VxPlayerInstallFolder = applicationInstallPath;
        }

        private void ErrorPageLogFileClickEventRecieved(string file)
        {
            new Util().OpenFile(Model.Engine.StringVariables["WixBundleLog"]);
        }

        private void ProgressPageClickEventRecieved(PageButtons button)
        {
            switch (button)
            {
                case PageButtons.Action1:
                    Model.IsPerformCancel = true;
                    break;
                case PageButtons.Action2: //Not applicable
                    break;
                case PageButtons.Action3: //Not applicable
                    break;
                default: // No operation
                    break;
            }
        }

        private void UninstallPageClickEventRecieved(PageButtons button)
        {
            switch (button)
            {
                case PageButtons.Action1:
                    SetProgressPagePropertiesAndPlanInstall();
                    break;
                case PageButtons.Action2:
                    Model.InstallMode = InstallationMode.Repair;
                    SetProgressPagePropertiesAndPlanInstall();
                    break;
                case PageButtons.Action3://Not applicable
                    break;
                default:// No operation
                    break;
            }

        }

        private void ConfigPageClickEventRecieved(PageButtons button)
        {
            switch (button)
            {
                case PageButtons.Action1:
                    SetProgressPagePropertiesAndPlanInstall();
                    break;
                case PageButtons.Action2://Not applicable
                    break;
                case PageButtons.Action3://Not applicable
                    break;
                default:// No operation
                    break;
            }
        }

        private void HomePageClickEventRecieved(PageButtons button)
        {
            switch (button)
            {
                case PageButtons.Action1:
                    {
                        if (Model.InstallMode == InstallationMode.Upgrade)
                        {
                            if (!AppManager.IsApplicationRunning)
                            {
                                SetProgressPagePropertiesAndPlanInstall();
                            }
                            else
                            {
                                ViewNavigator.ShowPage(typeof(ComponentUpgradePageView).Name);
                            }
                        }
                        else
                        {
                            SetProgressPagePropertiesAndPlanInstall();
                        }
                    }
                    break;
                case PageButtons.Action2:
                    ViewNavigator.ShowPage(typeof(CustomConfigPageView).Name);
                    break;
                case PageButtons.Action3:
                    UIService.ShowExitDialog();
                    break;
                default:// No operation
                    break;
            }
        }

        private void ComponentUpgradePageClickEventRecieved(PageButtons button)
        {
            switch (button)
            {
                case PageButtons.Action1:
                    SetProgressPagePropertiesAndPlanInstall();
                    break;
                case PageButtons.Action2://Not applicable
                    break;
                case PageButtons.Action3://Not applicable
                    break;
                default:// No operation
                    break;
            }
        }

        private void SetProgressPagePropertiesAndPlanInstall()
        {
            if (!AppManager.IsApplicationRunning || Model.InstallMode == InstallationMode.NewInstall)
            {
                var progressPageProperties = new Dictionary<string, object>();
                progressPageProperties.Add(Installer.Core.Core.Constants.IS_UNINSTALLING, Model.InstallMode == InstallationMode.Uninstall);
                progressPageProperties.Add(Installer.Core.Core.Constants.IS_REPAIRING, Model.InstallMode == InstallationMode.Repair);

                if ((Model.InstallMode == InstallationMode.Upgrade) || (Model.InstallMode == InstallationMode.NewInstall))
                {
                    progressPageProperties.Add(Installer.Core.Core.Constants.CAN_PERFORM_CANCEL, true);

                    if (Model.InstallInfo.IsApplicationInstalled(RegistryPath, InstallerConstants.REGISTRY_KEYNAME_PATH, RegistryHive.CurrentUser))
                    {
                        Model.VxPlayerInstallFolder = Model.InstallInfo.GetApplicationInstallFolder(RegistryPath, InstallerConstants.REGISTRY_KEYNAME_PATH, RegistryHive.CurrentUser);
                    }
                }

                ViewNavigator.ShowPage(typeof(ProgressPageView).Name);
                EventingService.GetEvent<ProgressPagePropertiesEvent>().Publish(progressPageProperties);
                // Plan the installation.
                Model.PlanInstallAction();
            }
        }

        /// <summary>
        /// Called when the installation state is detected.
        /// </summary>
        private void OnInstallModeDetected(InstallationMode mode)
        {
            switch (mode)
            {
                case InstallationMode.NewInstall:
                    SetWindowTitle(Resources.ResourceStrings.Resources.strInstallationWindowTitle);
                    ViewNavigator.ShowPage(typeof(HomePageView).Name);
                    break;

                case InstallationMode.Uninstall:
                    SetWindowTitle(Resources.ResourceStrings.Resources.strUninstallWindowTitle);
                    ViewNavigator.ShowPage(typeof(UninstallPageView).Name);
                    break;

                case InstallationMode.Upgrade:
                    SetWindowTitle(Resources.ResourceStrings.Resources.strUpgradeWindowTitle);
                    var homePageProperties = new Dictionary<string, object>();
                    homePageProperties.Add(Installer.Core.Core.Constants.IS_UPGRADE, true);
                    EventingService.GetEvent<HomePagePropertiesEvent>().Publish(homePageProperties);
                    ViewNavigator.ShowPage(typeof(HomePageView).Name);
                    break;

                case InstallationMode.Downgrade:
                    // We do not support downgrades so move the installer into the error state and report
                    // the error to the user.
                    SetWindowTitle(Resources.ResourceStrings.Resources.strInstallationWindowTitle);
                    ViewNavigator.ShowErrorPage(Resources.ResourceStrings.Resources.strErrorViewTitleText,
                                                Resources.ResourceStrings.Resources.strDowgradeErrorMessage);
                    break;

                case InstallationMode.Repair:
                case InstallationMode.Modify:
                    // Currently not supported and will just do an uninstall if selected.
                    break;

                default:
                    break; // nothing to do
            }
        }
        /// <summary>
        /// Sets the window title on the UI thread.
        /// </summary>
        /// <param name="title"></param>
        private void SetWindowTitle(string title)
        {
            if (Model.InstallMode == InstallationMode.Uninstall || Model.InstallMode == InstallationMode.Repair)
            {
                VersionVisibility = false;
            }
            UIService.RunOnUIThreadAsync(() => WindowTitle = title);
        }

        #endregion

        #region Public methods

        /// <summary>
        /// Register for page events
        /// </summary>
        public void RegisterForPageEvents()
        {
            EventingService.GetEvent<InstallationModeDetectedEvent>().Subscribe(OnInstallModeDetected);
            EventingService.GetEvent<HomePageClickEvent>().Subscribe(HomePageClickEventRecieved);
            EventingService.GetEvent<CustomConfigPageClickEvent>().Subscribe(ConfigPageClickEventRecieved);
            EventingService.GetEvent<ProgressPageClickEvent>().Subscribe(ProgressPageClickEventRecieved);
            EventingService.GetEvent<UninstallPageClickEvent>().Subscribe(UninstallPageClickEventRecieved);
            EventingService.GetEvent<ComponentUpgradePageClickEvent>().Subscribe(ComponentUpgradePageClickEventRecieved);
            EventingService.GetEvent<CustomConfigPageNotificationsEvent>().Subscribe(CustomConfigPageNotificationRecieved);
            EventingService.GetEvent<ErrorPageLogFileClickEvent>().Subscribe(ErrorPageLogFileClickEventRecieved);
        }

        /// <summary>
        /// unregister for page events
        /// </summary>
        public void UnRegisterFromPageEvents()
        {
            EventingService.GetEvent<InstallationModeDetectedEvent>().Unsubscribe(OnInstallModeDetected);
            EventingService.GetEvent<HomePageClickEvent>().Unsubscribe(HomePageClickEventRecieved);
            EventingService.GetEvent<CustomConfigPageClickEvent>().Unsubscribe(ConfigPageClickEventRecieved);
            EventingService.GetEvent<ProgressPageClickEvent>().Unsubscribe(ProgressPageClickEventRecieved);
            EventingService.GetEvent<UninstallPageClickEvent>().Unsubscribe(UninstallPageClickEventRecieved);
            EventingService.GetEvent<ComponentUpgradePageClickEvent>().Unsubscribe(ComponentUpgradePageClickEventRecieved);
            EventingService.GetEvent<CustomConfigPageNotificationsEvent>().Unsubscribe(CustomConfigPageNotificationRecieved);
        }

        #endregion
    }
}
