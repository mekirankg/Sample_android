﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespaces

using Installer.Core.Enums;
using Installer.Core.Interfaces;
using Microsoft.Tools.WindowsInstallerXml.Bootstrapper;
using Newtonsoft.Json;
using System;
using System.IO;
using Installer.Core.Core;
using System.Diagnostics;
using System.Linq;
using ExportPlayerCustomInstaller.Constants;
using Installer.Core.Helper;
using Microsoft.Win32;

#endregion

namespace ExportPlayerCustomInstaller.Model
{
    /// <summary>
    /// Class holds the model for the Bundle.
    /// </summary>
    public class BundleModel : ILogger
    {
        #region Constructor

        public BundleModel(Bundle bundle, BootstrapperApplication app)
        {
            App = app;
            BundleInfo = bundle;
            InstallerExitCode = 0;
            RestartState = ApplyRestart.None;
            InstallInfo = new InstallationInfo();            

            VxPlayerInstallFolder = new DirectoryHelper().GetProgramFilesFolder(@"Pelco\VideoXpert\VxPlayer");
        }

        #endregion

        #region Properties

        /// <summary>
        /// Retrieves information about the current executing bundle
        /// </summary>
        public Bundle BundleInfo { get; private set; }

        /// <summary>
        /// Retrieves information about and installed VxPlayer instance.
        /// </summary>
        public InstallationInfo InstallInfo { get; private set; }

        /// <summary>
        /// Gets and sets the installation mode.
        /// </summary>
        public InstallationMode InstallMode { get; set; }       

        /// <summary>
        /// Indicates if VxPlayer is currently installed.
        /// </summary>
        public bool IsVxPlayerInstalled
        {
            get
            {
                return InstallInfo.IsApplicationInstalled(Resources.ResourceStrings.Resources.regPath, InstallerConstants.REGISTRY_KEYNAME_PATH, RegistryHive.CurrentUser);
            }
        }

        /// <summary>
        /// Get the def. installation directory.
        /// </summary>
        public string DefaultInstallationDirectory
        {
            get
            {
                return  VxPlayerInstallFolder;
            }
        }

        /// <summary>
        /// Gets and sets the flag indicating if the VxPlayer should be installed.
        /// </summary>
        public bool ShouldInstallVxPlayer
        {
            get
            {
                return Engine.NumericVariables[InstallerConstants.SHOULD_INSTALL_VXPLAYER] == 1;
            }

            set
            {
                Engine.NumericVariables[InstallerConstants.SHOULD_INSTALL_VXPLAYER] = value ? 1 : 0;
            }
        }

        /// <summary>
        /// Gets and sets the installation folder for VxPlayer.
        /// </summary>
        public string VxPlayerInstallFolder
        {
            get
            {
                return Engine.StringVariables[InstallerConstants.VXPLAYER_INSTALL_FOLDER];
            }

            set
            {
                Engine.StringVariables[InstallerConstants.VXPLAYER_INSTALL_FOLDER] = new DirectoryHelper().SanitizePath(value);
            }
        }        

        /// <summary>
        /// Gets and set the exit code to use when exiting the installer.
        /// </summary>
        public int InstallerExitCode { get; set; }

        /// <summary>
        /// Flag indicating if the user has requested to Cancel the installation
        /// </summary>
        public bool IsPerformCancel { get; set; }

        /// <summary>
        /// Gets and sets the installer's restart state.
        /// </summary>
        public ApplyRestart RestartState { get; set; }

        /// <summary>
        /// Indicates if a restart is required.
        /// </summary>
        public bool IsRestartRequired
        {
            get
            {
                return (RestartState == ApplyRestart.RestartInitiated) || (RestartState == ApplyRestart.RestartRequired);
            }
        }

        /// <summary>
        /// The installer's bootstrapper application
        /// </summary>
        public BootstrapperApplication App { get; private set; }

        /// <summary>
        /// The installer's install engine.
        /// </summary>
        public Engine Engine
        {
            get
            {
                return App.Engine;
            }
        }

        #endregion        

        #region ILogger

        /// <summary>
        /// Logs an error message
        /// </summary>
        /// <param name="msg">The message to log</param>
        public void LogError(string msg)
        {
            Log(LogLevel.Error, msg);
        }

        /// <summary>
        /// Logs a standard message
        /// </summary>
        /// <param name="msg">The message to log</param>
        public void LogStandard(string msg)
        {
            Log(LogLevel.Standard, msg);
        }

        /// <summary>
        /// Logs a debug message
        /// </summary>
        /// <param name="msg">The message to log</param>
        public void LogDebug(string msg)
        {
            Log(LogLevel.Debug, msg);
        }

        /// <summary>
        /// Logs a verbose message
        /// </summary>
        /// <param name="msg">The message to log</param>
        public void LogVerbose(string msg)
        {
            Log(LogLevel.Verbose, msg);
        }

        /// <summary>
        /// Logs a standard event.
        /// </summary>
        /// <param name="eventName">The name of the event to log</param>
        /// <param name="args">The event args to log</param>
        public void LogStandardEvent(string eventName, EventArgs args = null)
        {
            LogEvent(LogLevel.Standard, eventName, args);
        }

        /// <summary>
        /// Logs a debug event.
        /// </summary>
        /// <param name="eventName">The name of the event to log</param>
        /// <param name="args">The event args to log</param>
        public void LogDebugEvent(string eventName, EventArgs args = null)
        {
            LogEvent(LogLevel.Debug, eventName, args);
        }

        /// <summary>
        /// Logs a verbose event.
        /// </summary>
        /// <param name="eventName">The name of the event to log</param>
        /// <param name="args">The event args to log</param>
        public void LogVerboseEvent(string eventName, EventArgs args = null)
        {
            LogEvent(LogLevel.Verbose, eventName, args);
        }

        /// <summary>
        /// Logs a message 
        /// </summary>
        /// <param name="level">The log level of the message</param>
        /// <param name="msg">The message to log</param>
        public void Log(LogLevel level, string msg)
        {
            Engine.Log(level, msg);
        }

        /// <summary>
        /// Logs an event.
        /// </summary>
        /// <param name="level">The log level to log at.</param>
        /// <param name="eventName">The name of the event</param>
        /// <param name="args">The event args to log</param>
        public void LogEvent(LogLevel level, string eventName, EventArgs args = null)
        {
            Engine.Log(level, args == null
                    ? string.Format("EVENT: {0}", eventName)
                    : string.Format("EVENT: {0} ({1})", eventName, JsonConvert.SerializeObject(args)));
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Plans (defines) the installation mode.  Planning does not initiate the installation you must
        /// call Apply to start the installation.  Applying is done when a 'PlanComplete' callback is
        /// executed (defined in the ProgressPageViewModel)
        /// </summary>
        public void PlanInstallAction()
        {
            switch (InstallMode)
            {
                case InstallationMode.Uninstall:
                    Engine.Plan(LaunchAction.Uninstall);
                    break;

                case InstallationMode.Repair:
                    Engine.Plan(LaunchAction.Repair);
                    break;

                case InstallationMode.Modify:
                    Engine.Plan(LaunchAction.Modify);
                    break;

                case InstallationMode.Upgrade:
                case InstallationMode.NewInstall:
                    Engine.Plan(LaunchAction.Install);
                    break;

                default:
                    break; // no-op; should never get here; detect would have to fail.
            }
        }        

        /// <summary>
        /// Kill a process locally
        /// </summary>
        /// <param name="process">Name of the process</param>
        /// <returns></returns>
        public void KillProcess(string process)
        {
            var processes = Process.GetProcessesByName(process);
            if (processes.Count() >= 1)
            {
                processes[0].Kill();
            }
        }

        #endregion

    }
}
