﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespaces

using Installer.Views.Common.Dialogs;
using Installer.Views.Common.ViewModels;
using Installer.Views.Common.Views;
using Installer.Core.Core;
using Installer.Core.Core.Events;
using Installer.Core.Core.IPC;
using Installer.Core.Enums;
using Installer.Core.Interfaces;
using ExportPlayerCustomInstaller.Model;
using ExportPlayerCustomInstaller.Constants;
using Microsoft.Tools.WindowsInstallerXml.Bootstrapper;
using Prism.Events;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Interop;
using System.Windows.Threading;
using System.IO;
using Installer.Core.Core.Handler;
using System.Windows.Media.Imaging;
using System.Diagnostics;
using Installer.Core.Helper;
using Microsoft.Win32;

#endregion

namespace ExportPlayerCustomInstaller
{
    public class BundleBootstrapper : BootstrapperApplication, IUIInteractionService, IBootstrapperEvents
    {
        #region Private Members

        private bool cancelRequested = false;
        private bool failureRequiresRestart = false;
        private bool performingRollback = false;
        private string licenseText;
        private bool shouldCheckRelatedMSI = true;

        #endregion

        #region Constructor

        public BundleBootstrapper()
        {
            EventingService = new EventAggregator();
        }

        #endregion

        #region Properties

        public string LicenseText
        {
            get { return licenseText; }
            set
            {
                licenseText = value;
            }
        }
        /// <summary>
        /// Gets and sets the underlying installation model
        /// </summary>
        private BundleModel Model { get; set; }

        /// <summary>
        /// Gets and sets the application's main window.
        /// </summary>
        private Window MainWindow { get; set; }

        /// <summary>
        /// Gets and sets the main window handle
        /// </summary>
        private IntPtr MainWindowHandle { get; set; }

        /// <summary>
        /// Gets and sets the application's composition container
        /// </summary>
        private CompositionContainer Container { get; set; }

        /// <summary>
        /// Gets and sets the application's eventing aggregator
        /// </summary>
        private EventAggregator EventingService { get; set; }

        /// <summary>
        /// Gets and shared memory instance used to hold upgrade state.
        /// </summary>
        private SharedMemory<UpgradeState> UpgradeInfo { get; set; }

        #endregion

        #region Installer Entry

        /// <summary>
        /// Runs the installer application.
        /// </summary>
        protected override void Run()
        {
#if DEBUG
            // To enable debugging from Visual Studio uncomment the following line.
            //System.Diagnostics.Debugger.Launch();
#endif
            RegisterForBootstrapperEvents();

            using (var mutex = new Mutex(false, InstallerConstants.AppId))
            {
                mutex.SetAccessControl(GetMutexAccessControl());

                bool processHandle = false;
                try
                {
                    using (UpgradeInfo = new SharedMemory<UpgradeState>(InstallerConstants.SharedMemId, Marshal.SizeOf(typeof(UpgradeState))))
                    {
                        UpgradeInfo.Open();

                        // Only allow a single instance of the installer to run unless we are performing an
                        // uninstall during an upgrade.  If we are not performing an upgrade then the upgrade
                        // state will have no data.
                        var state = UpgradeInfo.Data;
                        if ((state.HasValue && state.Value.HasData) || (processHandle = mutex.WaitOne(1000, false)))
                        {
                            Engine.Log(LogLevel.Verbose, "Running Custom VxPlayer installer UI");

                            var version = Engine.VersionVariables["WixBundleVersion"];

                            Model = new BundleModel(BootstrapperApplicationData.GetBundleInfo(version), this);

                            var cultureInfo = new CultureHandler().SetCulture();
                            Installer.Core.Resources.ResourceStrings.Resources.Culture = cultureInfo;
                            Resources.ResourceStrings.Resources.Culture = cultureInfo;

                            using (Container = this.SetupCompositionContainer())
                            {
                                Engine.Log(LogLevel.Verbose, "Creating VxPlayer installer UI");

                                MainWindow = Container.GetExportedValue<Window>("MainWindow");
                                MainWindowHandle = new WindowInteropHelper(MainWindow).EnsureHandle();

                                // Kick off the detect, which will determine if the install conditions are meet.
                                Engine.Detect();
                                var homePageProperties = new Dictionary<string, object>();
                                homePageProperties.Add(Installer.Core.Core.Constants.INSTALLER_VERSION, string.Format("{0} {1}", Model.BundleInfo.Attributes.DisplayName, Model.BundleInfo.Version.ToString()));
                                EventingService.GetEvent<HomePagePropertiesEvent>().Publish(homePageProperties);
                                var configPageProperties = new Dictionary<string, object>();
                                configPageProperties.Add(Installer.Core.Core.Constants.INSTALL_DIRECTORY, Model.VxPlayerInstallFolder);
                                configPageProperties.Add(Installer.Core.Core.Constants.FILEDIALOG_TEXT, Model.BundleInfo.Attributes.DisplayName);
                                configPageProperties.Add(Installer.Core.Core.Constants.ENHANCED_DECODER_CHECKBOX_TEXT, "");
                                configPageProperties.Add(Installer.Core.Core.Constants.CHECKBOX_VISIBLE, false);
                                EventingService.GetEvent<CustomConfigPagePropertiesEvent>().Publish(configPageProperties);
                                if (Command.Display == Display.Passive || Command.Display == Display.Full)
                                {
                                    // Not a silent install so let's show the UI.
                                    MainWindow.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                                    MainWindow.Show();
                                }
                                else
                                {
                                    string[] commandLineArguments = Command.GetCommandLineArgs();
                                    if (commandLineArguments != null && commandLineArguments.Count() > 0)
                                    {
                                        ConsoleHelper.ExtractMsiProperties(commandLineArguments);
                                    }
                                }
                                Dispatcher.Run();
                            }
                        }
                        else
                        {
                            // A instance of this installer is already running report an error and exit.
                            System.Windows.MessageBox.Show(Resources.ResourceStrings.Resources.srcProcessAlreadyRunning,
                                                           Resources.ResourceStrings.Resources.srcErrorText,
                                                           MessageBoxButton.OK,
                                                           MessageBoxImage.Error);

                            Engine.Quit(0);
                        }
                    }
                }
                catch (AbandonedMutexException)
                {
                    // do nothing
                }
                catch (Exception ex)
                {
                    Engine.Log(LogLevel.Error,
                               string.Format("Caught exception while starting the installer, reason: {0}", ex.Message));
                }
                finally
                {
                    if (processHandle)
                    {
                        mutex.ReleaseMutex();
                    }

                    UnregisterFromBootstrapperEvents();

                    Engine.Quit(Model.InstallerExitCode);
                    Engine.Log(LogLevel.Verbose, "Exiting VxPlayer installer UI");
                }
            }

        }

        #endregion

        #region UIInteractionService

        /// <summary>
        /// Runs a action on the UI thread.
        /// </summary>
        /// <param name="body">The action to run</param>
        public void RunOnUIThreadAsync(Action body)
        {
            MainWindow.Dispatcher.BeginInvoke(body, null);
        }

        /// <summary>
        /// Executes an action on the UI Thread synchronously.
        /// </summary>
        /// <param name="body">The action to run</param>
        public void RunOnUIThreadSync(Action body)
        {
            MainWindow.Dispatcher.Invoke(body);
        }

        /// <summary>
        /// Opens an error dialog
        /// </summary>
        /// <param name="message">The error message to display</param>
        public void ShowErrorDialog(string message)
        {
            RunOnUIThreadAsync(() =>
            {
                var dialog = new ErrorDialog(message);
                dialog.Owner = MainWindow;
                dialog.WindowStartupLocation = WindowStartupLocation.CenterOwner;
                dialog.ShowDialog();
            });
        }

        /// <summary>
        /// Opens the confirmation dialog to allow the user to confirm that they
        /// want to delete their recordings and database files.
        /// </summary>
        /// <returns>True if the which to continue, false otherwise</returns>
        public async Task<bool> ShowDeleteConfirmationDialog()
        {
            return await MainWindow.Dispatcher.Invoke(() =>
            {
                var dialog = new DeleteFilesDialog();
                dialog.Owner = MainWindow;
                dialog.WindowStartupLocation = WindowStartupLocation.CenterOwner;
                dialog.ShowDialog();

                return Task.FromResult(dialog.Proceed);
            });
        }

        /// <summary>
        /// Opens a folder browse dialog and returns the selected folder. If the user selected
        /// folder is empty then initial path is returned.
        /// </summary>
        /// <param name="description">The dialogs description</param>
        /// <param name="initialFolder">initial folder to seed the dialog with</param>
        /// <returns></returns>
        public string OpenFileBrowseDialog(string description, string initalPath)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.SelectedPath = initalPath;
            dialog.Description = description;
            dialog.ShowDialog();

            var selected = dialog.SelectedPath;

            return string.IsNullOrEmpty(selected) ? initalPath : selected;
        }

        /// <summary>
        /// Return default installation directory
        /// </summary>
        public string GetDefaultInstallDirectory()
        {
            return Model.DefaultInstallationDirectory;
        }

        /// <summary>
        /// Return views header images
        /// </summary>
        public BitmapImage GetHeaderImage(bool isHomePage)
        {
            string uri = string.Empty;

            if (isHomePage)
            {
                uri = InstallerConstants.HOME_PAGE_ICON;
            }
            else
            {
                uri = InstallerConstants.INSTALLER_PAGE_ICON;
            }

            var packUri = new Uri(uri, UriKind.Absolute);
            BitmapImage img = new BitmapImage(packUri);
            return img;
        }

        /// <summary>
        /// Opens the Eula dialog
        /// </summary>
        public void ShowEulaDialog()
        {
            RunOnUIThreadAsync(() =>
            {
                string licenseFile = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), InstallerConstants.VXPLAYER_LICENSE_FILE);
                LicenseText = File.ReadAllText(licenseFile);

                var dialog = new EulaDialog(LicenseText, Resources.ResourceStrings.Resources.strEulaScreenHeading);

                dialog.Owner = MainWindow;
                dialog.WindowStartupLocation = WindowStartupLocation.CenterOwner;
                dialog.ShowDialog();
            });
        }

        public void ShowExitDialog()
        {
            RunOnUIThreadAsync(() =>
            {
                var model = new MessageBoxDialogViewModel(this, Resources.ResourceStrings.Resources.strMessageDialogExitTitleText,
                    Resources.ResourceStrings.Resources.strMessageDialogExitText);
                var dialog = new MessageBoxDialog(model);

                dialog.Owner = MainWindow;
                dialog.WindowStartupLocation = WindowStartupLocation.CenterOwner;
                dialog.ShowDialog();
            });
        }
        public void ShowCancelDialog()
        {
        }

        /// <summary>
        /// Closes and exits the installer UI window
        /// </summary>
        public void CloseUIAndExit()
        {
            RunOnUIThreadAsync(() => MainWindow.Close());
        }
        public void CancelInstaller()
        {
        }
        /// <summary>
        /// Returns the installer's main window handle
        /// </summary>
        /// <returns></returns>
        public IntPtr GetMainWindowHandle()
        {
            return MainWindowHandle;
        }

        #endregion

        #region Bootstrapper callbacks        

        /// <summary>
        /// Called when the BootstrapperApplication engine detection process starts.  This will allow
        /// us to determine if the product is installed or not.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Bootstrapper_DetectedBegin(object sender, DetectBeginEventArgs e)
        {
            Model.LogVerboseEvent("DetectBegin", e);

            Model.InstallMode = e.Installed ? InstallationMode.Uninstall : InstallationMode.NewInstall;
            Model.LogVerboseEvent("Installation Mode : " + Model.InstallMode);

            CheckAndSetDetectConditions();
            AssignInstallationFolder();
            if (Model.InstallInfo.SkipSilentUninstall(Command, Model.InstallMode, Resources.ResourceStrings.Resources.regPath, Model.BundleInfo.Version, InstallerConstants.CURRENT_VER_TEXT, RegistryHive.CurrentUser))
            {
                Model.LogStandardEvent("Detected request to cancel the install, notifying WiX");
                e.Result = Result.Cancel;
                Engine.Quit(0);
            }
        }

        /// <summary>
        /// Called when the BootstrapperApplication engine detects a related bundle.  This will only
        /// get called if we are repairing, modifying, downgrading, or upgrading and exiting bundle.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Bootstrapper_DetectedRelatedBundle(object sender, DetectRelatedBundleEventArgs e)
        {
            Model.LogVerboseEvent("DetectedRelatedBundle", e);

            if (e.Operation == RelatedOperation.Downgrade)
            {
                Model.InstallMode = InstallationMode.Downgrade;
            }
            else if (e.Operation == RelatedOperation.MajorUpgrade)
            {
                Model.InstallMode = InstallationMode.Upgrade;

                if (Model.BundleInfo.Version != null)
                {
                    if (Model.BundleInfo.Version.CompareTo(e.Version) < 0)
                    {
                        Model.InstallMode = InstallationMode.Downgrade;
                    }
                }
            }
            else if (e.Operation == RelatedOperation.Remove)
            {
                Model.InstallMode = InstallationMode.Uninstall;
            }
            else if (e.Operation == RelatedOperation.Repair)
            {
                Model.InstallMode = InstallationMode.Repair;
            }

            shouldCheckRelatedMSI = false;
            Model.LogVerboseEvent("Installation Mode : " + Model.InstallMode);

            AssignInstallationFolder();

        }

        /// <summary>
        /// Called when the Bootstrapper engine has completed detecting installation information.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Bootstrapper_DetectedComplete(object sender, DetectCompleteEventArgs e)
        {
            Model.LogVerboseEvent("DetectComplete", e);

            ViewNavigatorHandler pageNav = null;
            try
            {
                pageNav = Container.GetExportedValue<ViewNavigatorHandler>();

                NotifyInstallationModeDetected(Model.InstallMode);

                if (e.Status >= 0)
                {
                    if (Model.InstallMode == InstallationMode.Downgrade)
                    {
                        Engine.Log(LogLevel.Error, "Detected product downgrade. Downgrades are not supported");
                        return;
                    }
                    else if (Model.InstallMode == InstallationMode.Upgrade)
                    {
                        // We are performing an upgrade set the upgrade state so that we
                        // have enough context to tell the previous version uninstall to
                        // ignore uninstalling if the versions where not changed.
                        Engine.Log(LogLevel.Verbose, "Detected product Upgrade");
                        UpgradeInfo.Data = new UpgradeStateWrapper(Model.InstallInfo, Resources.ResourceStrings.Resources.regPath, InstallerConstants.CURRENT_VER_TEXT, RegistryHive.CurrentUser).State;
                    }

                    if (Command.Action == LaunchAction.Layout)
                    {
                        // Copies all of the bundle content to a specified directory
                        Engine.Plan(LaunchAction.Layout);
                        Engine.Log(LogLevel.Verbose, "Detected Launch Action - Layout");
                        return;
                    }
                    else if (Command.Display != Display.Full)
                    {
                        // Perform a silent install.
                        Engine.Log(LogLevel.Verbose, string.Format("Invoking automatic {0} for non-interactive mode", Model.InstallMode));

                        Model.PlanInstallAction();
                        return;
                    }
                }
                else
                {
                    // If a failure occurs during the detect phase then we cannot install.
                    pageNav.ShowErrorPage(Resources.ResourceStrings.Resources.strInstallationFailedTitle,
                        Resources.ResourceStrings.Resources.strInstallationFailedText);
                    Engine.Log(LogLevel.Error, "Failure occurred during the detect phase");
                }
            }
            catch (Exception ex)
            {
                var msg = string.Format("Failure occurred during detect completion, reason: {0}", ex.Message);
                Model.LogError(msg);

                if (Command.Display != Display.Full || pageNav == null)
                {
                    CloseUIAndExit(); // Just shutdown
                }
                else if (pageNav != null)
                {
                    pageNav.ShowErrorPage(Resources.ResourceStrings.Resources.strInstallationFailedTitle, msg);
                }
            }
        }

        /// <summary>
        /// Called when the bootstrapper engine is shutdown. This means that the installation is complete
        /// or failed for some reason.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void BundleBootstrapper_Shutdown(object sender, ShutdownEventArgs e)
        {
            Model.LogVerboseEvent("Shutdown", e);

            if (Model.IsRestartRequired)
            {
                if (Command.Display != Display.None)
                {
                    // Request a restart if the installation process requires a restart.
                    Model.LogStandard("Detected restart required while shutting down the installer. Setting the restart flag");
                    e.Result = Result.Restart;
                }
                else
                {
                    Model.LogStandard("Silent install. Skipping restart");
                }
            }
        }

        /// <summary>
        /// Called when the error event is received.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Bootstrapper_Error(object sender, Microsoft.Tools.WindowsInstallerXml.Bootstrapper.ErrorEventArgs e)
        {
            Model.LogEvent(LogLevel.Verbose, "Error", e);
            ViewNavigatorHandler pageNav = Container.GetExportedValue<ViewNavigatorHandler>();
            if (RequiresReboot(e.ErrorCode))
            {
                Model.LogError(string.Format("Received restart error code '{0}' setting installer state to required restart", e.ErrorCode));
                failureRequiresRestart = true;
            }
            else
            {
                // Report the error and cancel the installation
                pageNav.ShowErrorPage(Resources.ResourceStrings.Resources.strErrorViewTitleText,
                                            string.Format(Resources.ResourceStrings.Resources.strInstallErrorTemplate, e.ErrorMessage));

                e.Result = Result.Cancel;

                var msg = string.Format("Error Reported, canceling the installation" + e.ErrorMessage + " - " + e.ErrorCode);
                Model.LogError(msg);
            }
        }

        /// <summary>
        /// Called when the Plan complete event is generated by the engine.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Bootstrapper_PlanCompleted(object sender, PlanCompleteEventArgs e)
        {
            ViewNavigatorHandler pageNav = Container.GetExportedValue<ViewNavigatorHandler>();
            try
            {
                Model.LogEvent(LogLevel.Verbose, "PlanComplete", e);

                if (e.Status >= 0)
                {
                    Model.Log(LogLevel.Standard, "Applying requested plan");
                    Model.Engine.Apply(GetMainWindowHandle());
                }
                else
                {
                    // Report error
                    pageNav.ShowErrorPage(Resources.ResourceStrings.Resources.strInstallationFailedTitle, Resources.ResourceStrings.Resources.strInstallationFailedText);
                    var msg = string.Format("Error reported while processing PlanComplete event");
                    Model.Log(LogLevel.Error, msg);
                }
            }
            catch (Exception ex)
            {
                var msg = string.Format("Exception thrown while processing PlanComplete event, reason: ", ex.Message);
                Model.Log(LogLevel.Error, msg);

                pageNav.ShowErrorPage(Resources.ResourceStrings.Resources.strInstallationFailedTitle, msg);
            }
        }

        /// <summary>
        /// Executes when a bootstrapper progress event is received. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Bootstrapper_ExecuteProgress(object sender, ExecuteProgressEventArgs e)
        {
            Model.LogEvent(LogLevel.Verbose, "ExecuteProgress", e);

            if (Model.IsPerformCancel)
            {
                e.Result = Result.Cancel;
                Model.LogStandardEvent("Detected request to cancel the install, notifying WiX");
            }

            var progressPageProperties = new Dictionary<string, object>();
            progressPageProperties.Add(Installer.Core.Core.Constants.PROGRESS, e.OverallPercentage);
            EventingService.GetEvent<ProgressPagePropertiesEvent>().Publish(progressPageProperties);
        }

        /// <summary>
        /// Called when the apply operation is completed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Bootstrapper_ApplyComplete(object sender, ApplyCompleteEventArgs e)
        {
            ViewNavigatorHandler pageNav = Container.GetExportedValue<ViewNavigatorHandler>();
            try
            {
                Model.LogEvent(LogLevel.Verbose, "ApplyComplete", e);

                // Record the installation status and using it as the exit code for the bootstrapper engine.
                Model.LogStandard("Recording the installation status and using it as the exit code for the bootstrapper engine");
                Model.InstallerExitCode = e.Status;

                Model.LogStandard("Installation Exit code - " + Model.InstallerExitCode);

                // Store so we can determine if we should re-start or not after install.
                Model.RestartState = e.Restart;
                Model.LogStandard("Restart State - " + Model.RestartState);

                if (Model.App.Command.Display != Display.Full)
                {
                    // If we are running in silent mode then we need to make sure
                    // to close out the installer.  Even though we are not showing
                    // the UI we are still blocked waiting for the Dispatcher to stop
                    // this call indirectly calls Dispatcher.Shutdown and will allow
                    // the installer to exit.
                    CloseUIAndExit();
                    Model.LogStandardEvent("Detected silent installation closing UI");
                }

                if (e.Status >= 0)
                {
                    if (Model.IsPerformCancel)//_cancelRequested)
                    {
                        Model.LogStandard("User requested to cancel the installer after it was completed, finish page will still be shown");
                    }

                    if (Model.InstallMode == InstallationMode.Uninstall)
                    {
                        if (Model.RestartState == ApplyRestart.RestartRequired)
                        {
                            Model.LogStandard("Successfully uninstalled but requires a restart to complete");
                            var uninstallFinishPageProperties = new Dictionary<string, object>();
                            uninstallFinishPageProperties.Add(Installer.Core.Core.Constants.RESTART_REQUIRED, true);
                            EventingService.GetEvent<UninstallPageFinishPropertiesEvents>().Publish(uninstallFinishPageProperties);
                        }
                        Model.LogStandard("User requested to uninstall");
                        pageNav.ShowPage(typeof(UninstallFinishPageView).Name);
                    }
                    else if (Model.InstallMode == InstallationMode.Repair)
                    {
                        Model.LogStandard("User requested to uninstall");
                        var uninstallFinishPageProperties = new Dictionary<string, object>();
                        uninstallFinishPageProperties.Add(Installer.Core.Core.Constants.RESTART_REQUIRED, true);
                        uninstallFinishPageProperties.Add(Installer.Core.Core.Constants.IS_REPAIRING, true);
                        EventingService.GetEvent<UninstallPageFinishPropertiesEvents>().Publish(uninstallFinishPageProperties);
                        pageNav.ShowPage(typeof(UninstallFinishPageView).Name);
                    }
                    else if (Model.InstallMode == InstallationMode.NewInstall)
                    {
                        Model.LogStandard("User requested to install");
                        pageNav.ShowPage(typeof(InstallFinishPageView).Name);
                    }
                    else if (Model.InstallMode == InstallationMode.Upgrade)
                    {
                        Model.LogStandard("User requested to upgrade");
                        var installFinishPageProperties = new Dictionary<string, object>();
                        if (Model.RestartState == ApplyRestart.RestartRequired)
                        {
                            installFinishPageProperties.Add(Installer.Core.Core.Constants.RESTART_REQUIRED, true);
                        }
                        installFinishPageProperties.Add(Installer.Core.Core.Constants.IS_UPGRADE, true);
                        EventingService.GetEvent<InstallPageFinishPropertiesEvent>().Publish(installFinishPageProperties);
                        pageNav.ShowPage(typeof(InstallFinishPageView).Name);
                    }
                }
                else
                {
                    // We received an error that was not the result of a cancel request by the user.
                    if (!Model.IsPerformCancel)
                    {
                        Model.LogStandard("Received an error that was not the result of a cancel request by the user");
                        if (failureRequiresRestart)
                        {
                            // The installer detected an error that indicates a restart is required.
                            Model.LogStandard("The installer detected an error that indicates a restart is required");
                        }
                        else
                        {
                            // Error status received show error page.
                            pageNav.ShowErrorPage(Resources.ResourceStrings.Resources.strInstallationFailedTitle, Resources.ResourceStrings.Resources.strInstallationFailedText);
                            Model.LogStandard("Detected an error.");
                        }
                    }
                    else
                    {
                        // Error status received show error page.
                        Model.LogStandard("Detected an error. Showing error page.");
                        if (Model.InstallMode == InstallationMode.NewInstall)
                        {
                            pageNav.ShowErrorPage(Resources.ResourceStrings.Resources.strInstallationFailedText, Resources.ResourceStrings.Resources.strErrorViewInstallCancelTitleText);
                        }
                        else if (Model.InstallMode == InstallationMode.Uninstall)
                        {
                            pageNav.ShowErrorPage(Resources.ResourceStrings.Resources.strUnInstallationFailedText, Resources.ResourceStrings.Resources.strErrorViewUninstallCancelTitleText);
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                var msg = string.Format("Exception thrown while processing ApplyComplete callback, reason:", ex.Message);
                Model.Log(LogLevel.Error, msg);
                pageNav.ShowErrorPage(Resources.ResourceStrings.Resources.strInstallationFailedTitle, msg);
            }
        }

        /// <summary>
        /// Called when the bootstrapper execute package begins
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Bootstrapper_ExecutePackageBegin(object sender, ExecutePackageBeginEventArgs e)
        {
            Model.LogEvent(LogLevel.Verbose, "ExecutePackageBegin", e);
            string progressDescription = string.Empty;
            // Set rollback flag
            performingRollback = !e.ShouldExecute;

            RunOnUIThreadSync(() =>
            {
                // If ShouldExecute is false then we know a rollback is being performed.
                Model.LogStandardEvent("Deciding to Rollback - " + !e.ShouldExecute);
                var messagePrefix = e.ShouldExecute ? Resources.ResourceStrings.Resources.strProcessingText : Resources.ResourceStrings.Resources.strRollingbackText;

                try
                {
                    var package = Model.BundleInfo.Packages.FirstOrDefault(p => p.Id != null && e.PackageId == p.Id);
                    if (package != null && package.DisplayName != null)
                    {
                        progressDescription = string.Format("{0} {1}", messagePrefix, package.DisplayName);
                    }
                    else
                    {
                        Guid uuid;
                        if (Guid.TryParse(e.PackageId, out uuid))
                        {
                            progressDescription = string.Format(Resources.ResourceStrings.Resources.strUninstallOnUpgradeVxProDescription);
                        }
                        else
                        {
                            progressDescription = string.Format("{0} {1}", messagePrefix, e.PackageId);
                        }
                    }
                }
                catch (Exception)
                {
                    progressDescription = string.Format("{0} {1}", messagePrefix, e.PackageId);
                    Model.LogEvent(LogLevel.Verbose, "Exception caught : " + progressDescription);
                }
                var properties = new Dictionary<string, object>();
                properties.Add("ProgressDescription", progressDescription);
                EventingService.GetEvent<ProgressPagePropertiesEvent>().Publish(properties);
            });

            if (Model.IsPerformCancel && !performingRollback)//_cancelRequested && !_performingRollback)
            {
                // Only cancel if we are not performing a rollback.
                Model.LogEvent(LogLevel.Verbose, "Canceling as we are not performing a rollback, notifying WiX");
                e.Result = Result.Cancel;
            }
        }

        /// <summary>
        /// Called when the bootstrapper execute package is completed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Bootstrapper_ExecutePackageComplete(object sender, ExecutePackageCompleteEventArgs e)
        {
            string resourceString = string.Empty;
            ViewNavigatorHandler pageNav = Container.GetExportedValue<ViewNavigatorHandler>();
            Model.LogEvent(LogLevel.Verbose, "ExecutePackageComplete", e);

            if (Model.IsPerformCancel && cancelRequested)//!_performingRollback && _cancelRequested)
            {
                // Only cancel if we are not performing a rollback
                e.Result = Result.Cancel;
                Model.LogStandard("Detected request to cancel the install, notifying WiX");
                return;
            }

            if (e.Status < 0)
            {
                // Cancel install and report error.
                e.Result = Result.Cancel;
                Model.LogError(string.Format("Received status code '{0}', failure occur while installing {1}", e.Status, e.PackageId));
                if (Model.InstallMode == InstallationMode.Repair)
                {
                    resourceString = Resources.ResourceStrings.Resources.strErrorViewRepairCancelTitleText;
                    pageNav.ShowErrorPage(Resources.ResourceStrings.Resources.strRepairFailedText, resourceString);
                }
                else if (Model.InstallMode == InstallationMode.Upgrade)
                {
                    resourceString = Resources.ResourceStrings.Resources.strErrorViewUpgradeCancelTitleText;
                    pageNav.ShowErrorPage(Resources.ResourceStrings.Resources.strUpgradeFailedText, resourceString);
                }
            }
            else
            {
                if (Model.InstallMode == InstallationMode.Upgrade)
                {
                    var progressPageProperties = new Dictionary<string, object>();
                    progressPageProperties.Add(Installer.Core.Core.Constants.CAN_PERFORM_CANCEL, false);
                    EventingService.GetEvent<ProgressPagePropertiesEvent>().Publish(progressPageProperties);
                }
            }
        }

        /// <summary>
        /// Called when the bootstrapper related MSI is detected.
        /// This should execute only in case when VxPlayer is upgraded in a machine
        /// where Older version of OpsCenter is installed. In this case VxPlayer would be
        /// installed using the MSI version.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BundleBootstrapper_DetectRelatedMsiPackage(object sender, DetectRelatedMsiPackageEventArgs e)
        {
            Model.LogVerboseEvent("DetectRelatedMsiPackage", e);

            if (shouldCheckRelatedMSI && Model.InstallMode == InstallationMode.NewInstall)
            {
                if (e.Operation == RelatedOperation.Downgrade)
                {
                    Model.InstallMode = InstallationMode.Downgrade;
                }
                else if (e.Operation == RelatedOperation.MajorUpgrade)
                {
                    Model.InstallMode = InstallationMode.Upgrade;

                    if (Model.BundleInfo.Version != null)
                    {
                        if (Model.BundleInfo.Version.CompareTo(e.Version) < 0)
                        {
                            Model.InstallMode = InstallationMode.Downgrade;
                        }
                    }
                }
                else if (e.Operation == RelatedOperation.Remove)
                {
                    Model.InstallMode = InstallationMode.Uninstall;
                }
                else if (e.Operation == RelatedOperation.Repair)
                {
                    Model.InstallMode = InstallationMode.Repair;
                }

                shouldCheckRelatedMSI = false;
            }
            Model.LogVerboseEvent("Installation Mode : " + Model.InstallMode);
        }
        #endregion

        #region Private methods
        /// <summary>
        /// Assigning installation folder based on installation mode.
        /// </summary>
        /// <returns></returns>
        private void AssignInstallationFolder()
        {
            //Fetching installation directory from commandline arguments
            if (ConsoleHelper.CmdOptions != null && ConsoleHelper.CmdOptions.ContainsKey(InstallerConstants.VXPLAYER_DIR) && Model.InstallMode != InstallationMode.Upgrade)
            {
                Model.Engine.StringVariables[InstallerConstants.VXPLAYER_INSTALL_FOLDER] = ConsoleHelper.CmdOptions[InstallerConstants.VXPLAYER_DIR];
                Model.Engine.Log(LogLevel.Verbose, InstallerConstants.VXPLAYER_INSTALL_FOLDER + " : " + ConsoleHelper.CmdOptions[InstallerConstants.VXPLAYER_DIR]);
            }
            else
            {
                if (Model.InstallInfo.IsApplicationInstalled(Resources.ResourceStrings.Resources.regPath, InstallerConstants.REGISTRY_KEYNAME_PATH, RegistryHive.CurrentUser))
                {
                    Model.VxPlayerInstallFolder = Model.InstallInfo.GetApplicationInstallFolder(Resources.ResourceStrings.Resources.regPath, InstallerConstants.REGISTRY_KEYNAME_PATH, RegistryHive.CurrentUser);
                }
            }
        }

        /// <summary>
        /// Creates and sets up the composition container.  This method wires up the application
        /// based on the component Export and Import dependency attributes defined in this assembly.
        /// 
        /// For more information about the CompositionContainer (MEF)
        /// 
        /// See: https://msdn.microsoft.com/en-us/library/system.componentmodel.composition.hosting.compositioncontainer(v=vs.110).aspx
        /// </summary>
        /// <returns></returns>
        private CompositionContainer SetupCompositionContainer()
        {
            //Exporting referenced Assemblies that includes common views and classes
            var catalog = new AggregateCatalog();
            catalog.Catalogs.Add(new AssemblyCatalog(Assembly.GetExecutingAssembly()));
            catalog.Catalogs.Add(new AssemblyCatalog(AppDomain.CurrentDomain.BaseDirectory + Installer.Core.Core.Constants.INSTALLER_VIEW));
            catalog.Catalogs.Add(new AssemblyCatalog(AppDomain.CurrentDomain.BaseDirectory + Installer.Core.Core.Constants.INSTALLER_CORE));
            var container = new CompositionContainer(catalog);

            container.ComposeExportedValue<BundleModel>(Model);
            container.ComposeExportedValue<ILogger>(Model);
            container.ComposeExportedValue<IUIInteractionService>(this);
            container.ComposeExportedValue<EventAggregator>(EventingService);

            return container;
        }

        /// <summary>
        /// Creates the access control for a mutex.
        /// </summary>
        /// <returns></returns>
        private MutexSecurity GetMutexAccessControl()
        {
            // Setting up security for multi-user usage and to also work on localized systems (don't use just "Everyone") 
            var allowEveryoneRule = new MutexAccessRule(new SecurityIdentifier(WellKnownSidType.WorldSid, null),
                                                                               MutexRights.FullControl,
                                                                               AccessControlType.Allow);

            var securitySettings = new MutexSecurity();
            securitySettings.AddAccessRule(allowEveryoneRule);

            return securitySettings;
        }

        /// <summary>
        ///  Send event to notify subscribers that an InstallMode was detected.
        /// </summary>
        private void NotifyInstallationModeDetected(InstallationMode mode)
        {
            Model.LogStandard(string.Format("Detected installation mode: {0}", mode));
            EventingService.GetEvent<InstallationModeDetectedEvent>().Publish(mode);
        }

        /// <summary>
        /// Checks the installation mode and sets the detect conditions if needed.
        /// </summary>
        private void CheckAndSetDetectConditions()
        {
            if (Model.InstallMode == InstallationMode.Uninstall)
            {
                UpgradeState? state = UpgradeInfo.Data;
                if (state.HasValue && state.Value.HasData)
                {
                    // If we have state from the SharedMemory then we are performing an uninstall
                    // after an upgrade and need to determine if the versions have changed.  If they
                    // have not, then set the detect conditions to false.  This way the components
                    // that where not updated will not be uninstalled.  This is needed because WiX
                    // does not allow for enough context to know when to uninstall or not if an
                    // ExePackage version did not change after an upgrade.  Without this check ExePackages
                    // that do not have different version will be uninstalled.

                    UpgradeStateWrapper wrapper = new UpgradeStateWrapper(state.Value);

                    if (Model.IsVxPlayerInstalled)
                    {
                        SetDetectCondition(InstallerConstants.VXPLAYER_INSTALLED,
                                           Model.InstallInfo.GetApplicationVersion(Resources.ResourceStrings.Resources.regPath, InstallerConstants.CURRENT_VER_TEXT, RegistryHive.CurrentUser),
                                           wrapper.ApplicationVersion);
                    }
                }
                else
                {
                    // We are just uinstalling set the detect conditions based on what is installed.
                    Model.Engine.NumericVariables[InstallerConstants.VXPLAYER_INSTALLED] = Model.IsVxPlayerInstalled ? 1 : 0;
                }
            }
        }

        /// <summary>
        /// Sets the detect condition variable based on the installation versions.  If the
        /// versions are the same then we set the detect condition to false to disable the
        /// uninstall.
        /// </summary>
        /// <param name="var">The detect variable to set</param>
        /// <param name="curr">The currently installed version</param>
        /// <param name="prev">The previously installed version</param>
        private void SetDetectCondition(string var, Version curr, Version prev)
        {
            // If the versions are the same this will trick the bootstrapper into thinking
            // the ExePackage is not installed.
            Model.Engine.NumericVariables[var] = curr.CompareTo(prev) == 0 ? 0 : 1;
        }

        /// <summary>
        /// Indicates if a restart is required.
        /// </summary>
        /// <param name="eCode">The error code to check</param>
        /// <returns></returns>
        private bool RequiresReboot(int eCode)
        {
            return ((eCode == InstallerConstants.FAILED_NOACTION_REBOOT) || (eCode == InstallerConstants.RESTART_REQUIRED) ||
                (eCode == InstallerConstants.RESTART_INITIATED));
        }

        #endregion

        #region Public methods

        /// <summary>
        /// Register for bootstrapper events.
        /// </summary>
        public void RegisterForBootstrapperEvents()
        {

            DetectBegin += Bootstrapper_DetectedBegin;
            DetectRelatedBundle += Bootstrapper_DetectedRelatedBundle;
            DetectComplete += Bootstrapper_DetectedComplete;
            Shutdown += BundleBootstrapper_Shutdown;
            Error += Bootstrapper_Error;
            PlanComplete += Bootstrapper_PlanCompleted;
            ApplyComplete += Bootstrapper_ApplyComplete;
            ExecuteProgress += Bootstrapper_ExecuteProgress;
            ExecutePackageBegin += Bootstrapper_ExecutePackageBegin;
            ExecutePackageComplete += Bootstrapper_ExecutePackageComplete;
            DetectRelatedMsiPackage += BundleBootstrapper_DetectRelatedMsiPackage;
        }

        /// <summary>
        /// Unregisters from bootstrapper events.
        /// </summary>
        public void UnregisterFromBootstrapperEvents()
        {
            // NOTICE: Do not remove the shutdown callback otherwise the restart flag
            // will not be set if needed.

            DetectBegin -= Bootstrapper_DetectedBegin;
            DetectRelatedBundle -= Bootstrapper_DetectedRelatedBundle;
            DetectComplete -= Bootstrapper_DetectedComplete;
            Error -= Bootstrapper_Error;
            PlanComplete -= Bootstrapper_PlanCompleted;
            ApplyComplete -= Bootstrapper_ApplyComplete;
            ExecuteProgress -= Bootstrapper_ExecuteProgress;
            ExecutePackageBegin -= Bootstrapper_ExecutePackageBegin;
            ExecutePackageComplete -= Bootstrapper_ExecutePackageComplete;
        }

        public void SetEncoderValue(bool value)
        {
           // no operation
        }

        public bool GetDefaultEnhancedDecoderStatus()
        {
            return false;
        }

        public void SetEnhancedDecoderValue(bool value)
        {
            // no operation
        }

        #endregion
    }
}
