﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */

#region Namespaces

using Installer.Views.Common.ViewModels;
using Installer.Views.Common.Views;
using Installer.Core.Core.Events;
using Installer.Core.Interfaces;
using Prism.Events;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Resources;
using System.Windows;
using System.Windows.Controls;
using ExportPlayerCustomInstaller.Model;

#endregion

namespace ExportPlayerCustomInstaller
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    [Export("MainWindow", typeof(Window))]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public partial class MainWindow : Window
    {
        #region Private Members

        ResourceManager rm = new ResourceManager(typeof(Resources.ResourceStrings.Resources));

        #endregion

        #region Constructor

        [ImportingConstructor]
        public MainWindow([Import] MainWindowViewModel viewModel,
                          [Import] EventAggregator eventAggregator,
                          [ImportMany(typeof(IWizardPage))] IEnumerable<Lazy<IWizardPage>> pages)
        {
            DataContext = viewModel;
            VisitedPages = new Stack<UserControl>();
            Pages = new Dictionary<string, UserControl>();


            // Close the dispatcher when the window is closed
            Closed += (sender, e) => Dispatcher.InvokeShutdown();

            InitializeComponent();
            InitializePages(pages);

            // Register for navigation events.
            EventingService = eventAggregator;
            EventingService.GetEvent<RequestWizardPageEvent>().Subscribe(OnRequestShowPage);
            EventingService.GetEvent<RequestErrorPageEvent>().Subscribe(OnRequestShowErrorPage);
            EventingService.GetEvent<RequestPreviousPageEvent>().Subscribe(OnShowPreviousPage);
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets and sets the current wizard page.
        /// </summary>
        private UserControl CurrentPage { get; set; }

        /// <summary>
        /// Gets and sets the available wizard pages.
        /// </summary>
        private Dictionary<string, UserControl> Pages { get; set; }

        /// <summary>
        /// Gets and sets the stack of previously visited pages. Does
        /// not include the current page.
        /// </summary>
        private Stack<UserControl> VisitedPages { get; set; }


        /// <summary>
        /// Gets and sets the eventing service.
        /// </summary>
        private EventAggregator EventingService { get; set; }

        /// <summary>
        /// Gets and sets the eventing service.
        /// </summary>
        private BundleModel Model { get; set; }

        #endregion

        #region EventHandlers

        /// <summary>
        /// Called when the user clicks the Left mouse button down.  This will allow the window to
        /// be draggable.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            // Allow us to drag the window.
            base.OnMouseLeftButtonDown(e);
            DragMove();
        }

        /// <summary>
        /// Called when and show page event is generated.
        /// </summary>
        /// <param name="pageName"></param>
        private void OnRequestShowPage(string pageName)
        {
            ShowNextPageByName(pageName);
        }

        #endregion

        #region Navigation Methods

        /// <summary>
        /// Called when a request to show the error page is received
        /// </summary>
        /// <param name="error">Error page content</param>
        private void OnRequestShowErrorPage(ErrorInfo error)
        {
            Dispatcher.BeginInvoke((Action)(() =>
            {
                UserControl page = null;

                if (Pages.TryGetValue(typeof(ErrorPageView).Name, out page))
                {
                    // Modify the page's error message
                    var control = page as UserControl;
                    var errorVM = control.DataContext as ErrorPageViewModel;
                    errorVM.ErrorHeading = error.Header;
                    errorVM.ErrorSubHeading = error.Message;
                    pageControl.ShowPage(control);
                }
            }));
        }

        /// <summary>
        /// Requests to show the previously visited wizard page.
        /// </summary>
        public void OnShowPreviousPage()
        {

            Dispatcher.BeginInvoke((Action)(() =>
            {
                if (VisitedPages.Count > 0)
                {
                    // Grab the last visited page.
                    UserControl prev = VisitedPages.Pop();
                    CurrentPage = prev;

                    if (prev.DataContext is WizardPageViewModel)
                    {
                        // The wizard page's data context is a WizardPageViewModel call
                        // it's OnNavigateBack method.
                        (prev.DataContext as WizardPageViewModel).OnNavigateBack();
                        (prev.DataContext as WizardPageViewModel).SetPageTexts(rm);
                        (prev.DataContext as WizardPageViewModel).SetPageButtonTexts(rm);
                    }

                    pageControl.ShowPage(prev);
                }
            }));
        }

        private void ShowNextPageByName(string name)
        {
            Dispatcher.BeginInvoke((Action)(() =>
            {
                UserControl page = null;

                if (Pages.TryGetValue(name, out page))
                {
                    if (CurrentPage != null)
                    {
                        VisitedPages.Push(CurrentPage);
                    }

                    CurrentPage = page;

                    if (CurrentPage.DataContext is WizardPageViewModel)
                    {
                        // The page's data context is a wizard page view model.
                        // lets call its OnNavigateTo method.
                        (CurrentPage.DataContext as WizardPageViewModel).OnNavigateTo();
                        (CurrentPage.DataContext as WizardPageViewModel).SetPageTexts(rm);
                        (CurrentPage.DataContext as WizardPageViewModel).SetPageButtonTexts(rm);
                    }

                    pageControl.ShowPage(CurrentPage);
                }
            }));
        }

        #endregion

        #region IDisposable

        public void Dispose()
        {
            EventingService.GetEvent<RequestWizardPageEvent>().Unsubscribe(OnRequestShowPage);
            EventingService.GetEvent<RequestErrorPageEvent>().Unsubscribe(OnRequestShowErrorPage);
            EventingService.GetEvent<RequestPreviousPageEvent>().Unsubscribe(OnShowPreviousPage);
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Initializes the available wizard pages.
        /// </summary>
        /// <param name="pages"></param>
        private void InitializePages(IEnumerable<Lazy<IWizardPage>> pages)
        {
            pages.ToList().ForEach((page) =>
            {
                Pages.Add(page.Value.PageName, page.Value as UserControl);
            });
        }

        #endregion
    }
}
