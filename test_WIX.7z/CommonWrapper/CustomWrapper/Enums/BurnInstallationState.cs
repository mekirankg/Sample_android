﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */

namespace Installer.Core.Enums
{
    /// <summary>
    /// Enum with possible states of the Burn installation.
    /// </summary>
    public enum BurnInstallationState
    {
        /// <summary>
        /// Installation of the product is being initialized.
        /// </summary>
        Initializing,

        /// <summary>
        /// The installation of the product already exists on the computer.
        /// </summary>
        Present,

        /// <summary>
        /// The product is not installed on the computer.
        /// </summary>
        NotPresent,

        /// <summary>
        /// A newer version of the product was already installed on this computer.        
        /// </summary>
        Newer,

        /// <summary>
        /// The installation of the product is running.
        /// </summary>
        Applying,

        /// <summary>
        /// The installation of the product is done.
        /// </summary>
        Applied,

        /// <summary>
        /// The installation has failed.
        /// </summary>
        Failed

    }
}
