﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

namespace Installer.Core.Enums
{
    /// <summary>
    /// Enum to notify which Action in the page is executed to the custom installer.
    /// </summary>
    public enum PageButtons
    {
        //Indicates the generic actions in each user control pages.
        Action1,
        Action2,
        Action3,
    }
}
