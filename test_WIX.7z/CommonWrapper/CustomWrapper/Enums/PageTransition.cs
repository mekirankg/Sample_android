﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

namespace Installer.Core.Enums
{
    /// <summary>
    /// The available page transitions.
    /// </summary>
    public enum PageTransition
    {
        /// <summary>
        /// Disables any page transition animations.
        /// </summary>
        NoAnimation,

        /// <summary>
        /// Fades the wizard pages in and out on page transitions.
        /// </summary>
        Fade,

        /// <summary>
        /// Slides the wizard pages in and out on page transitions.
        /// </summary>
        Slide,

        /// <summary>
        /// Fades and slides the pages in and out on page transitions.
        /// </summary>
        FadeAndSlide,

        /// <summary>
        /// Fades and slides the pages in and out on page transitions in reverse order.
        /// </summary>
        ReverseFadeAndSlide
    }
}
