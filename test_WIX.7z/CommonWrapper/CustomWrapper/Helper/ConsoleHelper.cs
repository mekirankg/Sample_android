﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region NameSpaces

using System;
using System.Collections.Generic;
using System.Linq;

#endregion

namespace Installer.Core.Helper
{
  public sealed class ConsoleHelper
    {
        #region Properties

        public static Dictionary<string,string> CmdOptions { get; set; }
        
        #endregion

        #region Public Methods

        /// <summary>
        /// Extract and assign MSI properties 
        /// </summary>
        /// <param name="commandLineArguments">command line arguments</param>
        public static void ExtractMsiProperties(string[] commandLineArguments)
        {
            var advancedOptionsDictionary = new Dictionary<string, string>();
            foreach (string item in commandLineArguments)
            {
                if (item.Contains('='))
                {
                    List<string> list = new List<string>(item.Split('='));
                    advancedOptionsDictionary.Add(list[0], list[1]);
                }
            }
            try
            {
                CmdOptions = advancedOptionsDictionary;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        #endregion
    }
}
