﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region NameSpaces

using System;
using System.Collections.Generic;
using System.IO;
using System.Security.AccessControl;
using System.Security.Principal;

#endregion

namespace Installer.Core.Helper
{
    public class DirectoryHelper
    {
        #region Public Methods

        /// <summary>
        /// Removes all the contents of the directory except for directories passed
        /// as parameters. Will scan for all files and removes each of them.
        /// </summary>
        /// <param name="path">Directory path to be deleted</param>
        /// <param name="args">Array of directory names that should not be deleted</param>
        public void CleanUpDirectoryWithExemptions(string path, params String[] args)
        {
            var foldersExempted = new List<string>(args);
            foldersExempted = foldersExempted.ConvertAll(d => d.ToLower());

            DirectoryInfo directory = new DirectoryInfo(path);
            if (directory.Name.ToLower() != "data")
            {
                // Scan all files in the current path and delete each files.
                foreach (FileInfo file in directory.GetFiles())
                {
                    file.Attributes &= ~System.IO.FileAttributes.ReadOnly;
                    string name = file.Name;
                    name = name.ToLower();
                    file.Delete();
                }

                DirectoryInfo[] subDirectories = directory.GetDirectories();
                foreach (DirectoryInfo subDirectory in subDirectories)
                {
                    subDirectory.Attributes &= ~System.IO.FileAttributes.ReadOnly;
                    if (!foldersExempted.Contains(subDirectory.Name.ToLower()))
                    {
                        subDirectory.Delete();
                    }
                }
            }
        }

        /// <summary>
        /// Creates the folder at the specified path and sets ACL if it does not exist.
        /// </summary>
        public void CreateFolders(string path)
        {
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
                AddDirectorySecurity(path, FileSystemRights.FullControl, AccessControlType.Allow);
            }
        }

        /// <summary>
        /// Adds an ACL entry on the specified directory for Everyone.
        /// </summary>
        public void AddDirectorySecurity(string FileName, FileSystemRights Rights, AccessControlType ControlType)
        {
            // Create a new DirectoryInfo object.
            DirectoryInfo dInfo = new DirectoryInfo(FileName);

            // Get a DirectorySecurity object that represents the 
            // current security settings.
            DirectorySecurity dSecurity = dInfo.GetAccessControl();

            // Use the Security Identifier over string to support other languages.
            SecurityIdentifier everyone = new SecurityIdentifier(WellKnownSidType.WorldSid, null);

            // Add the FileSystemAccessRule to the security settings. 
            dSecurity.AddAccessRule(new FileSystemAccessRule(everyone,
                                                            Rights,
                                                            ControlType));

            // Set the new access settings.
            dInfo.SetAccessControl(dSecurity);
        }

        /// <summary>
        /// Delete files and folders in the  directory.
        /// </summary>
        /// <param name="path">Directory to delete</param>
        public void DeleteDirectory(string path)
        {
            try
            {
                if (!string.IsNullOrEmpty(path))
                {
                    if (Directory.Exists(path))
                    {
                        Directory.Delete(path, true);
                    }
                }
            }
            catch (Exception)
            {
            }
        }

        /// <summary>
        /// Delete backup directory after copying to install directory. 
        /// </summary>
        /// <param name="path"> Backup directory path</param>
        /// <param name="backupDir"> Source directory</param>
        /// <param name="targetDir"> Target directory</param>
        public void DeleteBackupDirectory(string sourcePath, string commonDataDir, DirectoryInfo backupDir, DirectoryInfo targetDir)
        {
            try
            {
                if (Directory.Exists(Path.Combine(sourcePath, commonDataDir)))
                {
                    foreach (FileInfo fi in backupDir.GetFiles())
                    {
                        fi.CopyTo(Path.Combine(targetDir.FullName, fi.Name), true);
                    }

                    DeleteDirectory(Path.Combine(sourcePath, commonDataDir));

                }
            }
            catch (Exception)
            {
            }
        }

        /// <summary>
        /// Delete Logs directory of Application. Just to make it more user friendly. 
        /// </summary>
        /// <param name="logDir">Logs directory path</param>
        public void DeleteLogDirectory(string logDir)
        {
            try
            {
                if (Directory.Exists(logDir))
                {
                    DeleteDirectory(logDir);
                }
            }
            catch (Exception)
            {
            }
        }

        /// <summary>
        /// Copy file and folders to the Install directory.
        /// </summary>
        /// <param name="source"> Source directory</param>
        /// <param name="target"> Destination directory</param>
        public void RestoreFiles(DirectoryInfo source, DirectoryInfo target)
        {
            // Copy each file into the Install directory.
            foreach (FileInfo fi in source.GetFiles())
            {
                fi.CopyTo(Path.Combine(target.FullName, fi.Name), true);
            }

            // Copy each subdirectory using recursion.
            foreach (DirectoryInfo diSourceSubDir in source.GetDirectories())
            {
                DirectoryInfo nextTargetSubDir = target.CreateSubdirectory(diSourceSubDir.Name);
                RestoreFiles(diSourceSubDir, nextTargetSubDir);
            }
        }

        /// <summary>
        /// Returns a new path relative to the ProgramFiles directory.
        /// </summary>
        /// <param name="relPath"></param>
        /// <returns></returns>
        public string GetProgramFilesFolder(string relPath)
        {
            var parent = Environment.ExpandEnvironmentVariables(Core.Constants.ENVIRONMENT_VAR_PRGM_FILES);
            return Path.Combine(parent, relPath);
        }

        /// <summary>
        /// Returns a new path relative to the ProgramFiles directory. 
        /// </summary>
        /// <param name="relPath"></param>
        /// <returns></returns>
        public string GetProgram64FilesFolder(string relPath)
        {
            var parent = Environment.ExpandEnvironmentVariables(Core.Constants.ENVIRONMENT_VAR_PRGM64_FILES);
            return Path.Combine(parent, relPath);
        }

        /// <summary>
        /// Sanitizes directory path by removing trailing '\' characters.
        /// </summary>
        /// <param name="path">The path to sanitize</param>
        /// <returns>Sanitized path if it is set; otherwise the path passed in is returned</returns>
        public string SanitizePath(string path)
        {
            // Because of the following WIX bug we must also trim the trailing '\' character otherwise we end up with
            // hundreds of bundle processes and the installer eventually fails but the processes keep spawning.
            // https://sourceforge.net/p/wix/bugs/3190/
            return string.IsNullOrEmpty(path) ? path : path.TrimEnd('\\');
        }

        /// <summary>
        /// Returns a new path relative to the ProgramData directory.
        /// </summary>
        /// <param name="relPath"></param>
        /// <returns></returns>
        public string GetProgramDataFolder(string relPath)
        {
            var parent = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
            return Path.Combine(parent, relPath);
        }

        #endregion
    }
}
