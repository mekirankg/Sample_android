﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */

#region NameSpaces

using Microsoft.Win32;
using System;

#endregion

namespace Installer.Core.Helper
{
    public static class RegistryHelper
    {
        #region Public Methods

        /// <summary>
        /// Sets a value in the 64-bit registry.
        /// </summary>
        /// <param name="hive">The registry hive.</param>
        /// <param name="subKey">The subkey (e.g. @"SOFTWARE\Pelco\OpsCenter")</param>
        /// <param name="valueName">The name of the value to set (e.g. "InstallDir")</param>
        /// <param name="value">The value to set.</param>
        public static void SetValue(RegistryHive hive, string subKey, string valueName, object value)
        {
            using (RegistryKey baseKey = RegistryKey.OpenBaseKey(hive, RegistryView.Registry64))
            {
                using (RegistryKey key = baseKey.OpenSubKey(subKey, true))
                {
                    if (key == null)
                    {
                        using (RegistryKey regKey = baseKey.CreateSubKey(subKey))
                        {
                            regKey.SetValue(valueName, value);
                        }
                    }
                    else
                    {
                        key.SetValue(valueName, value);
                    }
                }
            }
        }

        /// <summary>
        /// Gets a value from the 64-bit registry and returns the string value.
        /// </summary>
        /// <param name="hive">The registry hive.</param>
        /// <param name="subKey">The subkey (e.g. @"SOFTWARE\Pelco\OpsCenter")</param>
        /// <param name="valueName">The name of the value to set (e.g. "InstallDir")</param>
        public static object GetValue(RegistryHive hive, string subKey, string valueName)
        {
            object keyValue = null;
            using (RegistryKey baseKey = RegistryKey.OpenBaseKey(hive, RegistryView.Registry64))
            {
                using (RegistryKey key = baseKey.OpenSubKey(subKey, false))
                {
                    try
                    {
                        keyValue = key.GetValue(valueName);
                    }
                    catch (NullReferenceException ex)
                    {
                        throw new InvalidOperationException(string.Format("Could not find the registry value {0}.", valueName), ex);
                    }
                }
            }
            return keyValue;
        }

        /// <summary>
        /// Delete registry entry of installers
        /// </summary>
        public static void DeleteRegistry(string regpath)
        {
                RegistryKey key = Registry.CurrentUser.OpenSubKey(regpath, true);
                Registry.CurrentUser.DeleteSubKeyTree(regpath);
                key.Close();
        }

        #endregion
    }
}

