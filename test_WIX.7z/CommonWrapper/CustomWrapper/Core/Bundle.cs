﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */

#region Namespaces

using System;
using System.Collections.Generic;
using System.Xml.Serialization;

#endregion

namespace Installer.Core.Core
{
    /// <summary>
    /// Class holds the bundle information.
    /// </summary>
    [XmlRoot("BootstrapperApplicationData", IsNullable = false, Namespace = "http://schemas.microsoft.com/wix/2010/BootstrapperApplicationData")]
    public class Bundle
    {
        #region Properties

        [XmlIgnore]
        public Version Version { get; internal set; }

        [XmlElement("WixBundleProperties")]
        public BundleAttributes Attributes { get; set; }

        [XmlElement("WixPackageProperties")]
        public List<Package> Packages;

        #endregion
    }
}
    