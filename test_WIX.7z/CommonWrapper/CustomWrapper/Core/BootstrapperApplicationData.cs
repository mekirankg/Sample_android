﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespaces
using System;
using System.IO;
using System.Reflection;
using System.Xml;
using System.Xml.Serialization;
#endregion

namespace Installer.Core.Core
{
    /// <summary>
    /// Extracts the bootstrapper data from the BootstrapperData.xml file.
    /// <remarks>
    /// <para>
    /// To view the BootstrapperApplicationData.xml you can extract it from your
    /// bundle exe using 'dark.exe -x TargetDirectory'
    /// </para>
    /// </remarks>
    /// </summary>
    public sealed class BootstrapperApplicationData
    {

        #region Private Members

        private const string dataFile = "BootstrapperApplicationData.xml";

        private static string appDataFile;

        #endregion

        #region Constructor

        private BootstrapperApplicationData()
        {

        }

        #endregion

        #region Properties

        /// <summary>
        /// Returns the file location of the BootstrapperApplicationData.xml file.
        /// </summary>
        public static string FileLocation
        {
            get
            {
                if (appDataFile == null)
                {
                    var folder = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                    appDataFile = Path.Combine(folder, dataFile);
                }

                return appDataFile;
            }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Retrieves information about the bundle to be installed.
        /// </summary>
        /// <returns></returns>
        public static Bundle GetBundleInfo(Version version)
        {
            // Read the BootstrapperApplicationData.xml and create the BundleInfo object from that XML.
            var xmlSerializer = new XmlSerializer(typeof(Bundle));
            using (var fileStream = new FileStream(FileLocation, FileMode.Open))
            {
                var reader = XmlReader.Create(fileStream);
                var bundle = (Bundle)xmlSerializer.Deserialize(reader);
                bundle.Version = version;

                return bundle;
            }
        }

        #endregion
    }
}
