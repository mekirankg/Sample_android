﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespaces
using System.Diagnostics;
#endregion

namespace Installer.Core.Core
{
    /// <summary>
    /// Class contains common utility functions
    /// </summary>
    public class Util
    {
        #region public methods

        /// <summary>
        /// Opens a web browser with the following url.
        /// </summary>
        /// <param name="url">The url to open the browser to</param>
        public void OpenWebBrowser(string url)
        {
            Process.Start(new ProcessStartInfo(url));
        }

        /// <summary>
        /// Opens a file
        /// </summary>
        /// <param name="file">The file to open</param>
        public void OpenFile(string file)
        {
            // These really do the same thing in the background but this method
            // just helps keep things more readable.
            OpenWebBrowser(file);
        }

        #endregion

    }
}
