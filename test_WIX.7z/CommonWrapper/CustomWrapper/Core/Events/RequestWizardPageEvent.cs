﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */

#region Namespaces
using Prism.Events;
#endregion

namespace Installer.Core.Core.Events
{
    #region Event Type

    /// <summary>
    /// Event used to request to show wizard page
    /// </summary>
    public class RequestWizardPageEvent : PubSubEvent<string>
    {

    }

    #endregion
}
