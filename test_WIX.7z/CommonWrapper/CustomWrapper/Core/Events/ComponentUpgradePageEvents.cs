﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespaces
using Installer.Core.Enums;
using Prism.Events;
#endregion
namespace Installer.Core.Core.Events
{
    #region Event Types

    /// <summary> 
    /// Event type for notify Component Upgrade Page Click Event on Custom installer.
    /// </summary>
    public class ComponentUpgradePageClickEvent : PubSubEvent<PageButtons>
    {
    }

    /// <summary>
    /// Event type for notify Error Page Log File Click Event on Custom installer.
    /// </summary>
    public class ErrorPageLogFileClickEvent : PubSubEvent<string>
    {
    }

    #endregion
}
