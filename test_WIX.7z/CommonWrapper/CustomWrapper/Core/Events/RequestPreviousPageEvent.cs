﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */

#region Namespaces
using Prism.Events;
#endregion

namespace Installer.Core.Core.Events
{
    #region Event Type

    /// <summary>
    /// Event to request to show the wizard's previously visited page.
    /// </summary>
    public class RequestPreviousPageEvent : PubSubEvent
    {

    }

    #endregion
}
