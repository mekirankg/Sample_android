﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */

#region Namespaces
using Prism.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks; 
#endregion

namespace Installer.Core.Core.Events
{
    #region Event Type

    /// <summary>
    /// Event type for properties received in uninstall finish Page from Custom installer.
    /// </summary>
    public class UninstallPageFinishPropertiesEvents: PubSubEvent<Dictionary<string, object>>
    {

    }

    #endregion
}
