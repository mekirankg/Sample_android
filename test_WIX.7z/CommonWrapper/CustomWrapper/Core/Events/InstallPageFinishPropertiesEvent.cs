﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */
#region Namespaces
using Prism.Events;
using System.Collections.Generic;
#endregion

namespace Installer.Core.Core.Events
{
    #region Event Types

    /// <summary>
    /// Event type for Install Page Finish.
    /// </summary>
    public class InstallPageFinishPropertiesEvent : PubSubEvent<Dictionary<string, object>>
    {

    }

    #endregion
}
