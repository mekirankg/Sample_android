﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespaces

using System.IO;
using System.Linq;

#endregion

namespace Installer.Core.Core
{
    /// <summary>
    /// Validate Directory path
    /// </summary>
    public class PathValidator
    {
        #region Public Methods

        /// <summary>
        /// Determines if the Path is valid.
        /// </summary>
        /// <param name="path">Path to validate</param>
        /// <returns></returns>
        public static string ValidatePath(string path)
        {
            if (!string.IsNullOrEmpty(path))
            {
                path = path.Trim();
                char[] invalidPathChars = Path.GetInvalidPathChars();
                var match = path.IndexOfAny(invalidPathChars) != -1;
                if (match || !Path.IsPathRooted(path) || (path.Contains("/")))
                {
                    return Resources.ResourceStrings.Resources.strInvalidPath;
                }
                else if (!IsDriveValid(path))
                {
                    return Resources.ResourceStrings.Resources.strInvalidPath;
                }
                else
                {
                    try
                    {
                        Path.GetFullPath(path);

                        /// Check the rootdrive contains a forward or backward slash
                        /// enabling forward slash and preventing backward slash
                        string rootDrive = path.Substring(0, 3);
                        if (!rootDrive.Contains(@"\"))
                        {
                            return Resources.ResourceStrings.Resources.strInvalidPath;
                        }
                    }
                    catch (System.Exception)
                    {
                        return Resources.ResourceStrings.Resources.strInvalidPath;
                    }
                }
                return string.Empty;
            }
            return Resources.ResourceStrings.Resources.strInvalidPath;
        }

        /// <summary>
        /// Determines if the drive is valid.
        /// </summary>
        /// <param name="drive">Drive to validate</param>
        /// <returns></returns>
        public static bool IsDriveValid(string drive)
        {
            bool isValid = true;
            try
            {
                var root = Path.GetPathRoot(drive);
                var driveInfo = new DriveInfo(root);
                isValid = DriveInfo.GetDrives().Any(x => x.VolumeLabel == driveInfo.VolumeLabel);
            }
            catch (DriveNotFoundException)
            {
                isValid = false;
            }
            catch (System.Exception)
            {
                isValid = false;
            }

            return isValid;
        }

        /// <summary>
        /// Returns the Drive info for the provided path
        /// </summary>
        /// <param name="path">Provided path</param>
        /// <returns></returns>
        public static DriveInfo GetDriveInfoFromPath(string path)
        {
            try
            {
                var root = Path.GetPathRoot(path);
                var driveInfo = new DriveInfo(root);
                return driveInfo;
            }
            catch (System.Exception)
            {
                return null;
            }
        }

        #endregion
    }
}
