﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namepaces

using Microsoft.Win32;
using System;
using System.Linq;
using Installer.Core.Enums;
using Microsoft.Tools.WindowsInstallerXml.Bootstrapper;
using System.Windows;

#endregion

namespace Installer.Core.Core
{
    /// <summary>
    /// Retrieves information about an existing installation.  Depending on the
    /// registry keys is not the best idea but because WiX 3.8 does not provide
    /// the upgrade code or version in the BootstrapperApplicationData.xml we have
    /// no choice by to rely on it.  Once everything is updated to WiX 3.10 we will
    /// be able to use the MsiRelatedProducts call to check for versions and to
    /// determine if things are installed.
    /// </summary>
    public class InstallationInfo
    {
        #region Public Methods

        /// <summary>
        /// Returns System Platform details
        /// </summary>
        /// <returns></returns>
        public RegistryView GetSystemPlatform()
        {
            var systemPlatform = new RegistryView();

            if (Environment.Is64BitOperatingSystem)
            {
                systemPlatform = RegistryView.Registry64;
            }
            else
            {
                systemPlatform = RegistryView.Registry32;
            }
            return systemPlatform;
        }

        /// <summary>
        /// Indicates if the Application is currently installed.
        /// </summary>
        /// <param name="regKey">Accepts Key for searching</param>
        /// <param name="keyName">Accepts Key value name for searching</param>
        /// <param name="registryHive">Accepts type of RegistryHive for searching</param>
        /// <returns>True if installed else false</returns>
        public bool IsApplicationInstalled(string regKey, string keyName, RegistryHive registryHive)
        {
            using (var key = RegistryKey.OpenBaseKey(registryHive, GetSystemPlatform()).OpenSubKey(regKey))
            {
                if (key != null)
                {
                    var value = key.GetValue(keyName);
                    return value != null ? true : false;
                }
                return false;
            }
        }

        /// <summary>
        /// Retrieves the installation folder of the Application install.
        /// </summary>
        /// <returns>install folder or null if Application is not installed</returns>
        public string GetApplicationInstallFolder(string regKey, string keyName, RegistryHive registryHive)
        {
            using (var key = RegistryKey.OpenBaseKey(registryHive, GetSystemPlatform()).OpenSubKey(regKey))
            {
                if (key != null)
                {
                    var value = key.GetValue(keyName);
                    return value != null ? value.ToString() : null;
                }

                return null;
            }
        }

        /// <summary>
        /// Retrieves the version of the Application install. If the version is not set then a
        /// default version is returned
        /// </summary>
        /// <returns>version or null if Application is not installed</returns>
        public Version GetApplicationVersion(string Path, string keyName, RegistryHive registryHive)
        {
            using (var key = RegistryKey.OpenBaseKey(registryHive, GetSystemPlatform()).OpenSubKey(Path))
            {
                if (key != null)
                {
                    var value = key.GetValue(keyName);

                    return value != null ? new Version(value.ToString()) : new Version();
                }

                return null;
            }
        }

        /// <summary>
        /// Cancel silent uninstall if already installed the same version
        /// </summary>
        public bool SkipSilentUninstall(Command cmd, InstallationMode mode, string regPath, Version bundleVersion, string keyName, RegistryHive registryHive)
        {
            string[] commandLineArguments = Environment.GetCommandLineArgs();
            if (commandLineArguments.Count() > 0)
            {
                var value = commandLineArguments.FirstOrDefault(p => p.Contains("uninstall"));

                if (value == null && cmd.Display == Display.None && mode == InstallationMode.Uninstall)
                {
                    return true;
                }
                else if (cmd.Display == Display.None)
                {
                    // Checks whether the bundle version is less than the installed version and skips the package execution.
                    if (regPath != string.Empty && bundleVersion != null)
                    {
                        Version installedVersion = GetApplicationVersion(regPath, keyName, registryHive);
                        if (bundleVersion < installedVersion)
                        {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        #endregion
    }
}
