﻿

#region Namespaces

using Microsoft.Win32;
/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/
using System;

#endregion

namespace Installer.Core.Core.IPC
{
    /// <summary>
    /// UpgradeState wrapper class.  This class wraps the Upgrade state to make it easier to work
    /// with.
    /// </summary>
    public class UpgradeStateWrapper
    {
        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="state">The state info to initialize from</param>
        public UpgradeStateWrapper(UpgradeState state)
        {
            State = state;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="installInfo">Install info containing product versions</param>
        public UpgradeStateWrapper(InstallationInfo installInfo,string path, string keyname, RegistryHive registryHive)
        {
            var application = installInfo.GetApplicationVersion(path, keyname, registryHive);

            var state = new UpgradeState();

            if (application != null)
            {
                state.MajorVersion = application.Major;
                state.MinorVersion = application.Minor;
                state.PatchVersion = application.Build;
                state.BuildVersion = application.Revision;
            }

            state.HasData = true; // Indicate that the data is valid

            State = state;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the wrapped UpgradeState.
        /// </summary>
        public UpgradeState State { get; private set; }

        /// <summary>
        /// Gets the Application version.
        /// </summary>
        public Version ApplicationVersion
        {
            get
            {
                return new Version(State.MajorVersion, State.MinorVersion, State.PatchVersion, State.BuildVersion);
            }
        }

        #endregion
    }
}
