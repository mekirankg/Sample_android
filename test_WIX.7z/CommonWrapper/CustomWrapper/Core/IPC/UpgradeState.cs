﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */
#region Namespaces

using System.Runtime.InteropServices;

#endregion

namespace Installer.Core.Core.IPC
{
    /// <summary>
    /// Holds upgrade state prior to the upgrade. This data is used by the upgrade
    /// uninstall process to determine if we should uninstall a product or not.
    /// </summary>
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct UpgradeState
    {
        #region Public Members

        /// <summary>
        /// Flag indicating if data was set.  Shared memory
        /// get calls will return a default struct this tells
        /// us if the data is valid or not.
        /// </summary>
        public bool HasData;
        public int MajorVersion;
        public int MinorVersion;
        public int PatchVersion;
        public int BuildVersion;

        #endregion

    }
}
