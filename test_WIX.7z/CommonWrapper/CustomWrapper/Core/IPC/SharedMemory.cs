﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */

#region Namespaces

using System;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Threading;

#endregion

namespace Installer.Core.Core.IPC
{
    /// <summary>
    /// A SharedMemory instance allows different processes to share memory.
    /// 
    /// Type 'T' must be a simple struct that contains no references or nested structures.
    /// </summary>
    /// <typeparam name="T">The type of structure to share</typeparam>
    public class SharedMemory<T> : IDisposable where T : struct
    {
        #region Private Members

        private string memId = string.Empty;
        private int size;
        private string name;
        private Mutex mutex;
        private bool isOpen;
        private MemoryMappedFile mmf;
        MemoryMappedFileSecurity security;
        private MemoryMappedViewAccessor accessor;

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="name">The global shared memory name</param>
        /// <param name="size">The allocation size of the shared memory</param>
        public SharedMemory(string memoryName, int memorySize)
        {
            name = memoryName;
            size = memorySize;
            isOpen = false;
            //  memId = memoryId;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets and sets the shared structure
        /// </summary>
        public T? Data
        {
            get
            {
                mutex.WaitOne();
                try
                {
                    if (!isOpen)
                    {
                        throw new InvalidOperationException("Must open SharedMemory before using it");
                    }

                    T data;
                    accessor.Read(0, out data);

                    return data;
                }
                catch (Exception)
                {
                    return null;
                }
                finally
                {
                    mutex.ReleaseMutex();
                }
            }

            set
            {
                mutex.WaitOne();
                try
                {
                    if (!isOpen)
                    {
                        throw new InvalidOperationException("Must open SharedMemory before using it");
                    }

                    if (value.HasValue)
                    {
                        T data = value.Value;
                        accessor.Write<T>(0, ref data);
                    }
                }
                finally
                {
                    mutex.ReleaseMutex();
                }
            }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Initializes and allocates the shared memory
        /// </summary>
        /// <returns>true if Open succeeds, false otherwise</returns>
        public bool Open()
        {
            try
            {
                if (isOpen)
                {
                    return true;
                }

                security = new MemoryMappedFileSecurity();
                SecurityIdentifier everyone = new SecurityIdentifier(WellKnownSidType.WorldSid, null);
                security.AddAccessRule(new AccessRule<MemoryMappedFileRights>(everyone,
                                                                               MemoryMappedFileRights.FullControl,
                                                                               AccessControlType.Allow));

                mmf = MemoryMappedFile.CreateOrOpen(name,
                                                     size,
                                                     MemoryMappedFileAccess.ReadWrite,
                                                     MemoryMappedFileOptions.DelayAllocatePages,
                                                     security,
                                                     HandleInheritability.Inheritable);

                accessor = mmf.CreateViewAccessor(0, size, MemoryMappedFileAccess.ReadWrite);
                mutex = new Mutex(false, memId);

                isOpen = true;

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        #endregion

        #region IDisposable

        /// <summary>
        /// Closes and deallocates resources.
        /// </summary>
        public void Dispose()
        {
            if (isOpen)
            {
                mmf.Dispose();
                accessor.Dispose();
                mutex.Dispose();
                isOpen = false;
            }
        }

        #endregion
    }
}
