﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */
using System;

namespace ExportPlayerCustomInstaller.Core
{
    /// <summary>
    /// Interface to log messages and events.
    /// </summary>
    public interface ILogger
    {
        /// <summary>
        /// Log error message.
        /// </summary>
        /// <param name="msg">The message to log</param>
        void LogError(string msg);

        /// <summary>
        /// Log standard message.
        /// </summary>
        /// <param name="msg">The message to log</param>
        void LogStandard(string msg);

        /// <summary>
        /// Log debug message.
        /// </summary>
        /// <param name="msg">The message to log</param>
        void LogDebug(string msg);

        /// <summary>
        /// Log verbose message.
        /// </summary>
        /// <param name="msg">The message to log</param>
        void LogVerbose(string msg);

        /// <summary>
        /// Log standard event.
        /// </summary>
        /// <param name="eventName">The name of the event being logged</param>
        /// <param name="args">The event args to log</param>
        void LogStandardEvent(string eventName, EventArgs args = null);

        /// <summary>
        /// Log debug event.
        /// </summary>
        /// <param name="eventName">The name of the event being logged</param>
        /// <param name="args">The event args to log</param>
        void LogDebugEvent(string eventName, EventArgs args = null);

        /// <summary>
        /// Log verbose event.
        /// </summary>
        /// <param name="eventName">The name of the event being logged</param>
        /// <param name="args">The event args to log</param>
        void LogVerboseEvent(string eventName, EventArgs args = null);
    }
}
