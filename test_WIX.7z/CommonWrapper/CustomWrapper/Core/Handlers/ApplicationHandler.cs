﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespaces
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.Composition;
using System.Diagnostics;
using System.Linq;
using Installer.Core.Interfaces;
#endregion

namespace Installer.Core.Core.Handler
{
    /// <summary>
    /// Manages the available Vx process that are discovered.  This class will allow user to
    /// receive events with Vx processes that are shutdown or request to have them shutdown. 
    /// </summary>
    [Export]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public class ApplicationHandler : IDisposable
    {
        #region Private Members

        private readonly object processLock = new object();
        private readonly object eventLock = new object();
        private readonly object listLock = new object();

        private bool isInitialized;
        private List<string> runningApps;
        private EventHandler applicationEventHandler;

        #endregion

        #region Public Members

        public List<string> installingApps;

        #endregion

        #region Constructor

        [ImportingConstructor]
        public ApplicationHandler(ILogger logger)
        {
            Logger = logger;

            runningApps = new List<string>();
            installingApps = new List<string>();
            isInitialized = false;

            // Init();
        }

        #endregion

        #region Event Handlers

        /// <summary>
        /// Register to receive an event when the Application process exits.
        /// </summary>
        public event EventHandler ApplicationExitedEvent
        {
            add
            {
                lock (eventLock)
                {
                    applicationEventHandler += value;
                }
            }

            remove
            {
                lock (eventLock)
                {
                    applicationEventHandler -= value;
                }
            }
        }

        #endregion

        #region Properties

        /// <summary>
        /// Indicates if any of the applications are running.
        /// </summary>
        public bool AreAnyApplicationsRunning
        {
            get
            {
                return IsApplicationRunning;
            }
        }

        /// <summary>
        /// Indicates if the Application process is running or not.
        /// </summary>
        public bool IsApplicationRunning { get; private set; }

        /// <summary>
        /// Returns a list of the currently running applications.
        /// </summary>
        public string[] RunningApplications
        {
            get
            {
                lock (listLock)
                {
                    return runningApps.ToArray();
                }
            }
        }

        /// <summary>
        /// Returns a list of the installing applications
        /// </summary>
        public string[] ApplicationsList
        {
            get
            {
                lock (listLock)
                {
                    return installingApps.ToArray();
                }
            }
        }

        /// <summary>
        /// Gets and sets the Export Application's process.
        /// </summary>
        private List<Process> ApplicationProcess { get; set; }

        /// <summary>
        /// Gets and sets the logger service.
        /// </summary>
        private ILogger Logger { get; set; }

        /// <summary>
        /// Gets or sets the list of process names.
        /// </summary>
        private ObservableCollection<ProcessAttributes> ProcessNames { get; set; }

        #endregion

        #region Public Methods

        /// <summary>
        /// Request to shutdown the Application process.  If it is running the process will shutdown otherwise
        /// this method is a no-op
        /// </summary>
        public void ShutdownAllApplications()
        {
            if (IsApplicationRunning && ApplicationProcess != null)
            {
                Logger.LogStandard("Received request to shutdown listed applications");
                ApplicationProcess.ForEach((process) =>
                {
                    if (!process.CloseMainWindow())
                    {
                        Logger.LogStandard(string.Format("Unable to gracefully shutdown the {0}, forcefully exiting the process", (process.ProcessName)));

                        process.Kill();
                    }
                });

            }
        }

        /// <summary>
        /// Initializes the ApplicationsManager.
        /// </summary>
        public void Init(ObservableCollection<ProcessAttributes> appProcesses, List<string> installingApps)
        {
            lock (processLock)
            {
                if (!isInitialized)
                {
                    ApplicationProcess = new List<Process>();
                    InitApplicationProcess(appProcesses);
                    foreach (string apps in installingApps)
                    {
                        this.installingApps.Add(apps);
                    }
                    isInitialized = true;
                }
            }
        }

        /// <summary>
        /// Reinitializes the ApplicationsManager.
        /// </summary>
        public void ReInit()
        {
            lock (processLock)
            {
                if (ApplicationProcess == null)
                {
                    InitApplicationProcess(ProcessNames);
                }
            }
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Initializes Applications process if it exists.
        /// </summary>
        /// <returns></returns>
        private void InitApplicationProcess(ObservableCollection<ProcessAttributes> applicationProcessNames)
        {
            lock (processLock)
            {
                try
                {
                    ProcessNames = applicationProcessNames;
                    foreach (ProcessAttributes process in applicationProcessNames)
                    {
                        var processes = Process.GetProcessesByName(process.ProcessName);
                        if (processes.Count() >= 1)
                        {
                            Logger.LogStandard(string.Format("Detected running {0} application, configuring process to be managed.", process.AppName));

                            processes[0].EnableRaisingEvents = true;
                            processes[0].Exited += ApplicationProcess_Exited;
                            // There should only ever be one process
                            ApplicationProcess.Add(processes[0]);

                            IsApplicationRunning = true;

                            lock (listLock)
                            {
                                runningApps.Add(process.AppName);
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    Logger.LogError(string.Format("Caught exception while configuring applications process, message: {0}", e.Message));
                }
            }
        }

        #endregion

        #region Process Exit handlers

        /// <summary>
        /// Called when the Applications process exits.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ApplicationProcess_Exited(object sender, EventArgs e)
        {
            Process process = sender as Process;
            var filtered = ProcessNames.FirstOrDefault(p => p.ProcessName.Equals(process.ProcessName));

            lock (processLock)
            {
                Logger.LogStandard(string.Format("Detected {0} process exit (shutdown)", filtered.AppName));

                IsApplicationRunning = false;
                ApplicationProcess = null;

                lock (listLock)
                {
                    runningApps.Remove(filtered.AppName);
                }

                lock (eventLock)
                {
                    try
                    {
                        applicationEventHandler?.Invoke(this, EventArgs.Empty);
                    }
                    catch (Exception ex)
                    {
                        Logger.LogError(string.Format("Caught exception invoking application exited handler, message: {0}", ex.Message));
                    }
                }
            }
        }

        #endregion

        #region IDisposable

        public void Dispose()
        {
            lock (processLock)
            {
                if (ApplicationProcess != null)
                {
                    foreach (Process process in ApplicationProcess)
                    {
                        var processes = Process.GetProcessesByName(process.ProcessName);
                        if (processes.Count() >= 1)
                        {
                            // There should only ever be one process         
                            processes[0].EnableRaisingEvents = false;
                            processes[0].Exited -= ApplicationProcess_Exited;
                        }
                    }
                }
            }
        }

        #endregion
    }
}
