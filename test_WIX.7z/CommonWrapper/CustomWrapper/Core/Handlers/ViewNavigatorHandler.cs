﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespaces
using Prism.Events;
using System.ComponentModel.Composition;
using Installer.Core.Core.Events;
using Installer.Core.Enums;
using System.Diagnostics;
#endregion

namespace Installer.Core.Core.Handler
{
    /// <summary>
    /// The view navigator is a service provided to request to show
    /// a wizard page.  This service is needed because we cannot use
    /// the WizardPageManager directly because it would cause a dependency
    /// cycle.  This service generates a request to the WizardPageManager
    /// to show a page.
    /// </summary>
    [Export]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public class ViewNavigatorHandler
    {
        #region Constructor

        [ImportingConstructor]
        public ViewNavigatorHandler(EventAggregator eventAgg)
        {
            EventingService = eventAgg;
        }

        #endregion

        #region Properties

        public EventAggregator EventingService { get; set; }

        /// <summary>
        /// Gets and sets flag indicating the Animation order
        /// </summary>
        public static bool IsReverseAnimationNeeded { get; set; } = false;

        #endregion

        #region Navigation methods

        /// <summary>
        /// To show the requested page
        /// </summary>
        public void ShowPage(string pageName)
        {
            RequestToShowPageByName(pageName);
        }

        /// <summary>
        /// Request to show the previously shown page.
        /// </summary>
        public void ShowPreviousPage()
        {
            EventingService.GetEvent<RequestPreviousPageEvent>().Publish();

            ///To change the  flow direction of the animation
            IsReverseAnimationNeeded = true;
        }

        /// <summary>
        /// Request to show the installer's error page
        /// </summary>
        /// <param name="header">The value of the header text to display</param>
        /// <param name="message">The value of the error message to display</param>
        public void ShowErrorPage(string header, string message)
        {
            EventingService.GetEvent<RequestErrorPageEvent>().Publish(new Installer.Core.Core.Events.ErrorInfo { Header = header, Message = message });
        }

        /// <summary>
        /// Helper method used to request to show a wizard page.
        /// </summary>
        /// <param name="name"></param>
        private void RequestToShowPageByName(string name)
        {
            EventingService.GetEvent<RequestWizardPageEvent>().Publish(name);
        }

        /// <summary>
        /// Generates the page button click event.
        /// </summary>
        /// <param name="btn">button type</param>
        /// <param name="pageType">Name of the page</param>
        public void GeneratePageEvent(PageButtons btn, string pageType)
        {
            switch (pageType)
            {
                case Constants.PAGE_NAME_HOME:
                    EventingService.GetEvent<HomePageClickEvent>().Publish(btn);
                    break;
                case Constants.PAGE_NAME_CONFIG:
                    EventingService.GetEvent<CustomConfigPageClickEvent>().Publish(btn);
                    break;
                case Constants.PAGE_NAME_PROGRESS:
                    EventingService.GetEvent<ProgressPageClickEvent>().Publish(btn);
                    break;
                case Constants.PAGE_NAME_UNINSTALL:
                    EventingService.GetEvent<UninstallPageClickEvent>().Publish(btn);
                    break;
                case Constants.PAGE_NAME_COMPONENT_UPGRADE:
                    EventingService.GetEvent<ComponentUpgradePageClickEvent>().Publish(btn);
                    break;
                default://No operation.
                    break;
            }
        }

        /// <summary>
        /// Generates the Config page notification events.
        /// </summary>
        /// <param name="applicationPath"></param>
        public void GenerateConfigPageEvent(string applicationPath)
        {
            EventingService.GetEvent<CustomConfigPageNotificationsEvent>().Publish(applicationPath);
        }

        /// <summary>
        /// Generates the error page log file click event.
        /// </summary>
        /// <param name="btn"></param>
        public void GenerateErrorPageLogFileClickEvent(string file)
        {
            EventingService.GetEvent<ErrorPageLogFileClickEvent>().Publish(file);
        }

        #endregion
    }
}
