﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespaces

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Markup;

#endregion

namespace Installer.Core.Core.Handler
{
    /// <summary>
    /// Selects the localization culture.
    /// </summary>
    public class CultureHandler
    {
        #region Private Members

        private static Dictionary<String, String> languages = new Dictionary<String, String>
        {
            { "ar", ("ar-SA") }, { "de", ("de-DE") }, { "es", ("es-ES") }, { "en", ("en-US") },
            { "fr", ("fr-FR") }, { "it", ("it-IT") }, { "ja", ("ja-JP") }, { "ko", ("ko-KR") },
            { "tr", ("tr-TR") }, { "pt", ("pt-BR") }, { "pl", ("pl-PL") }, { "zh", ("zh-CN") },
            { "ru", ("ru-RU") }
        };

        #endregion

        #region Public Methods

        /// <summary>
        /// Determines which culture to use for localization and sets the
        /// culture for WPF controls.
        /// </summary>
        /// <returns>The culture used for localization.</returns>
        public CultureInfo SetCulture()
        {
            //Localized application based on regional settings
            FrameworkElement.LanguageProperty.OverrideMetadata(
                   typeof(FrameworkElement),
                   new FrameworkPropertyMetadata(
                   XmlLanguage.GetLanguage(CultureInfo.CurrentCulture.IetfLanguageTag)));

            //Current Regional Settings.
            string regionalSettings = CultureInfo.CurrentCulture.ToString();
            var currentLocale = languages.FirstOrDefault(x => x.Value == regionalSettings).Value;

            //Get language here.
            //We found matching locale in our language dictionary
            if (currentLocale == null)
            {
                //Load main language file based on first two language code. Eg: "en", "es"
                var languageCode = languages.FirstOrDefault(x => x.Key == regionalSettings.Substring(0, 2)).Value;
                return (languageCode != null) ? new CultureInfo(languageCode) : CultureInfo.CurrentCulture;
            }
            else
            {
                return CultureInfo.CurrentCulture;
            }
        }

        #endregion
    }
}