﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */

#region Namespaces

using System.Xml.Serialization;

#endregion

namespace Installer.Core.Core
{
    public class BundleAttributes
    {
        #region Properties

        [XmlAttribute("DisplayName")]
        public string DisplayName { get; set; }

        [XmlAttribute("UpgradeCode")]
        public string UpgradeCode { get; set; }

        #endregion
    }
}