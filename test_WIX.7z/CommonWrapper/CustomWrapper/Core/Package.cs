﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */
using System.Xml.Serialization;

namespace Installer.Core.Core
{
    public enum PackageType
    {
        [XmlEnum("Exe")]
        EXE,

        [XmlEnum("Msi")]
        MSI,

        [XmlEnum("Msp")]
        MSP,

        [XmlEnum("Msu")]
        MSU,
    }

    public class Package
    {
        #region Properties

        [XmlAttribute("Package")]
        public string Id { get; set; }

        [XmlAttribute("DisplayName")]
        public string DisplayName { get; set; }

        [XmlAttribute("Description")]
        public string Description { get; set; }

        [XmlAttribute("PackageType")]
        public PackageType Type { get; set; }

        // The following properties are not available until 3.9.410.0
        // ...

        [XmlAttribute("ProductCode")]
        public string ProductCode { get; set; }

        [XmlAttribute("UpgradeCode")]
        public string UpgradeCode { get; set; }

        [XmlAttribute("Version")]
        public string Version { get; set; }

        #endregion
    }
}
