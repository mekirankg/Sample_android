﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */

namespace Installer.Core.Core
{
    /// <summary>
    /// The ProcessList used to hold the running process and application name
    /// </summary>
    public class ProcessAttributes
    {
        #region Properties

        public string ProcessName { get; set; }
        public string AppName { get; set; }

        #endregion
    }
}
