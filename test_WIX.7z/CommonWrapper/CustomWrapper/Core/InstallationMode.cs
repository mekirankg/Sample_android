﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */

namespace CustomWrapper.Core
{
    /// <summary>
    /// The detected installation mode for the installer.
    /// </summary>
    public enum InstallationMode
    {
        Unknown,
        NewInstall,
        Upgrade,
        Downgrade,
        Uninstall,
        Repair,
        Modify
    }
}
