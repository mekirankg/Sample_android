﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

namespace Installer.Core.Core
{
    public static class Constants
    {
        #region URL constants

        public const string DOCUMENTATION_LINK = "https://www.pelco.com/video-management-system/videoxpert#tab/documents";
        public const string PELCO_WEBSITE_LINK = "https://www.pelco.com/";
        public const string PELCO_SUPPORT_WEBSITE_LINK = "https://www.pelco.com/support";

        #endregion

        #region Assembly Constants

        public const string INSTALLER_VIEW = @"\Installer.Views.Common.dll";
        public const string INSTALLER_CORE = @"\Installer.Core.dll";
        public const string ENVIRONMENT_VAR_PRGM_FILES =  "%ProgramFiles%";
        public const string ENVIRONMENT_VAR_PRGM64_FILES = "%ProgramW6432%";

        #endregion

        #region Property Constants

        public const string INSTALL_DIRECTORY = "InstallDirectory";
        public const string FILEDIALOG_TEXT = "FileDialogText";       
        public const string IS_UNINSTALLING = "IsUninstalling";
        public const string IS_REPAIRING = "IsRepairing";
        public const string IS_UPGRADE = "IsUpgrade";
        public const string CAN_PERFORM_CANCEL = "CanPerformCancel";
        public const string PROGRESS_DESCRIPTION = "ProgressDescription";
        public const string PROGRESS = "Progress";
        public const string RESTART_REQUIRED = "RestartRequired";
        public const string INSTALLER_VERSION = "InstallerVersion";
        public const string HEADER_IMAGE = "HeaderImage";
        public const string ENHANCED_DECODER_CHECKBOX_TEXT = "EnhancedDecoderCheckboxText";
        public const string CHECKBOX_VISIBLE = "CheckboxVisible";
        public const string CURRENT_VER_TEXT = "CurrentVersion";

        #endregion

        #region Page Constants

        public const string PAGE_NAME_HOME = "HomePage";
        public const string PAGE_NAME_CONFIG = "CustomConfigPage";
        public const string PAGE_NAME_PROGRESS = "ProgressPage";
        public const string PAGE_NAME_UNINSTALL = "UninstallPage";
        public const string PAGE_NAME_COMPONENT_UPGRADE = "ComponentUpgradePage";

        #endregion

        #region Resource Constants

        public const string NEXT_BUTTON_TEXT = "strNextButtonText";
        public const string UNINSTALL_HEADER = "strUninstallHeader";
        public const string UNINSTALL_TEXT = "strUninstallText";
        public const string DELETE_DATABASE = "strDeleteDatabase";
        public const string INSTALL_FINISH_TEXT = "strInstallFinishText";
        public const string UPGRADE_BUTTON_TEXT = "strUpgradeButtonText";
        public const string INSTALL_BUTTON_TEXT = "strInstallButtonText";
        public const string UPGRADE_FINISH_TEXT = "strUpgradeFinishText";
        public const string REPAIR_FINISH_HEADER = "strRepairFinishHeader";
        public const string UNINSTALL_FINISH_TEXT = "strUninstallFinishText";
        public const string INSTALL_FINISH_HEADER = "strInstallFinishHeader";
        public const string FINISH_RESTART_HEADER = "strFinishRestartHeader";
        public const string UNINSTALL_FINISH_HEADER = "strUninstallFinishHeader";
        public const string SELECTION_SCREEN_BUTTON_OK_TEXT = "strOKButtonText";
        public const string UNINSTALL_RESTART_TEXT = "strRestartRequiredMessage";
        public const string HOME_SCREEN_WELCOME_TEXT = "strHomeScreenWelcomeText";
        public const string HOME_SCREEN_UPGRADE_TEXT = "strHomeScreenUpgradeText";
        public const string HOME_SCREEN_BUTTON_EXIT_TEXT = "strHomeScreenButtonExitText";
        public const string HOME_SCREEN_VIDEOXPERT_DETAILS_TEXT = "strHomeScreenVideoXpertDetailsText";
        public const string SELECTION_SCREEN_BUTTON_CANCEL_TEXT = "strSelectionScreenButtonCancelText";
        public const string SELECTION_SCREEN_BUTTON_BACK_TEXT = "strSelectionScreenButtonBackText";
        public const string UNINSTALL_RESTART_REQUIRED_MESSAGE = "strUninstallRestartRequiredMessage";
        public const string HOME_SCREEN_BEGIN_INSTALL_BUTTON_TEXT = "srcHomeScreenBeginInstallButtonText";
        public const string HOME_SCREEN_BEGIN_UPGRADE_BUTTON_TEXT = "srcHomeScreenBeginUpgradeButtonText";
        public const string HOME_SCREEN_ADVANCED_BUTTON_TEXT = "srcHomeScreenAdvancedButtonText";
        public const string UNINSTALL_SCREEN_BUTTON_UNINSTALL_TEXT = "strUninstallScreenButtonUninstallText";
        public const string SELECTION_CUSTOM_DIRECTORY_TEXT = "strSelectionCustomScreenInstalltionDirectoryText";

        #endregion

    }
}
