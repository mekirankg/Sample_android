﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

namespace Installer.Core.Interfaces
{
    /// <summary>
    /// Represents a WizardPage user interface
    /// </summary>
    public interface IWizardPage
    {
        /// <summary>
        /// Returns the name of the wizard page.
        /// </summary>
        string PageName { get; }
    }
}
