﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */

#region Namespaces

using System;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

#endregion

namespace Installer.Core.Interfaces
{
    /// <summary>
    /// Service used to interact with the UI.
    /// </summary>
    public interface IUIInteractionService
    {
        /// <summary>
        /// Opens the eula dialog
        /// </summary>
        void ShowEulaDialog();

        /// <summary>
        /// Force user to reconsider their life decisions
        /// Ask user if they really want to exit the installer
        /// </summary>
        void ShowExitDialog();

        /// <summary>
        /// Return def. installation directory
        /// </summary>
        string GetDefaultInstallDirectory();

        /// <summary>
        /// Return def. enhanced decoder status
        /// </summary>
        bool GetDefaultEnhancedDecoderStatus();

        /// <summary>
        /// set encoder status
        /// </summary>
        void SetEnhancedDecoderValue(bool value);

        /// <summary>
        /// Return view header images
        /// </summary>
        BitmapImage GetHeaderImage(bool isHomePage);

        /// <summary>
        /// Force user to reconsider their life decisions
        /// Ask user if they really want to cancel the installer
        /// </summary>
        void ShowCancelDialog();

        /// <summary>
        /// Opens an error dialog
        /// </summary>
        /// <param name="message">The error message to display</param>
        void ShowErrorDialog(string message);

        /// <summary>
        /// Opens the confirmation dialog to allow the user to confirm that they
        /// want to delete their recordings and database files.
        /// </summary>
        /// <returns>True if they wish to continue, false otherwise</returns>
        Task<bool> ShowDeleteConfirmationDialog();

        /// <summary>
        /// Opens a folder browse dialog and returns the selected folder.  If the user selected
        /// folder is empty then initial path is returned.
        /// </summary>
        /// <param name="description">The dialogs description</param>
        /// <param name="initialFolder">initial folder to seed the dialog with</param>
        /// <returns></returns>
        string OpenFileBrowseDialog(string description, string initalPath);

        /// <summary>
        /// Executes an action on the UI Thread asynchronously.
        /// </summary>
        /// <param name="body">The body of the action to run</param>
        void RunOnUIThreadAsync(Action body);

        /// <summary>
        /// Executes an action on the UI Thread synchronously.
        /// </summary>
        /// <param name="body">The body of the action to run</param>
        void RunOnUIThreadSync(Action body);

        /// <summary>
        /// Closes and exits the UI window.
        /// </summary>
        void CloseUIAndExit();

        /// <summary>
        /// Cancel the installation.
        /// </summary>
        void CancelInstaller();

        /// <summary>
        /// Returns the installer's main window handle
        /// </summary>
        /// <returns></returns>
        IntPtr GetMainWindowHandle();

    }
}
