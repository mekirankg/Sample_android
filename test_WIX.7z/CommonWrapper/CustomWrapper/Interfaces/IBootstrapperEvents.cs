﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */

#region Namespaces

using Microsoft.Tools.WindowsInstallerXml.Bootstrapper;

#endregion

namespace Installer.Core.Interfaces
{
    /// <summary>
    /// Interface can be implemented in the entry point class of the custom installer.
    /// </summary>
    public interface IBootstrapperEvents
    {
        /// <summary>
        /// Bootstrapper error Event.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Bootstrapper_Error(object sender, ErrorEventArgs e);

        /// <summary>
        /// Bootstrapper Plan complete event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Bootstrapper_PlanCompleted(object sender, PlanCompleteEventArgs e);

        /// <summary>
        /// Bootstrapper progress event.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Bootstrapper_ExecuteProgress(object sender, ExecuteProgressEventArgs e);

        /// <summary>
        /// Bootstrapper apply complete event.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Bootstrapper_ApplyComplete(object sender, ApplyCompleteEventArgs e);

        /// <summary>
        /// Bootstrapper execute package begin.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Bootstrapper_ExecutePackageBegin(object sender, ExecutePackageBeginEventArgs e);

        /// <summary>
        /// Bootstrapper Execute complete
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Bootstrapper_ExecutePackageComplete(object sender, ExecutePackageCompleteEventArgs e);

        /// <summary>
        ///  Register for Bootstrapper events.
        /// </summary>
        void RegisterForBootstrapperEvents();

        /// <summary>
        /// Unregister from Bootstrapper events
        /// </summary>
        void UnregisterFromBootstrapperEvents();

        /// <summary>
        /// Bootstrapper Detect begin.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Bootstrapper_DetectedBegin(object sender, DetectBeginEventArgs e);

        /// <summary>
        /// Bootstrapper Detect related bundle.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Bootstrapper_DetectedRelatedBundle(object sender, DetectRelatedBundleEventArgs e);

        /// <summary>
        /// Bootstrapper detect complete.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Bootstrapper_DetectedComplete(object sender, DetectCompleteEventArgs e);

        /// <summary>
        /// Bootstrapper shutdown.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void BundleBootstrapper_Shutdown(object sender, ShutdownEventArgs e);
    }
}
