﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */

#region Namespaces
using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
#endregion

namespace Installer.Core.Converters
{
    /// <summary>
    /// Converter class used to convert a boolean value to a Visibility type
    /// </summary>
    public class InverseBooleanToVisibilityConverter : IValueConverter
    {
        #region Public Methods

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is Boolean && (bool)value)
            {
                return Visibility.Collapsed;
            }

            return Visibility.Visible;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is Visibility && ((Visibility)value == Visibility.Visible))
            {
                return false;
            }

            return true;
        }

        #endregion
    }
}
