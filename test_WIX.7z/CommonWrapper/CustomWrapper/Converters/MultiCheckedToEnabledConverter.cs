﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */

#region Namespaces
using System;
using System.Globalization;
using System.Linq;
using System.Windows.Data;
#endregion

namespace Installer.Core.Converters
{
    /// <summary>
    /// Converter used to determine a single boolean from a list of booleans is true.
    /// For example this converter can be used to see if at least one checkbox from a set
    /// of checkboxes is selected.
    /// </summary>
    public class MultiCheckedToEnabledConverter : IMultiValueConverter
    {
        #region Public Methods

        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            if (values != null)
            {
                return values.OfType<bool>().Any(b => b);
            }

            return false;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            return new object[] { };
        }

        #endregion
    }
}
