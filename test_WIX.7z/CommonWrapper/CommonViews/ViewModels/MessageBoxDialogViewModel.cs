﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespaces
using Installer.Core.Interfaces;
using Prism.Commands;
using System.Windows.Input;
#endregion

namespace Installer.Views.Common.ViewModels
{
    public class MessageBoxDialogViewModel
    {
        #region Private Members

        private IUIInteractionService uiService;

        #endregion

        #region Constructor

        public MessageBoxDialogViewModel(IUIInteractionService uiService, string dialogTitle, string subtext)
        {
            this.uiService = uiService;

            ExitInstallerCommand = new DelegateCommand(ExitInstaller);
            Title = dialogTitle;
            SubText = subtext;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the Title of the message box.
        /// </summary>
        public string Title { get; private set; }

        /// <summary>
        /// Gets or sets the sub text.
        /// </summary>
        public string SubText { get; private set; }

        #endregion

        #region Commands

        /// <summary>
        /// Command for Exit button.
        /// </summary>
        public ICommand ExitInstallerCommand { get; private set; }

        #endregion

        #region Private Methods

        /// <summary>
        /// Executes when exit click.
        /// </summary>
        private void ExitInstaller()
        {
            uiService.CloseUIAndExit();
        }

        #endregion
    }
}
