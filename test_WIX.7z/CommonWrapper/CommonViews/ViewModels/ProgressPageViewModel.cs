﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */

#region Namespaces
using System;
using System.ComponentModel.Composition;
using System.Windows.Input;
using Prism.Commands;
using Installer.Core.Enums;
using Installer.Core.Interfaces;
using Installer.Core.Core;
using Installer.Core.Core.Events;
using System.Collections.Generic;
using Installer.Core.Resources.ResourceStrings;
using Installer.Core.Core.Handler;
using System.Windows.Media.Imaging;
#endregion

namespace Installer.Views.Common.ViewModels
{
    [Export]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public class ProgressPageViewModel : WizardPageViewModel, IDisposable
    {
        #region Private Members

        private int progress;
        private int progressMaximum;
        private bool canCancel;
        private bool isUninstalling;
        private bool isRepairing;
        private string currentPackageName = Resources.strInitializingText;

        #endregion       

        #region Constructor

        [ImportingConstructor]
        public ProgressPageViewModel(IUIInteractionService uiService,
                                     ViewNavigatorHandler nav) : base(uiService, nav)
        {
            progressMaximum = 100;
            isUninstalling = false;
            isRepairing = false;
            canCancel = true;
            nav.EventingService.GetEvent<ProgressPagePropertiesEvent>().Subscribe(ProgressPagePropertiesEventRecieved);
            CancelCommand = new DelegateCommand(Cancel);
            HeaderImage = UIService.GetHeaderImage(false);
        }

        #endregion

        #region Properties

        /// <summary>
        /// sets the HeaderImage 
        /// </summary>
        public BitmapImage HeaderImage { get; set; }

        /// <summary>
        /// Indicates that the installation was due to an uninstall
        /// </summary>
        public bool IsUninstalling
        {
            get
            {
                return isUninstalling;
            }

            private set
            {
                SetProperty(ref isUninstalling, value);
            }
        }
        /// <summary>
        /// Indicates that the installation was due to a repair
        /// </summary>
        public bool IsRepairing
        {
            get
            {
                return isRepairing;
            }

            private set
            {
                SetProperty(ref isRepairing, value);
            }
        }
        /// <summary>
        /// Gets and sets the name of the currently installing package.
        /// </summary>
        public string ProgressDescription
        {
            get
            {
                return currentPackageName;
            }

            private set
            {
                if (currentPackageName != value)
                {
                    SetProperty(ref currentPackageName, value);
                }
            }
        }

        /// <summary>
        /// Gets and sets the maximum value of the progress bar
        /// </summary>
        public int ProgressMaximum
        {
            get
            {
                return progressMaximum;
            }

            set
            {
                if (progressMaximum != value)
                {
                    SetProperty(ref progressMaximum, value);
                }
            }
        }

        /// <summary>
        /// Gets and sets the installation's global progress.
        /// </summary>
        public int Progress
        {
            get
            {
                return progress;
            }

            private set
            {
                if (progress != value)
                {
                    SetProperty(ref progress, value);
                }
            }
        }

        /// <summary>
        /// Gets and set the flag indicating if the cancel button is enabled
        /// </summary>
        public bool CanPerformCancel
        {
            get
            {
                return canCancel;
            }

            private set
            {
                if (canCancel != value)
                {
                    SetProperty(ref canCancel, value);
                }
            }
        }

        #endregion

        #region Commands

        /// <summary>
        /// Gets and sets command for canceling an active install.
        /// </summary>
        public ICommand CancelCommand { get; private set; }

        #endregion

        #region Private Methods

        /// <summary>
        /// Executes when cancel clicked.
        /// </summary>
        private void Cancel()
        {
            CanPerformCancel = false;
            ViewNavigator.GeneratePageEvent(PageButtons.Action1, Constants.PAGE_NAME_PROGRESS);
        }

        /// <summary>
        /// Executes when the page properties are received from the custom installer.
        /// </summary>
        /// <param name="progressPageProperties"></param>
        private void ProgressPagePropertiesEventRecieved(Dictionary<string, object> progressPageProperties)
        {
            foreach (var prop in progressPageProperties)
            {
                switch (prop.Key.ToString())
                {
                    case Constants.IS_UNINSTALLING:
                        IsUninstalling = Convert.ToBoolean(prop.Value);
                        break;
                    case Constants.IS_REPAIRING:
                        IsRepairing = Convert.ToBoolean(prop.Value);
                        break;
                    case Constants.CAN_PERFORM_CANCEL:
                        CanPerformCancel = Convert.ToBoolean(prop.Value);
                        break;
                    case Constants.PROGRESS_DESCRIPTION:
                        ProgressDescription = prop.Value.ToString();
                        break;
                    case Constants.PROGRESS:
                        UIService.RunOnUIThreadAsync(() => Progress = Convert.ToInt32(prop.Value));
                        break;
                    default: break;
                }
            }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Executed when the page is navigated to.  This method will perform the installation.
        /// </summary>
        public override void OnNavigateTo()
        {
            //No operation   
        }

        #endregion

        #region IDisposable

        public void Dispose()
        {

        }

        #endregion

    }
}
