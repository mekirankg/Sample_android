﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */

#region Namespaces

using Prism.Commands;
using System.ComponentModel.Composition;
using System.Windows.Input;
using Installer.Core.Interfaces;
using Installer.Core.Core;
using System.Resources;
using Installer.Core.Core.Events;
using System.Collections.Generic;
using Installer.Core.Core.Handler;
using System.Windows.Media.Imaging;
using Installer.Core.Resources.ResourceStrings;
using System.ComponentModel;
using System;

#endregion

namespace Installer.Views.Common.ViewModels
{
    [Export]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public class CustomConfigPageViewModel : WizardPageViewModel, IDataErrorInfo
    {
        #region Private Members

        private string selectionCustomScreenInstalltionDirectoryText;
        private string applicationInstallationDirectory;
        private string selectionScreenButtonCancelText;
        private string selectionScreenButtonBackText;
        private string installButtonText;
        private string nextButtonText;
        private string fileDialogText;
        private string enhancedDecoderCheckboxText;
        private bool checkboxVisible;
        private bool isCheckboxSelected=true;

        #endregion

        #region Constructor

        [ImportingConstructor]
        public CustomConfigPageViewModel(IUIInteractionService uiService,
                                         ViewNavigatorHandler nav) : base(uiService, nav)
        {
            OkCommand = new DelegateCommand(Ok);
            CancelCommand = new DelegateCommand(Cancel);
            BackCommand = new DelegateCommand(Back);
            NextCommand = new DelegateCommand(Next);
            Navigator = nav;
            BrowseInstallFolderCommand = new DelegateCommand(SelectInstallFolder);
            nav.EventingService.GetEvent<CustomConfigPagePropertiesEvent>().Subscribe(CustomConfigPagePropertiesRecieved);
            HeaderImage = UIService.GetHeaderImage(false);
        }

        #endregion

        #region Properties
        /// <summary>
        /// sets the HeaderImage 
        /// </summary>
        public BitmapImage HeaderImage { get; set; }

        /// <summary>
        /// Gets or sets the ViewNavigator handler
        /// </summary>
        public ViewNavigatorHandler Navigator { get; set; }

        /// <summary>
        /// Gets and sets the Application installation directory
        /// </summary>
        public string ApplicationInstallationDirectory
        {
            get
            {
                return applicationInstallationDirectory;
            }

            set
            {
                if (applicationInstallationDirectory != value)
                {
                    SetProperty(ref applicationInstallationDirectory, value);
                }
            }
        }

        /// <summary>
        /// Gets and sets InstalltionDirectoryText
        /// </summary>
        public string SelectionCustomScreenInstalltionDirectoryText
        {
            get
            {
                return selectionCustomScreenInstalltionDirectoryText;
            }

            set
            {
                if (selectionCustomScreenInstalltionDirectoryText != value)
                {
                    SetProperty(ref selectionCustomScreenInstalltionDirectoryText, value);
                }
            }
        }

        /// <summary>
        /// Gets and sets SelectionScreenButtonCancelText
        /// </summary>
        public string SelectionScreenButtonCancelText
        {
            get
            {
                return selectionScreenButtonCancelText;
            }

            set
            {
                if (selectionScreenButtonCancelText != value)
                {
                    SetProperty(ref selectionScreenButtonCancelText, value);
                }
            }
        }

        /// <summary>
        /// Gets or sets the Enhanced decorder value.
        /// </summary>
        public bool IsCheckboxSelected
        {
            get
            {
                return isCheckboxSelected;
            }
            set
            {
                if (isCheckboxSelected != value)
                {
                    SetProperty(ref isCheckboxSelected, value);
                }
            }
        }

        /// <summary>
        /// Gets and sets SelectionScreenButtonBackText
        /// </summary>
        public string SelectionScreenButtonBackText
        {
            get
            {
                return selectionScreenButtonBackText;
            }

            set
            {
                if (selectionScreenButtonBackText != value)
                {
                    SetProperty(ref selectionScreenButtonBackText, value);
                }
            }
        }
        /// <summary>
        /// Gets and sets InstallButtonText
        /// </summary>
        public string InstallButtonText
        {
            get
            {
                return installButtonText;
            }

            set
            {
                if (installButtonText != value)
                {
                    SetProperty(ref installButtonText, value);
                }
            }
        }
        /// <summary>
        /// Gets and sets NextButtonText
        /// </summary>
        public string NextButtonText
        {
            get
            {
                return nextButtonText;
            }

            set
            {
                if (nextButtonText != value)
                {
                    SetProperty(ref nextButtonText, value);
                }
            }
        }
        /// <summary>
        /// Retrieves the OpenFileDialog text
        /// </summary>
        public string FileDialogText
        {
            get
            {
                return fileDialogText;
            }

            private set
            {
                if (fileDialogText != value)
                {
                    SetProperty(ref fileDialogText, value);
                }
            }
        }
        
        /// <summary>
        /// Retrieves the EnhancedDecoderCheckboxText text
        /// </summary>
        public string EnhancedDecoderCheckboxText
        {
            get
            {
                return enhancedDecoderCheckboxText;
            }

            private set
            {
                if (enhancedDecoderCheckboxText != value)
                {
                    SetProperty(ref enhancedDecoderCheckboxText, value);
                }
            }
        }
        /// <summary>
        /// Retrieves the status of Checkbox visibility.
        /// </summary>
        public bool CheckboxVisible
        {
            get
            {
                return checkboxVisible;
            }

            private set
            {
                if (checkboxVisible != value)
                {
                    SetProperty(ref checkboxVisible, value);
                }
            }
        }

        #endregion

        #region Commands

        /// <summary>
        /// Command to Set the installer directory.
        /// </summary>
        public ICommand OkCommand { get; private set; }
        /// <summary>
        /// Command to Exit the installer.
        /// </summary>
        public ICommand CancelCommand { get; private set; }

        /// <summary>
        /// Command to navigate to the previous wizard page.
        /// </summary>
        public ICommand BackCommand { get; private set; }

        /// <summary>
        /// Command to navigate to the next wizard page.
        /// </summary>
        public ICommand NextCommand { get; private set; }

        /// <summary>
        /// Command to browse for pro server install folder
        /// </summary>
        public ICommand BrowseInstallFolderCommand { get; private set; }

        #endregion

        #region IDataErrorInfo

        /// <summary>
        /// To return IDataErrorInfo Member Error.
        /// </summary>
        public string Error
        {
            get
            {
                return null;
            }
        }
        /// <summary>
        /// To validate Application Installation Directory
        /// </summary>
        /// <param name="columnName"></param>
        /// <returns>Error message</returns>
        public string this[string columnName]
        {
            get
            {
                string msg = null;
                switch (columnName)
                {
                    case nameof(ApplicationInstallationDirectory):
                        msg = PathValidator.ValidatePath(ApplicationInstallationDirectory);
                        break;
                    default:
                        msg = null;
                        break;
                }
                return msg;
            }
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Executes on Cancel click.
        /// </summary>
        private void Cancel()
        {
            UIService.ShowExitDialog();
        }

        /// <summary>
        /// Executes on Back click.
        /// </summary>
        private void Back()
        {
            ApplicationInstallationDirectory = UIService.GetDefaultInstallDirectory();
            IsCheckboxSelected = UIService.GetDefaultEnhancedDecoderStatus();
            ViewNavigator.ShowPreviousPage();
        }

        /// <summary>
        /// Executes on Back click.
        /// </summary>
        private void Ok()
        {
            Navigator.GenerateConfigPageEvent(ApplicationInstallationDirectory.Trim());
            UIService.SetEnhancedDecoderValue(isCheckboxSelected);
            ViewNavigator.ShowPreviousPage();
        }

        /// <summary>
        /// Executes on Next click.
        /// </summary>
        private void Next()
        {
            ViewNavigator.GeneratePageEvent(Core.Enums.PageButtons.Action1, Constants.PAGE_NAME_CONFIG);
        }

        /// <summary>
        /// Executes when the new path is selected.
        /// </summary>
        private void SelectInstallFolder()
        {
            UIService.RunOnUIThreadAsync(() =>
            {
                ApplicationInstallationDirectory = UIService.OpenFileBrowseDialog(string.Format(Resources.strSelectInstallationFolder, FileDialogText), ApplicationInstallationDirectory);
            });
        }

        /// <summary>
        /// Executes when the page properties are received as event from the installer.
        /// </summary>
        /// <param name="properties"></param>
        private void CustomConfigPagePropertiesRecieved(Dictionary<string, object> properties)
        {
            foreach (var prop in properties)
            {
                switch (prop.Key.ToString())
                {
                    case Constants.INSTALL_DIRECTORY:
                        ApplicationInstallationDirectory = prop.Value.ToString();
                        break;
                    case Constants.FILEDIALOG_TEXT:
                        FileDialogText = prop.Value.ToString();
                        break;
                    case Constants.ENHANCED_DECODER_CHECKBOX_TEXT:
                        EnhancedDecoderCheckboxText = prop.Value.ToString();
                        break;
                    case Constants.CHECKBOX_VISIBLE:
                        CheckboxVisible = Convert.ToBoolean(prop.Value);
                        break;
                    default: // No operation
                        break;
                }
            }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Sets the page's text content from the resource provide from the custom installer.
        /// </summary>
        /// <param name="resource"></param>
        public override void SetPageTexts(ResourceManager resource)
        {
            SelectionCustomScreenInstalltionDirectoryText = resource.GetString(Constants.SELECTION_CUSTOM_DIRECTORY_TEXT, Resources.Culture);
        }

        /// <summary>
        /// Sets the content of the Button based on installers.
        /// </summary>
        /// <param name="resource"></param>
        public override void SetPageButtonTexts(ResourceManager resource)
        {
            SelectionScreenButtonCancelText = resource.GetString(Constants.SELECTION_SCREEN_BUTTON_CANCEL_TEXT, Resources.Culture);
            SelectionScreenButtonBackText = resource.GetString(Constants.SELECTION_SCREEN_BUTTON_OK_TEXT, Resources.Culture);
            InstallButtonText = resource.GetString(Constants.INSTALL_BUTTON_TEXT, Resources.Culture);
            NextButtonText = resource.GetString(Constants.NEXT_BUTTON_TEXT, Resources.Culture);
        }

        public override void OnNavigateTo()
        {
            //No operation
        }

        #endregion

    }
}
