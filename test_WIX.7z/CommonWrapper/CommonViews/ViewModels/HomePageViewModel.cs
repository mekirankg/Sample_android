﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespaces
using Installer.Core.Core;
using Installer.Core.Core.Events;
using Installer.Core.Core.Handler;
using Installer.Core.Enums;
using Installer.Core.Interfaces;
using Installer.Core.Resources.ResourceStrings;
using Prism.Commands;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Resources;
using System.Windows.Input;
using System.Windows.Media.Imaging;
#endregion

namespace Installer.Views.Common.ViewModels
{
    [Export]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public class HomePageViewModel : WizardPageViewModel
    {
        #region Private Members

        private bool isUpgrade;
        private bool isLicenseAccepted;
        private string homeWelcomeText;
        private string homeDetailText;
        private string homeUpgradeText;
        private string installerVersion;
        private string homeScreenButtonExitText;
        private string homeScreenBeginInstallButtonText;
        private string homeScreenBeginUpgradeButtonText;
        private string homeScreenButtonAdvancedText;
        
        #endregion

        #region Constructor

        [ImportingConstructor]
        public HomePageViewModel(IUIInteractionService uiService,
                                 ViewNavigatorHandler nav) : base(uiService, nav)
        {
            isUpgrade = false;
            isLicenseAccepted = false;

            ShowEulaCommand = new DelegateCommand(UIService.ShowEulaDialog);
            OpenDocumentationLinkCommand = new DelegateCommand(OpenDocumentationLink);
            OpenPelcoSupportLinkCommand = new DelegateCommand(OpenPelcoSupportLink);
            Action1Command = new DelegateCommand<object>(PageAction1);
            Action2Command = new DelegateCommand<object>(PageAction2);
            Action3Command = new DelegateCommand<object>(PageAction3);
            nav.EventingService.GetEvent<HomePagePropertiesEvent>().Subscribe(HomePagePropertiesRecieved);
            HeaderImage = UIService.GetHeaderImage(true);
        }

        #endregion      

        #region Properties

        public BitmapImage HeaderImage { get; set; }

        /// <summary>
        /// Indicates that the installation was due to an upgrade.
        /// </summary>
        public bool IsUpgrade
        {
            get
            {
                return isUpgrade;
            }

            private set
            {
                SetProperty(ref isUpgrade, value);
            }
        }

        /// <summary>
        /// Retrieves the installer's version number
        /// </summary>
        public string InstallerVersion
        {
            get
            {
                return installerVersion;
            }

            private set
            {
                SetProperty(ref installerVersion, value);
            }
        }

        /// <summary>
        /// Flag indicating if the user accepted the license agreement.
        /// </summary>
        public bool IsLicenseAccepted
        {
            get
            {
                return isLicenseAccepted;
            }

            set
            {
                if (isLicenseAccepted != value)
                {
                    SetProperty(ref isLicenseAccepted, value);
                }
            }
        }

        /// <summary>
        /// Gets and sets HomePageWelcomeText
        /// </summary>
        public string HomeWelcomeText
        {
            get
            {
                return homeWelcomeText;
            }

            set
            {
                if (homeWelcomeText != value)
                {
                    SetProperty(ref homeWelcomeText, value);
                }
            }
        }

        /// <summary>
        /// Gets and sets HomeScreenButtonExitText
        /// </summary>
        public string HomeScreenButtonExitText
        {
            get
            {
                return homeScreenButtonExitText;
            }

            set
            {
                if (homeScreenButtonExitText != value)
                {
                    SetProperty(ref homeScreenButtonExitText, value);
                }
            }
        }

        /// <summary>
        /// Gets and sets HomeScreenBeginInstallButtonText
        /// </summary>
        public string HomeScreenBeginInstallButtonText
        {
            get
            {
                return homeScreenBeginInstallButtonText;
            }

            set
            {
                if (homeScreenBeginInstallButtonText != value)
                {
                    SetProperty(ref homeScreenBeginInstallButtonText, value);
                }
            }
        }

        /// <summary>
        /// Gets and sets HomeScreenBeginInstallButtonText
        /// </summary>
        public string HomeScreenBeginUpgradeButtonText
        {
            get
            {
                return homeScreenBeginUpgradeButtonText;
            }

            set
            {
                if (homeScreenBeginUpgradeButtonText != value)
                {
                    SetProperty(ref homeScreenBeginUpgradeButtonText, value);
                }
            }
        }

        /// <summary>
        /// Gets and sets HomeScreenButtonAdvancedText
        /// </summary>
        public string HomeScreenButtonAdvancedText
        {
            get
            {
                return homeScreenButtonAdvancedText;
            }

            set
            {
                if (homeScreenButtonAdvancedText != value)
                {
                    SetProperty(ref homeScreenButtonAdvancedText, value);
                }
            }
        }

        /// <summary>
        /// Gets and sets HomePageDetailsText
        /// </summary>
        public string HomeDetailsText
        {
            get
            {
                return homeDetailText;
            }

            set
            {
                if (homeDetailText != value)
                {
                    SetProperty(ref homeDetailText, value);
                }
            }
        }

        /// <summary>
        /// Gets and sets HomePageUpgradeText
        /// </summary>
        public string HomeUpgradeText
        {
            get
            {
                return homeUpgradeText;
            }

            set
            {
                if (homeUpgradeText != value)
                {
                    SetProperty(ref homeUpgradeText, value);
                }
            }
        }

        #endregion

        #region Commands

        /// <summary>
        /// Command to show Eula dialog
        /// </summary>
        public ICommand ShowEulaCommand { get; private set; }

        /// <summary>
        /// Command to show the online documentation
        /// </summary>
        public ICommand OpenDocumentationLinkCommand { get; private set; }

        /// <summary>
        /// Command to open up the pelco web site.
        /// </summary>
        public ICommand OpenPelcoSupportLinkCommand { get; private set; }

        /// <summary>
        /// Command for page action3.
        /// </summary>
        public ICommand Action3Command { get; private set; }

        /// <summary>
        /// Command for page action1.
        /// </summary>
        public ICommand Action1Command { get; private set; }

        /// <summary>
        /// Command for page action2.
        /// </summary>
        public ICommand Action2Command { get; private set; }

        #endregion

        #region Private Methods

        /// <summary>
        /// Executes on Link click.
        /// </summary>
        private void OpenPelcoSupportLink()
        {
            new Util().OpenWebBrowser(Constants.PELCO_SUPPORT_WEBSITE_LINK);
        }

        /// <summary>
        /// Executes on document link click.
        /// </summary>
        private void OpenDocumentationLink()
        {
            new Util().OpenWebBrowser(Constants.DOCUMENTATION_LINK);
        }

        /// <summary>
        /// Executes when page properties are received from custom installer.
        /// </summary>
        /// <param name="properties"></param>
        private void HomePagePropertiesRecieved(Dictionary<string, object> properties)
        {
            foreach (var prop in properties)
            {
                switch (prop.Key.ToString())
                {
                    case Constants.INSTALLER_VERSION:
                        InstallerVersion = Convert.ToString(prop.Value);
                        break;
                    case Constants.IS_UPGRADE:
                        IsUpgrade = Convert.ToBoolean(prop.Value);
                        break;
                    case Constants.HEADER_IMAGE:
                        HeaderImage = (BitmapImage)prop.Value;
                        break;
                    default: break;
                }
            }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Sets the content of the page based on installers.
        /// </summary>
        /// <param name="resource"></param>
        public override void SetPageTexts(ResourceManager resource)
        {
            HomeWelcomeText = resource.GetString(Constants.HOME_SCREEN_WELCOME_TEXT , Resources.Culture);
            HomeDetailsText = resource.GetString(Constants.HOME_SCREEN_VIDEOXPERT_DETAILS_TEXT , Resources.Culture);
            HomeUpgradeText = resource.GetString(Constants.HOME_SCREEN_UPGRADE_TEXT, Resources.Culture);
        }

        /// <summary>
        /// Sets the content of the Button based on installers.
        /// </summary>
        /// <param name="resource"></param>
        public override void SetPageButtonTexts(ResourceManager resource)
        {
            HomeScreenButtonExitText = resource.GetString(Constants.HOME_SCREEN_BUTTON_EXIT_TEXT, Resources.Culture);
            HomeScreenBeginInstallButtonText = resource.GetString(Constants.HOME_SCREEN_BEGIN_INSTALL_BUTTON_TEXT, Resources.Culture);
            HomeScreenBeginUpgradeButtonText = resource.GetString(Constants.HOME_SCREEN_BEGIN_UPGRADE_BUTTON_TEXT, Resources.Culture);
            HomeScreenButtonAdvancedText = resource.GetString(Constants.HOME_SCREEN_ADVANCED_BUTTON_TEXT, Resources.Culture);
        }

        public override void OnNavigateTo()
        {
            //No operation
        }

        #endregion
    }
}
