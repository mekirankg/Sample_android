﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespaces
using Prism.Mvvm;
using System.Resources;
using Installer.Core.Core;
using Installer.Core.Interfaces;
using Installer.Core.Core.Handler;
using Installer.Core.Enums;
using System;
#endregion

namespace Installer.Views.Common.ViewModels
{
    public abstract class WizardPageViewModel : BindableBase
    {
        #region Constructor

        public WizardPageViewModel(IUIInteractionService uiService,
                                   ViewNavigatorHandler nav)
        {
            UIService = uiService;
            ViewNavigator = nav;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Retrieves the UI interaction service.
        /// </summary>
        protected IUIInteractionService UIService { get; private set; }

        /// <summary>
        /// Retrieves the View Navigator
        /// </summary>
        protected ViewNavigatorHandler ViewNavigator { get; private set; }

        #endregion

        #region Public Methods

        /// <summary>
        /// Called when a page is navigated to.
        /// </summary>
        public virtual void OnNavigateTo()
        {
            // no-op
        }

        /// <summary>
        /// Called to set Page Texts
        /// </summary>
        public virtual void SetPageTexts(ResourceManager text)
        {
            // no-op
        }

        /// <summary>
        /// Called to set Page Button Texts
        /// </summary>
        public virtual void SetPageButtonTexts(ResourceManager text)
        {
            // no-op
        }

        /// <summary>
        /// Called when a page is navigated back to.  This can only occur
        /// when the previously visited page is requested through the PageManager.ShowPreviousPage()
        /// </summary>
        public virtual void OnNavigateBack()
        {
            // no-op
        }

        /// <summary>
        /// Called when the page buttons are clicked.
        /// </summary>
        /// <param name="pageType">Name of the page generating the event</param>
        public void PageAction1(object pageType)
        {
            ViewNavigator.GeneratePageEvent(PageButtons.Action1, Convert.ToString(pageType));
        }

        /// <summary>
        /// Called when the page buttons are clicked.
        /// </summary>
        /// <param name="pageType">Name of the page generating the event</param>
        public void PageAction2(object pageType)
        {
            ViewNavigator.GeneratePageEvent(PageButtons.Action2, Convert.ToString(pageType));
        }

        /// <summary>
        /// Called when the page buttons are clicked.
        /// </summary>
        /// <param name="pageType">Name of the page generating the event</param>
        public void PageAction3(object pageType)
        {
            ViewNavigator.GeneratePageEvent(PageButtons.Action3, Convert.ToString(pageType));
        }

        #endregion
    }
}
