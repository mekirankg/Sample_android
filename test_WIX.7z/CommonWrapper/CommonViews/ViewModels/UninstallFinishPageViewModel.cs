﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespaces
using Installer.Core.Core;
using Installer.Core.Core.Events;
using Installer.Core.Core.Handler;
using Installer.Core.Interfaces;
using Installer.Core.Resources.ResourceStrings;
using Prism.Commands;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Resources;
using System.Windows.Input;
using System.Windows.Media.Imaging;
#endregion

namespace Installer.Views.Common.ViewModels
{
    [Export]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public class UninstallFinishPageViewModel : WizardPageViewModel
    {
        #region Private Members

        private string uninstallFinishHeader;
        private string uninstallFinishText;
        private string uninstallRestartRequiredMessage;
        private bool restartRequired;
        private string repairFinishHeader;
        private string uninstallRestartText;
        private bool isRepair=false;

        #endregion

        #region Constructor

        [ImportingConstructor]
        public UninstallFinishPageViewModel(IUIInteractionService uiService,
                                            ViewNavigatorHandler nav) : base(uiService, nav)
        {
            nav.EventingService.GetEvent<UninstallPageFinishPropertiesEvents>().Subscribe(UninstallPageFinishPropertiesEventsReceived);
            CloseCommand = new DelegateCommand(Close);
            HeaderImage = UIService.GetHeaderImage(false);
        }

        #endregion

        #region Properties

        /// <summary>
        /// sets the HeaderImage 
        /// </summary>
        public BitmapImage HeaderImage { get; set; }

        /// <summary>
        /// Retrieves the flag indicating if a restart is required.
        /// </summary>
        public bool RestartRequired
        {
            get { return restartRequired; }
            set
            {
                if (restartRequired != value)
                {
                    SetProperty(ref restartRequired, value);
                }
            }
        }

        /// <summary>
        /// Retrieves the flag indicating if a restart is required.
        /// </summary>
        public bool IsRepair
        {
            get { return isRepair; }
            set
            {
                if (isRepair != value)
                {
                    SetProperty(ref isRepair, value);
                }
            }
        }

        /// <summary>
        /// Gets and sets UninstallFinishHeader
        /// </summary>
        public string UninstallRestartText
        {
            get
            {
                return uninstallRestartText;
            }

            set
            {
                if (uninstallRestartText != value)
                {
                    SetProperty(ref uninstallRestartText, value);
                }
            }
        }

        /// <summary>
        /// Gets and sets UninstallFinishHeader
        /// </summary>
        public string UninstallFinishHeader
        {
            get
            {
                return uninstallFinishHeader;
            }

            set
            {
                if (uninstallFinishHeader != value)
                {
                    SetProperty(ref uninstallFinishHeader, value);
                }
            }
        }
        /// <summary>
        /// Gets and sets UninstallFinishHeader
        /// </summary>
        public string RepairFinishHeader
        {
            get
            {
                return repairFinishHeader;
            }

            set
            {
                if (repairFinishHeader != value)
                {
                    SetProperty(ref repairFinishHeader, value);
                }
            }
        }

        /// <summary>
        /// Gets and sets UninstallFinishText
        /// </summary>
        public string UninstallFinishText
        {
            get
            {
                return uninstallFinishText;
            }

            set
            {
                if (uninstallFinishText != value)
                {
                    SetProperty(ref uninstallFinishText, value);
                }
            }
        }

        /// <summary>
        /// Gets and sets UninstallFinishText
        /// </summary>
        public string UninstallRestartRequiredMessage
        {
            get
            {
                return uninstallRestartRequiredMessage;
            }

            set
            {
                if (uninstallRestartRequiredMessage != value)
                {
                    SetProperty(ref uninstallRestartRequiredMessage, value);
                }
            }
        }

        #endregion

        #region Commands

        /// <summary>
        /// Command to close and exit the installer.
        /// </summary>
        public ICommand CloseCommand { get; private set; }

        #endregion

        #region Public Methods

        /// <summary>
        /// Sets the content of the page.
        /// </summary>
        /// <param name="resource"></param>
        public override void SetPageTexts(ResourceManager resource)
        {
            UninstallFinishHeader = resource.GetString(Constants.UNINSTALL_FINISH_HEADER, Resources.Culture);
            UninstallFinishText = resource.GetString(Constants.UNINSTALL_FINISH_TEXT, Resources.Culture);
            UninstallRestartRequiredMessage = resource.GetString(Constants.UNINSTALL_RESTART_REQUIRED_MESSAGE, Resources.Culture);
            RepairFinishHeader = resource.GetString(Constants.REPAIR_FINISH_HEADER, Resources.Culture);
            UninstallRestartText= resource.GetString(Constants.UNINSTALL_RESTART_TEXT, Resources.Culture);
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Executes on Close.
        /// </summary>
        private void Close()
        {
            UIService.CloseUIAndExit();
        }

        /// <summary>
        /// Executes when the page properties are received from the custom installer.
        /// </summary>
        /// <param name="progressPageProperties"></param>
        private void UninstallPageFinishPropertiesEventsReceived(Dictionary<string, object> uninstallPageFinishProperties)
        {
            foreach (var prop in uninstallPageFinishProperties)
            {
                switch (prop.Key.ToString())
                {
                    case Constants.RESTART_REQUIRED:
                        RestartRequired = Convert.ToBoolean(prop.Value);
                        break;
                    case Constants.IS_REPAIRING:
                        IsRepair = Convert.ToBoolean(prop.Value);
                        break;
                    default: break;
                }
            }
        }

        #endregion
    }
}
