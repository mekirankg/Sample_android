﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespaces

using Prism.Commands;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel.Composition;
using System.Windows.Input;
using Installer.Views.Common.Controls;
using Installer.Core.Core;
using Installer.Core.Interfaces;
using Installer.Core.Resources.ResourceStrings;
using System.Resources;
using Installer.Core.Core.Handler;
using System.Windows.Media.Imaging;

#endregion

namespace Installer.Views.Common.ViewModels
{
    [Export]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public class ComponentUpgradePageViewModel : WizardPageViewModel, IDisposable
    {
        #region Private Members

        private bool canUpgrade;
        private ObservableCollection<string> components;
        private ApplicationProcessControlViewModel runningAppsModel;
        private ApplicationProcessControlViewModel appsControViewModel;
        private string selectionScreenButtonCancelText;
        private string selectionScreenButtonBackText;
        private string upgradeButtonText;

        #endregion

        #region constructor

        [ImportingConstructor]
        public ComponentUpgradePageViewModel(IUIInteractionService uiService,
                                             ViewNavigatorHandler nav,
                                              ApplicationProcessControlViewModel controlVm, ApplicationHandler appManager
                                             ) : base(uiService, nav)
        {
            ApplicationsManager = appManager;
            appsControViewModel = controlVm;
            appsControViewModel.Title = Resources.srcUpgradeRunningProcessesTitle;
            appsControViewModel.ApplicationsExited += OnApplicationsExited;

            CancelCommand = new DelegateCommand(Close);
            BackCommand = new DelegateCommand(Back);
            UpgradeCommand = new DelegateCommand(Upgrade);
            HeaderImage = UIService.GetHeaderImage(false);
        }

        #endregion

        #region Properties

        /// <summary>
        /// sets the HeaderImage 
        /// </summary>
        public BitmapImage HeaderImage { get; set; }

        /// <summary>
        /// Gets the list of installed components.
        /// </summary>
        public ObservableCollection<string> InstalledComponents
        {
            get
            {
                if (components == null)
                {
                    components = new ObservableCollection<string>();
                }

                return components;
            }
        }

        /// <summary>
        /// Flag indicating whether or not the upgrade button is enabled.
        /// </summary>
        public bool CanStartUpgrade
        {
            get
            {
                return canUpgrade;
            }

            set
            {
                if (canUpgrade != value)
                {
                    SetProperty(ref canUpgrade, value);

                    if (canUpgrade)
                    {
                        // If we can proceed with the upgrade then hide the process view
                        RunningAppsModel = null;
                    }
                }
            }
        }

        /// <summary>
        /// The model of the view for showing the currently running processes.
        /// </summary>
        public ApplicationProcessControlViewModel RunningAppsModel
        {
            get
            {
                return runningAppsModel;
            }

            set
            {
                SetProperty(ref runningAppsModel, value);
            }
        }

        /// <summary>
        /// Gets and sets SelectionScreenButtonCancelText
        /// </summary>
        public string SelectionScreenButtonCancelText
        {
            get
            {
                return selectionScreenButtonCancelText;
            }

            set
            {
                if (selectionScreenButtonCancelText != value)
                {
                    SetProperty(ref selectionScreenButtonCancelText, value);
                }
            }
        }
        /// <summary>
        /// Gets and sets SelectionScreenButtonBackText
        /// </summary>
        public string SelectionScreenButtonBackText
        {
            get
            {
                return selectionScreenButtonBackText;
            }

            set
            {
                if (selectionScreenButtonBackText != value)
                {
                    SetProperty(ref selectionScreenButtonBackText, value);
                }
            }
        }
        /// <summary>
        /// Gets and sets UpgradeButtonText
        /// </summary>
        public string UpgradeButtonText
        {
            get
            {
                return upgradeButtonText;
            }

            set
            {
                if (upgradeButtonText != value)
                {
                    SetProperty(ref upgradeButtonText, value);
                }
            }
        }
        #endregion

        #region Commands

        /// <summary>
        /// Command to close and exit the installer
        /// </summary>
        public ICommand CancelCommand { get; private set; }

        /// <summary>
        /// Command to navigate back to the previous page.
        /// </summary>
        public ICommand BackCommand { get; private set; }

        /// <summary>
        /// Command to perform the upgrade.
        /// </summary>
        public ICommand UpgradeCommand { get; private set; }

        // <summary>
        /// Gets and sets the Processes manager used to manage the running applications.
        /// </summary>
        private ApplicationHandler ApplicationsManager { get; set; }
        #endregion

        #region ApplicationsExit Handler

        /// <summary>
        /// Called when all executing applications have exited.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnApplicationsExited(object sender, EventArgs e)
        {
            CanStartUpgrade = true;
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Executes on exit  click.
        /// </summary>
        public void Close()
        {
            UIService.ShowExitDialog();
        }

        /// <summary>
        /// Executes on back button click.
        /// </summary>
        public void Back()
        {
            ViewNavigator.ShowPreviousPage();
        }

        /// <summary>
        /// On upgrade button click.
        /// </summary>
        private void Upgrade()
        {
            ViewNavigator.GeneratePageEvent(Core.Enums.PageButtons.Action1, Constants.PAGE_NAME_COMPONENT_UPGRADE);
        }

        /// <summary>
        /// Called when this page is navigated from a previous page.
        /// </summary>
        public override void OnNavigateTo()
        {
            InstalledComponents.Clear();
            appsControViewModel.Title = Resources.srcUpgradeRunningProcessesTitle;
            foreach (string app in ApplicationsManager.ApplicationsList)
            {
                InstalledComponents.Add(app);
            }
            RefreshAppsControl();
        }

        /// <summary>
        /// Called when this page is navigated back to from the next page.
        /// </summary>
        public override void OnNavigateBack()
        {
            //No operation
        }

        /// <summary>
        /// Sets the content of the Button based on installers.
        /// </summary>
        /// <param name="resource"></param>
        public override void SetPageButtonTexts(ResourceManager resource)
        {
            SelectionScreenButtonCancelText = resource.GetString(Constants.SELECTION_SCREEN_BUTTON_CANCEL_TEXT, Resources.Culture);
            SelectionScreenButtonBackText = resource.GetString(Constants.SELECTION_SCREEN_BUTTON_BACK_TEXT, Resources.Culture);
            UpgradeButtonText = resource.GetString(Constants.UPGRADE_BUTTON_TEXT, Resources.Culture);
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Refreshes the application control and sets the view state to visible or not.
        /// </summary>
        private void RefreshAppsControl()
        {
            appsControViewModel.Refresh();

            if (appsControViewModel.AreAnyApplicationsRunning)
            {
                RunningAppsModel = appsControViewModel;
                CanStartUpgrade = false;
            }
            else
            {
                RunningAppsModel = null;
                CanStartUpgrade = true;
            }
        }

        #endregion

        #region IDisposable

        /// <summary>
        /// Disposes the subscribed event.
        /// </summary>
        public void Dispose()
        {
            appsControViewModel.ApplicationsExited -= OnApplicationsExited;
        }

        #endregion
    }
}
