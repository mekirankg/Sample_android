﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespaces

using Installer.Views.Common.Controls;
using Installer.Core.Core;
using Installer.Core.Interfaces;
using Installer.Core.Resources.ResourceStrings;
using Prism.Commands;
using System;
using System.ComponentModel.Composition;
using System.Resources;
using System.Windows.Input;
using Installer.Core.Core.Handler;
using System.Windows.Media.Imaging;

#endregion

namespace Installer.Views.Common.ViewModels
{
    [Export]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public class UninstallPageViewModel : WizardPageViewModel, IDisposable
    {
        #region Private Members

        private bool canStartUninstall;
        private string selectionScreenButtonCancelText;
        private string uninstallScreenButtonUninstallText;
        private string uninstallHeader;
        private string uninstallNoMessage;
        private string uninstallText;
        private ApplicationProcessControlViewModel runningAppsModel;
        private ApplicationProcessControlViewModel appsControViewModel;        

        #endregion

        #region Constructor

        [ImportingConstructor]
        public UninstallPageViewModel(IUIInteractionService uiService,
                                      ViewNavigatorHandler nav,
                                      ApplicationProcessControlViewModel controlVm) : base(uiService, nav)
        {
            appsControViewModel = controlVm;
            appsControViewModel.Title = Resources.srcUninstallRunningProcessesTitle;
            appsControViewModel.ApplicationsExited += OnApplicationsExited;

            RunningAppsModel = null; // Initially set to null so that the view is not shown
            CancelUninstallCommand = new DelegateCommand(CancelUninstall);
            UninstallCommand = new DelegateCommand(Uninstall);
            RepairCommand = new DelegateCommand(Repair);
            HeaderImage = UIService.GetHeaderImage(false);
        }

        #endregion

        #region Properties

        /// <summary>
        /// sets the HeaderImage 
        /// </summary>
        public BitmapImage HeaderImage { get; set; }
        
        /// <summary>
        /// Flag indicating whether or not the uninstall button is enabled.
        /// </summary>
        public bool CanStartUninstall
        {
            get
            {
                return canStartUninstall;
            }

            set
            {
                SetProperty(ref canStartUninstall, value);

                if (canStartUninstall)
                {
                    RunningAppsModel = null;
                }
            }
        }

        /// <summary>
        /// The model of the view for showing the currently running processes.
        /// </summary>
        public ApplicationProcessControlViewModel RunningAppsModel
        {
            get
            {
                return runningAppsModel;
            }

            set
            {
                SetProperty(ref runningAppsModel, value);
            }
        }
        /// <summary>
        /// Gets and sets UninstallHeader
        /// </summary>
        public string UninstallHeader
        {
            get
            {
                return uninstallHeader;
            }

            set
            {
                if (uninstallHeader != value)
                {
                    SetProperty(ref uninstallHeader, value);
                }
            }
        }

        /// <summary>
        /// Gets and sets UninstallHeader
        /// </summary>
        public string UninstallNoMessage
        {
            get
            {
                return uninstallNoMessage;
            }

            set
            {
                if (uninstallNoMessage != value)
                {
                    SetProperty(ref uninstallNoMessage, value);
                }
            }
        }
        /// <summary>
        /// Gets and sets UninstallText
        /// </summary>
        public string UninstallText
        {
            get
            {
                return uninstallText;
            }

            set
            {
                if (uninstallText != value)
                {
                    SetProperty(ref uninstallText, value);
                }
            }
        }
        /// <summary>
        /// Gets and sets SelectionScreenButtonCancelText
        /// </summary>
        public string SelectionScreenButtonCancelText
        {
            get
            {
                return selectionScreenButtonCancelText;
            }

            set
            {
                if (selectionScreenButtonCancelText != value)
                {
                    SetProperty(ref selectionScreenButtonCancelText, value);
                }
            }
        }

        /// <summary>
        /// Gets and sets SelectionScreenButtonCancelText
        /// </summary>
        public string UninstallScreenButtonUninstallText
        {
            get
            {
                return uninstallScreenButtonUninstallText;
            }

            set
            {
                if (uninstallScreenButtonUninstallText != value)
                {
                    SetProperty(ref uninstallScreenButtonUninstallText, value);
                }
            }
        }

        #endregion

        #region Commands

        /// <summary>
        /// Command to cancel the uninstall and exit the installer
        /// </summary>
        public ICommand CancelUninstallCommand { get; private set; }

        /// <summary>
        /// Command to initiate the uninstall.
        /// </summary>
        public ICommand UninstallCommand { get; private set; }

        /// <summary>
        /// Command to initiate the repair.
        /// </summary>
        public ICommand RepairCommand { get; private set; }

        #endregion

        #region Private Methods

        /// <summary>
        /// On application exit event.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnApplicationsExited(object sender, EventArgs e)
        {
            CanStartUninstall = true;
        }

        /// <summary>
        /// On cancel button click.
        /// </summary>
        private void CancelUninstall()
        {
            UIService.ShowExitDialog();
        }

        /// <summary>
        /// On uninstall button click.
        /// </summary>
        private void Uninstall()
        {
            ViewNavigator.GeneratePageEvent(Core.Enums.PageButtons.Action1, Constants.PAGE_NAME_UNINSTALL);
        }

        /// <summary>
        /// On uninstall button click.
        /// </summary>
        private async void Repair()
        {
            ViewNavigator.GeneratePageEvent(Core.Enums.PageButtons.Action2, Constants.PAGE_NAME_UNINSTALL);
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Executes on navigating to the page.
        /// </summary>
        public override void OnNavigateTo()
        {
            appsControViewModel.Title = Resources.srcUninstallRunningProcessesTitle;

            appsControViewModel.Refresh();

            if (appsControViewModel.AreAnyApplicationsRunning)
            {
                RunningAppsModel = appsControViewModel;
                CanStartUninstall = false;
            }
            else
            {
                RunningAppsModel = null;
                CanStartUninstall = true;
            }
        }

        /// <summary>
        /// Executes on navigating back.
        /// </summary>
        public override void OnNavigateBack()
        {
            // Just do the same thing as navigating to
            OnNavigateTo();
        }

        /// <summary>
        /// Sets the page text content.
        /// </summary>
        /// <param name="resource"></param>
        public override void SetPageTexts(ResourceManager resource)
        {
            UninstallHeader = resource.GetString(Constants.UNINSTALL_HEADER, Resources.Culture);
            UninstallText = resource.GetString(Constants.UNINSTALL_TEXT, Resources.Culture);
        }

        /// <summary>
        /// Sets the content of the Button based on installers.
        /// </summary>
        /// <param name="resource"></param>
        public override void SetPageButtonTexts(ResourceManager resource)
        {
            SelectionScreenButtonCancelText = resource.GetString(Constants.SELECTION_SCREEN_BUTTON_CANCEL_TEXT, Resources.Culture);
            UninstallScreenButtonUninstallText = resource.GetString(Constants.UNINSTALL_SCREEN_BUTTON_UNINSTALL_TEXT, Resources.Culture);
        }

        #endregion

        #region IDisposable

        /// <summary>
        /// Disposes the subscribed event.
        /// </summary>
        public void Dispose()
        {
            appsControViewModel.ApplicationsExited -= OnApplicationsExited;
        }

        #endregion
    }
}
