﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespaces

using Prism.Commands;
using System.ComponentModel.Composition;
using System.Windows.Input;
using Installer.Core.Core;
using Installer.Core.Interfaces;
using Installer.Core.Core.Handler;
using System.Windows.Media.Imaging;

#endregion

namespace Installer.Views.Common.ViewModels
{
    [Export]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public class ErrorPageViewModel : WizardPageViewModel
    {
        #region Private Members

        private string errorHeading;
        private string errorSubHeading;
        
        #endregion

        #region Constructor

        [ImportingConstructor]
        public ErrorPageViewModel(IUIInteractionService uiService,
                                  ViewNavigatorHandler nav) : base(uiService, nav)
        {
            OpenLogFileCommand = new DelegateCommand(OpenLogFile);
            OpenPelcoSupportCommand = new DelegateCommand(OpenPelcoSupportWebLink);
            ExitInstallerCommand = new DelegateCommand(ExitInstaller);
            HeaderImage = UIService.GetHeaderImage(false);
        }

        #endregion

        #region Properties
        /// <summary>
        /// sets the HeaderImage 
        /// </summary>
        public BitmapImage HeaderImage { get; set; }

        /// <summary>
        /// Gets or sets the Error heading.
        /// </summary>
        public string ErrorHeading
        {
            get
            {
                return errorHeading;
            }

            set
            {
                if (errorHeading != value)
                {
                    SetProperty(ref errorHeading, value);
                }
            }
        }

        /// <summary>
        /// Gets or sets the error sub-heading.
        /// </summary>
        public string ErrorSubHeading
        {
            get
            {
                return errorSubHeading;
            }
            set
            {
                if (errorHeading != value)
                {
                    SetProperty(ref errorSubHeading, value);
                }
            }
        }

        #endregion

        #region Commands

        /// <summary>
        /// Command to close and exit the installer.
        /// </summary>
        public ICommand ExitInstallerCommand { get; private set; }

        /// <summary>
        /// Command to open up the WIX bundle log file.
        /// </summary>
        public ICommand OpenLogFileCommand { get; private set; }

        /// <summary>
        /// Command to open the Pelco support web page.
        /// </summary>
        public ICommand OpenPelcoSupportCommand { get; private set; }

        #endregion

        #region Private Methods

        /// <summary>
        /// Executes on Exit click.
        /// </summary>
        private void ExitInstaller()
        {
            UIService.CloseUIAndExit();
        }

        /// <summary>
        /// Executes on Log file click.
        /// </summary>
        private void OpenLogFile()
        {
            ViewNavigator.GenerateErrorPageLogFileClickEvent(string.Empty);
        }

        /// <summary>
        /// Executes on link click.
        /// </summary>
        private void OpenPelcoSupportWebLink()
        {
            new Util().OpenWebBrowser(Constants.PELCO_SUPPORT_WEBSITE_LINK);
        }
        
        #endregion
    }
}
