﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespaces
using Installer.Core.Core;
using Installer.Core.Core.Events;
using Installer.Core.Core.Handler;
using Installer.Core.Interfaces;
using Installer.Core.Resources.ResourceStrings;
using Prism.Commands;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Resources;
using System.Windows.Input;
using System.Windows.Media.Imaging;
#endregion

namespace Installer.Views.Common.ViewModels
{
    [Export]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public class InstallFinishPageViewModel : WizardPageViewModel
    {
        #region Private Members

        private bool isUpgrade;
        private bool restartRequired = false;
        private bool enableConfigure;
        private string openToolBoxQuestion;
        private string openToolboxDescription;
        private string configureProQuestion;
        private string pelcoToolConfiguration;
        private string installFinishHeader;
        private string finishRestartHeader;
        private string installFinishText;
        private string upgradeFinishText;
        #endregion

        #region Constructor

        [ImportingConstructor]
        public InstallFinishPageViewModel(IUIInteractionService uiService,
                                          ViewNavigatorHandler nav) : base(uiService, nav)
        {
            isUpgrade = false;
            restartRequired = false;
            enableConfigure = false;

            CloseInstallerCommand = new DelegateCommand(Close);
            ConfigureCommand = new DelegateCommand(Configure);
            HeaderImage = UIService.GetHeaderImage(false);
            nav.EventingService.GetEvent<InstallPageFinishPropertiesEvent>().Subscribe(InstallPageFinishPropertiesEventsReceived);
        }

        #endregion

        #region Properties

        /// <summary>
        /// sets the HeaderImage 
        /// </summary>
        public BitmapImage HeaderImage { get; set; }

        public string OpenToolBoxQuestion
        {
            get { return openToolBoxQuestion; }
            set
            {
                if (openToolBoxQuestion != value)
                {
                    SetProperty(ref openToolBoxQuestion, value);
                }
            }
        }

        public string OpenToolboxDescription
        {
            get { return openToolboxDescription; }
            set
            {
                if (openToolboxDescription != value)
                {
                    SetProperty(ref openToolboxDescription, value);
                }
            }
        }

        public string ConfigureProQuestion
        {
            get { return configureProQuestion; }
            set
            {
                if (configureProQuestion != value)
                {
                    SetProperty(ref configureProQuestion, value);
                }
            }
        }

        public string PelcoToolConfiguration
        {
            get { return pelcoToolConfiguration; }
            set
            {
                if (pelcoToolConfiguration != value)
                {
                    SetProperty(ref pelcoToolConfiguration, value);
                }
            }
        }


        /// <summary>
        /// Retrieves the flag indicating if the configuration button should be enabled. 
        /// </summary>
        public bool EnableConfigure
        {
            get { return enableConfigure; }
            private set { SetProperty(ref enableConfigure, value); }
        }

        /// <summary>
        /// Indicates that the installation was due to an upgrade.
        /// </summary>
        public bool IsUpgrade
        {
            get { return isUpgrade; }
            private set { SetProperty(ref isUpgrade, value); }
        }

        /// <summary>
        /// Retrieves the flag indicating if a restart is required.
        /// </summary>
        public bool RestartRequired
        {
            get { return restartRequired; }
            private set { SetProperty(ref restartRequired, value); }
        }

        /// <summary>
        /// Gets and sets InstallFinishHeader
        /// </summary>
        public string InstallFinishHeader
        {
            get { return installFinishHeader; }
            set
            {
                if (installFinishHeader != value)
                {
                    SetProperty(ref installFinishHeader, value);
                }
            }
        }

        /// <summary>
        /// Gets and sets FinishRestartHeader
        /// </summary>
        public string FinishRestartHeader
        {
            get { return finishRestartHeader; }
            set
            {
                if (finishRestartHeader != value)
                {
                    SetProperty(ref finishRestartHeader, value);
                }
            }
        }

        /// <summary>
        /// Gets and sets FinishRestartHeader
        /// </summary>
        public string InstallFinishText
        {
            get { return installFinishText; }
            set
            {
                if (installFinishText != value)
                {
                    SetProperty(ref installFinishText, value);
                }
            }
        }
        /// <summary>
        /// Gets and sets FinishRestartHeader
        /// </summary>
        public string UpgradeFinishText
        {
            get
            {
                return upgradeFinishText;
            }

            set
            {
                if (upgradeFinishText != value)
                {
                    SetProperty(ref upgradeFinishText, value);
                }
            }
        }

        #endregion

        #region Commands

        /// <summary>
        /// Command to exit and close the installer
        /// </summary>
        public ICommand CloseInstallerCommand { get; private set; }

        /// <summary>
        /// Command to open the configure page
        /// </summary>
        public ICommand ConfigureCommand { get; private set; }


        #endregion

        #region Public Methods


        /// <summary>
        /// Executes before navigating to the page
        /// </summary>
        public override void OnNavigateTo()
        {
            //No operation.
        }

        /// <summary>
        /// Sets the Page contents.
        /// </summary>
        /// <param name="resource"></param>
        public override void SetPageTexts(ResourceManager resource)
        {
            InstallFinishHeader = resource.GetString(Constants.INSTALL_FINISH_HEADER, Resources.Culture);
            FinishRestartHeader = resource.GetString(Constants.FINISH_RESTART_HEADER, Resources.Culture);
            InstallFinishText = resource.GetString(Constants.INSTALL_FINISH_TEXT, Resources.Culture);
            UpgradeFinishText = resource.GetString(Constants.UPGRADE_FINISH_TEXT, Resources.Culture);
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Close command action.
        /// </summary>
        private void Close()
        {
            UIService.CloseUIAndExit();
        }

        /// <summary>
        /// Configure command action
        /// </summary>
        private void Configure()
        {
            if (EnableConfigure)
            {
                //No operation
            }
        }

        /// <summary>
        /// Executes when the page properties are received from the custom installer.
        /// </summary>
        /// <param name="progressPageProperties"></param>
        private void InstallPageFinishPropertiesEventsReceived(Dictionary<string, object> uninstallPageFinishProperties)
        {
            foreach (var prop in uninstallPageFinishProperties)
            {
                switch (prop.Key.ToString())
                {
                    case Constants.IS_UPGRADE:
                        IsUpgrade = Convert.ToBoolean(prop.Value);
                        break;
                    case Constants.RESTART_REQUIRED:
                        RestartRequired = Convert.ToBoolean(prop.Value);
                        break;
                    default: break;
                }
            }
        }
        #endregion
    }
}
