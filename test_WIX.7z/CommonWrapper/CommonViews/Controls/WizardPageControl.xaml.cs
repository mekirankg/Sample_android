﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespaces

using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;
using Installer.Core.Enums;
using Installer.Core.Core.Handler;

#endregion

namespace Installer.Views.Common.Controls
{
    /// <summary>
    /// Interaction logic for WizardPageControl.xaml
    /// </summary>
    public partial class WizardPageControl : UserControl
    {
        #region Private Members

        private Stack<UserControl> pages;

        #endregion

        #region Public Members

        public static readonly DependencyProperty TransitionProperty = DependencyProperty.Register("TransitionType",
                                                                                                  typeof(PageTransition),
                                                                                                  typeof(WizardPageControl),
                                                                                                  new PropertyMetadata(PageTransition.FadeAndSlide));

        #endregion

        #region Constructor

        public WizardPageControl()
        {
            InitializeComponent();
            pages = new Stack<UserControl>();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Sets the page transition type.
        /// </summary>
        public PageTransition TransitionType
        {
            get
            {
                return (PageTransition)GetValue(TransitionProperty);
            }
            set
            {
                SetValue(TransitionProperty, value);
            }
        }

        /// <summary>
        /// Gets and sets the current wizard page.
        /// </summary>
        private UserControl CurrentPage { get; set; }
        #endregion

        #region Private Methods        

        /// <summary>
        /// Shows the next wizard page.
        /// </summary>
        private void ShowNewPage()
        {
            Dispatcher.Invoke((Action)delegate
            {
                if (contentPresenter.Content != null)
                {
                    UserControl oldPage = contentPresenter.Content as UserControl;

                    if (oldPage != null)
                    {
                        oldPage.Loaded -= newPage_Loaded;
                        UnloadPage(oldPage);
                    }
                }
                else
                {
                    ShowNextPage();
                }

            });
        }

        /// <summary>
        /// Called to show the next page.
        /// </summary>
        private void ShowNextPage()
        {
            UserControl newPage = pages.Pop();
            newPage.Loaded += newPage_Loaded;
            contentPresenter.Content = newPage;
        }

        /// <summary>
        /// Called to unload the currently shown page (transition off screen)
        /// </summary>
        /// <param name="page"></param>
        private void UnloadPage(UserControl page)
        {
            string resourceName = string.Format("{0}Out", TransitionType.ToString());
            if (ViewNavigatorHandler.IsReverseAnimationNeeded)
            {
                resourceName = string.Format("{0}OutRev", TransitionType.ToString());
            }

            if (TransitionType != PageTransition.NoAnimation)
            {
                Storyboard hidePage = (Resources[resourceName] as Storyboard).Clone();
                hidePage.Completed += hidePage_Completed;
                hidePage.Begin(contentPresenter);
            }
            else
            {
                // We are not executing a transition so we need to ensure
                // the page is still changed
                hidePage_Completed(this, null);
            }
        }

        /// <summary>
        /// Called when the new page is being loaded by WPF.  This will transition the new page on screen.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void newPage_Loaded(object sender, RoutedEventArgs e)
        {
            string resourceName = string.Format("{0}In", TransitionType.ToString());
            if (ViewNavigatorHandler.IsReverseAnimationNeeded)
            {
                resourceName = string.Format("{0}InRev", TransitionType.ToString());
            }

            if (TransitionType != PageTransition.NoAnimation)
            {
                Storyboard showNewPage = Resources[resourceName] as Storyboard;
                showNewPage.Begin(contentPresenter);
                ViewNavigatorHandler.IsReverseAnimationNeeded = false;
            }

            CurrentPage = sender as UserControl;
        }

        /// <summary>
        /// Called when the page has been hidden. This will set the page content to null,
        /// and then begin the transition to the next page.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void hidePage_Completed(object sender, EventArgs e)
        {
            contentPresenter.Content = null;
            ShowNextPage();
        }

        #endregion

        #region Public Methods        

        /// <summary>
        /// Show the provided wizard page.
        /// </summary>
        /// <param name="newPage"></param>
        public void ShowPage(UserControl newPage)
        {
            pages.Push(newPage);

            Task.Run(() => ShowNewPage());
        }

        #endregion
    }
}
