﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespaces

using System.Windows.Controls;

#endregion

namespace Installer.Views.Common.Controls
{
    #region Constructor

    /// <summary>
    /// Interaction logic for ApplicationProcessControl.xaml
    /// </summary>
    public partial class ApplicationProcessControl : UserControl
    {
        public ApplicationProcessControl()
        {
            InitializeComponent();
        }
    }

    #endregion
}
