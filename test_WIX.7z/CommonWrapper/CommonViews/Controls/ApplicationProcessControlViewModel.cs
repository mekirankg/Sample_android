﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespaces

using Prism.Commands;
using Prism.Mvvm;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel.Composition;
using System.Threading.Tasks;
using System.Windows.Input;
using Installer.Core.Interfaces;
using Installer.Core.Core.Handler;

#endregion

namespace Installer.Views.Common.Controls
{
    /// <summary>
    /// View model for the Running applications user control
    /// </summary>
    [Export]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public class ApplicationProcessControlViewModel : BindableBase, IDisposable
    {
        #region Private Members

        private readonly object appsLock = new object();
        private string title;
        private ObservableCollection<string> runningProcesses;

        #endregion

        #region Public Members

        /// <summary>
        /// Event handler for registering for application exit events.
        /// </summary>
        public EventHandler ApplicationsExited;

        #endregion

        #region Constructor

        [ImportingConstructor]
        public ApplicationProcessControlViewModel(ApplicationHandler appManager, IUIInteractionService uiService)
        {
            ExitApplicationsCommand = new DelegateCommand(ExitApps);

            UIService = uiService;

            ApplicationsManager = appManager;
            ApplicationsManager.ApplicationExitedEvent += ApplicationsManager_ApplicationExitedEvent;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets and sets the title text to show on the associated view.
        /// </summary>
        public string Title
        {
            get
            {
                return title;
            }

            set
            {
                if (title != value)
                {
                    SetProperty(ref title, value);
                }
            }
        }

        /// <summary>
        /// Return the currently running applications.
        /// </summary>
        public ObservableCollection<string> RunningApplications
        {
            get
            {
                if (runningProcesses == null)
                {
                    runningProcesses = new ObservableCollection<string>();
                }

                return runningProcesses;
            }
        }

        /// <summary>
        /// Indicates if any of the applications are running.
        /// </summary>
        public bool AreAnyApplicationsRunning
        {
            get
            {
                return ApplicationsManager.AreAnyApplicationsRunning;
            }
        }

        /// <summary>
        /// Gets and sets the Processes manager used to manage the running Vx Applications.
        /// </summary>
        private ApplicationHandler ApplicationsManager;

        /// <summary>
        /// Gets and sets the UI service
        /// </summary>
        private IUIInteractionService UIService;

        #endregion

        #region Commands

        /// <summary>
        /// Command to exit any running Vx applications
        /// </summary>
        public ICommand ExitApplicationsCommand { get; private set; }

        #endregion

        #region Public Methods

        /// <summary>
        /// Refreshes the state of the view model.  Will check if the processes are running or not
        /// and will update the UI if needed.
        /// </summary>
        public void Refresh()
        {
            ApplicationsManager.ReInit();

            // Must modify the Observable collection on the UI thread.
            UIService.RunOnUIThreadAsync(() =>
            {
                lock (appsLock)
                {
                    // Clear so we can rebuild.
                    RunningApplications.Clear();

                    // Add the currently running applications to the view
                    foreach (var app in ApplicationsManager.RunningApplications)
                    {
                        RunningApplications.Add(app);
                    }
                }
            });
        }

        public void ExitApps()
        {
            Task.Run(() => ApplicationsManager.ShutdownAllApplications());
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Notifies the Application exited event.
        /// </summary>
        private void NotifyApplicationsExited()
        {
            if (!ApplicationsManager.AreAnyApplicationsRunning)
            {
                ApplicationsExited?.Invoke(this, EventArgs.Empty);
            }
        }

        #endregion

        #region Process Exit Handlers       

        /// <summary>
        /// Called when the application processes has shutdown.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ApplicationsManager_ApplicationExitedEvent(object sender, EventArgs e)
        {
            NotifyApplicationsExited();
        }

        #endregion

        #region IDisposable

        /// <summary>
        /// Disposes the event registered.
        /// </summary>
        public void Dispose()
        {
            ApplicationsManager.ApplicationExitedEvent -= ApplicationsManager_ApplicationExitedEvent;
        }

        #endregion
    }
}
