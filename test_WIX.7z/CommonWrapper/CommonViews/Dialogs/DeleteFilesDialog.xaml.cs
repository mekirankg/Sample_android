﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */

#region Namespaces
using System.Windows;
#endregion

namespace Installer.Views.Common.Dialogs
{
    /// <summary>
    /// Interaction logic for DeleteFilesDialog.xaml
    /// </summary>
    public partial class DeleteFilesDialog : Window
    {
        #region Constructor

        public DeleteFilesDialog()
        {
            Proceed = false;

            InitializeComponent();
        }

        #endregion

        #region  Properties

        /// <summary>
        /// Flag indicating if the user selected the proceed button
        /// </summary>
        public bool Proceed { get; set; }

        #endregion

        #region Private Methods

        /// <summary>
        /// Executes when the cancel button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            Proceed = false;
            Close();
        }

        /// <summary>
        /// Executes when the proceed button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ProceedButton_Click(object sender, RoutedEventArgs e)
        {
            Proceed = true;
            Close();
        }

        /// <summary>
        /// Executes when the window load is complete
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            CancelButton.Focus();
        }

        #endregion
    }
}
