﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */

#region Namespaces
using System.Windows;
#endregion

namespace Installer.Views.Common.Dialogs
{
    /// <summary>
    /// Interaction logic for EulaView.xaml
    /// </summary>
    public partial class EulaDialog : Window
    {
        #region Constructor

        public EulaDialog()
        {
            InitializeComponent();
        }
        public EulaDialog(string LicenseText,string eulaTitle)
        {
            InitializeComponent();
            txtbkLicenseAgreement.Text = LicenseText;
            txtbkEulaTitle.Text = eulaTitle;
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Executes when the OK button is clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        #endregion
    }
}
