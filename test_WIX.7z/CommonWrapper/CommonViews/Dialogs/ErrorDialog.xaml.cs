﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */

#region Namespaces
using System.Windows;
#endregion
namespace Installer.Views.Common.Dialogs
{
    /// <summary>
    /// Interaction logic for ErrorDialog.xaml
    /// </summary>
    public partial class ErrorDialog : Window
    {
        #region Constructor

        /// <summary>
        /// Creates a new error dialog.
        /// </summary>
        /// <param name="errorMessage">The error message to display</param>
        public ErrorDialog(string errorMessage)
        {
            errorMsgText.Text = errorMessage;
            InitializeComponent();
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Executes when the OK button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            // Close the dialog when the ok button is clicked.
            this.Close();
        }

        #endregion
    }
}
