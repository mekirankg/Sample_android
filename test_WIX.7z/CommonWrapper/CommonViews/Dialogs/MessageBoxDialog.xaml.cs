﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespaces
using System.Windows;
using Installer.Views.Common.ViewModels;
#endregion

namespace Installer.Views.Common.Dialogs
{
    /// <summary>
    /// Interaction logic for MessageBoxDialog.xaml
    /// </summary>
    public partial class MessageBoxDialog : Window
    {
        #region Constructor

        public MessageBoxDialog(MessageBoxDialogViewModel viewModel)
        {
            DataContext = viewModel;
            InitializeComponent();
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Executes when the cancel button is clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            // Close the message box
            Dispatcher.Invoke(() => Close());
        }

        #endregion
    }
}
