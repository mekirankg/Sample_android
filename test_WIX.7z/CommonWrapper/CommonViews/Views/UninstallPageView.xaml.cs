﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/
#region Namespaces
using System.ComponentModel.Composition;
using System.Windows.Controls;
using Installer.Views.Common.ViewModels;
using Installer.Core.Interfaces;
#endregion

namespace Installer.Views.Common.Views
{
    /// <summary>
    /// Interaction logic for UninstallView.xaml
    /// </summary>
    [Export(typeof(IWizardPage))]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public partial class UninstallPageView : UserControl, IWizardPage
    {
        #region Constructor

        public UninstallPageView()
        {
            InitializeComponent();
        }

        [ImportingConstructor]
        public UninstallPageView(UninstallPageViewModel viewModel)
        {
            InitializeComponent();

            DataContext = viewModel;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the page's name.
        /// </summary>
        public string PageName
        {
            get
            {
                return this.GetType().Name;
            }
        }

        #endregion
    }
}

