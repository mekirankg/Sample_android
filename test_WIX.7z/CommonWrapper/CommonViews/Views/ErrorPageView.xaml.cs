﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespaces
using System.ComponentModel.Composition;
using System.Windows;
using System.Windows.Controls;
using Installer.Core.Interfaces;
using Installer.Views.Common.ViewModels;
#endregion

namespace Installer.Views.Common.Views
{
    /// <summary>
    /// Interaction logic for ErrorView.xaml
    /// </summary>
    [Export(typeof(IWizardPage))]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public partial class ErrorPageView : UserControl, IWizardPage
    {
        #region Constructor

        public ErrorPageView()
        {
            InitializeComponent();
        }

        [ImportingConstructor]
        public ErrorPageView(ErrorPageViewModel viewModel)
        {
            InitializeComponent();

            DataContext = viewModel;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the name of this page.
        /// </summary>
        public string PageName
        {
            get
            {
                return this.GetType().Name;
            }
        }

        #endregion

        #region Methods

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            btnExit.Focus();
        }

        #endregion
    }
}
