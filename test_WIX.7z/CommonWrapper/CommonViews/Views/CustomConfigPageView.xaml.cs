﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespaces
using Installer.Views.Common.ViewModels;
using Installer.Core.Interfaces;
using System.ComponentModel.Composition;
using System.Windows;
using System.Windows.Controls;
#endregion

namespace Installer.Views.Common.Views
{
    /// <summary>
    /// Interaction logic for InstallerSelectionCustomView.xaml
    /// </summary>
    [Export(typeof(IWizardPage))]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public partial class CustomConfigPageView : UserControl, IWizardPage
    {
        #region Constructor

        public CustomConfigPageView()
        {
            InitializeComponent();
        }

        [ImportingConstructor]
        public CustomConfigPageView(CustomConfigPageViewModel viewModel)
        {
            InitializeComponent();

            DataContext = viewModel;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Returns the name of this page.
        /// </summary>
        public string PageName
        {
            get
            {
                return this.GetType().Name;
            }
        }

        #endregion

        #region Methods

        private void ConfigPage_Loaded(object sender, RoutedEventArgs e)
        {
            txtbxDirectory.Focus();
        }

        #endregion
    }
}
