﻿
/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespace
using System.ComponentModel.Composition;
using System.Windows.Controls;
using Installer.Views.Common.ViewModels;
using Installer.Core.Interfaces;
#endregion

namespace Installer.Views.Common.Views
{
    /// <summary>
    /// Interaction logic for ComponentUpgradePageView.xaml
    /// </summary>
    [Export(typeof(IWizardPage))]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public partial class ComponentUpgradePageView : UserControl, IWizardPage
    {
        #region Constructor

        public ComponentUpgradePageView()
        {
            InitializeComponent();
        }

        [ImportingConstructor]
        public ComponentUpgradePageView(ComponentUpgradePageViewModel viewModel)
        {
            InitializeComponent();

            DataContext = viewModel;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Returns the name of this page.
        /// </summary>
        public string PageName
        {
            get
            {
                return this.GetType().Name;
            }
        }

        #endregion
    }
}
