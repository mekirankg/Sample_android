﻿/**
* Copyright (c) 2017 Pelco. All rights reserved.
*
* This file contains trade secrets of Pelco. No part may be reproduced or
* transmitted in any form by any means or for any purpose without the express
* written permission of Pelco.
*/

#region Namespaces
using System.ComponentModel.Composition;
using System.Windows.Controls;
using Installer.Core.Interfaces;
using Installer.Views.Common.ViewModels;
#endregion

namespace Installer.Views.Common.Views
{
    /// <summary>
    /// Interaction logic for InstallFinishView.xaml
    /// </summary>
    [Export(typeof(IWizardPage))]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public partial class InstallFinishPageView : UserControl, IWizardPage
    {
        #region Constructor

        public InstallFinishPageView()
        {
            InitializeComponent();
        }        

        [ImportingConstructor]
        public InstallFinishPageView(InstallFinishPageViewModel viewModel)
        {
            InitializeComponent();

            DataContext = viewModel;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Returns the page's name
        /// </summary>
        public string PageName
        {
            get
            {
                return this.GetType().Name;
            }
        }

        #endregion
    }
}
