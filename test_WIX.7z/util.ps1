#borrowed and modified from http://www.shilony.net/2013/06/15/build-automation-with-powershell-and-psake/
function get-projects
{
    [CmdletBinding()]
    param(
        [Parameter(Position=0, Mandatory=$true)][String]$solution,
        [Parameter(Position = 0, Mandatory = $false)][String]$ProjectExt = "csproj"
    )

    $paths = new-object System.Collections.Generic.List[PSObject]

    # Gets the project files based on a given file's extension
    $projFiles = @(get-childitem "$baseDir" -recurse -filter "*.$ProjectExt")

    $soluProjFiles=Get-Content $solution |
        Select-String 'Project\(' |
        ForEach-Object {
            $projectParts = $_ -Split '[,=]' | ForEach-Object { $_.Trim('[ "{}]') };
            New-Object PSObject -Property @{
            Name = $projectParts[1];
            File = $projectParts[2];
            }
        }

    foreach($file in $projFiles)
    {
        foreach($spfile in $soluProjFiles)
        {
            if(($spfile.Name + ".csproj") -match $file.Name)
            {
                $projDir = $file.Directory
                $fullName = $file.FullName
                $bin = "$projDir\bin\$script:config\"
                $projDocument = new-object XML
                #$projDocument.PreserveWhitespace = $true
                $projDocument.Load($fullName)
                #write-host $projDocument.InnerXml

                # Checks that xUnit is referenced so we can determine whether it's a project that may contain tests
                #$isTestProject = ($projDocument.Project.ItemGroup.Reference | where { $_."Include" -eq "xunit" }) -ne $null
                # I wasn't able to drill down with the above method so I had to try the ugliness below:
                $references = $projDocument.Project.ChildNodes | ? { $_.LocalName -eq "ItemGroup" } | % { $_.ChildNodes } | ? { $_.LocalName -eq "Reference" }
                #$references | % { write-host $_."Include" }
                $isTestProject = ($references | where { $_."Include".StartsWith("xunit") }) -ne $null

                # Gets the assembly's name out of the project's file
                $assemblyName = ($projDocument.Project.PropertyGroup | where { $_.AssemblyName -ne $null }).AssemblyName

                $paths.Add(@{
                    File = $file;
                    Directory = $projDir;
                    FullName = $fullName;
                    ProjectOutput = $bin;
                    ReleaseOutput = "$artifactsPath\";
                    AssemblyName = $assemblyName;
                    IsTestProject = $isTestProject
                })
            }
        }
    }
    
    return $paths;
}

function run-msbuild
{
    [CmdletBinding()]
    param(
        [Parameter(Position=0, Mandatory=$true)][String]$solution,
        [Parameter(Position=1, Mandatory=$true)][String]$target,
        [Parameter(Position=2, Mandatory=$true)][String]$configuration,
        [Parameter(Position=3, Mandatory=$true)][String]$platform,
        [Parameter(Position=4, Mandatory=$false)][String]$productVersion,
        [Parameter(Position=5, Mandatory=$false)][String]$signOutput,
		[Parameter(Position=6, Mandatory=$false)][String]$solutiondir
    )

    Write-Host "Building " $configuration " version: " $productVersion -foregroundcolor "Green"

    #debugging
    #$target
    #$configuration
    
    # Bamboo needs the full path passed in
    $msbuild = $env:bamboo_capability_system_builder_msbuild_MSBuild_v14_0__64bit_
    if ($msbuild -eq $null)
    {
        Write-Host "MSBUILD not found in environment variable, falling back to msbuild.exe"
        # below command will pick up old .NET versions, just let it resolve by itself
        # $msbuild = Join-Path $([System.Runtime.InteropServices.RuntimeEnvironment]::GetRuntimeDirectory()) "msbuild.exe"
        $msbuild = "msbuild.exe"
    }
    #$msbuild
    
    Write-Host "MSBUILD = " $msbuild
    
    #$buildArgs = $solutionFile, "/t:$target", "/p:Configuration=$configuration", "/p:Platform=""$platform""", "/v:$msbuildVerbosity", "/m:$msbuildCpuCount", "/p:BuildInParallel=$msbuildParallel"    
    $buildArgs = $solution, "/t:$target", "/p:Configuration=$configuration", "/v:$msbuildVerbosity", "/m:$msbuildCpuCount", "/p:BuildInParallel=$msbuildParallel", "/nr:false", "/p:ProductVersion=$productVersion", "/p:SignOutput=$signOutput","/p:Solutiondir=$solutiondir"
    #$buildArgs
    #$productVersion
    exec-and-wait -target $msbuild -arguments $buildArgs
}

function get-revision
{
    return ((svn info | select-string -pattern "Revision" -SimpleMatch) -split " ")[1].Trim()
}
function elapsed-time
{
  [CmdletBinding()]
    param(
        [Parameter(Position=0, Mandatory=$true)][datetime]$start,
        [Parameter(Position=1, Mandatory=$false)][String]$msg
    )

    #elapsed is weird to type. elapsed elapsed elapsed
    $elapsed = $(Get-Date) - $start
    $elapsedString = $([string]::Format("{0:d2}:{1:d2}.{1:d3}", $elapsed.Minutes, $elapsed.Seconds, $elapsed.Milliseconds))
    return "$elapsedString elapsed: $msg"
}

# On Bamboo, powershell scripts don't wait for completion when they call outside executables.
function exec-and-wait
{
   [CmdletBinding()]
    param(
        [Parameter(Position=0, Mandatory=$true)][String]$target,
        [Parameter(Position=1, Mandatory=$false)][String[]]$arguments
    )

    #debugging
    #$target
    #$arguments
    
    $startTime = Get-Date
    $global:LastExitCode = 0
    $procExitCode = 0
    $process = Start-Process -FilePath $target -ArgumentList $arguments -NoNewWindow -PassThru
    Wait-Process -InputObject $process -timeout $timeoutSeconds
    #elapsed-time -start $startTime -msg "finished waiting for $target"
    if (!$process.hasExited) {
        Stop-Process -Force -Id $process.ID
        elapsed-time -start $startTime -msg "forced stop-process on $target"
    }

    $procExitCode = $process.ExitCode
    #write-host "$target LastExitCode=$LastExitCode `$_=$_ process.ExitCode=$procExitCode"

    #aha! msbuild sets the process exit code but powershell doesn't notice
    if ($procExitCode -ne 0)
    {
        $global:LastExitCode = $procExitCode
    }
    
    if ($LastExitCode -ne 0)
    {
        throw "$target failed with exit code $LastExitCode."
    }
}

#Starts a process and redirects the output to a file from which it is read and returned.
function exec-and-wait-and-getoutput
{
   [CmdletBinding()]
    param(
        [Parameter(Position=0, Mandatory=$true)][String]$target,
        [Parameter(Position=1, Mandatory=$true)][String]$outputPath,
        [Parameter(Position=2, Mandatory=$false)][String[]]$arguments
    )

    #debugging
    #$target
    #$arguments
    
    $startTime = Get-Date
    $global:LastExitCode = 0
    $procExitCode = 0
    $outFile = "$outputPath\result.txt"
    $process = Start-Process -FilePath $target -ArgumentList $arguments -NoNewWindow -PassThru -RedirectStandardOutput $outFile
    Wait-Process -InputObject $process -timeout $timeoutSeconds
    #elapsed-time -start $startTime -msg "finished waiting for $target"
    if (!$process.hasExited) {
        Stop-Process -Force -Id $process.ID
        elapsed-time -start $startTime -msg "forced stop-process on $target"
    }

    $procExitCode = $process.ExitCode
    #write-host "$target LastExitCode=$LastExitCode `$_=$_ process.ExitCode=$procExitCode"
    $output = Get-Content -Path $outFile
    
    #Removes the file generated to get output
    Remove-Item $outFile -recurse -ErrorAction Ignore
    
    #aha! msbuild sets the process exit code but powershell doesn't notice
    if ($procExitCode -ne 0)
    {
        $global:LastExitCode = $procExitCode
    }
    
    if ($LastExitCode -ne 0)
    {
        throw "$target failed with exit code $LastExitCode."
    }
    else
    {
        return $output
    }
}


function Update-GlobalAssemblyInfo($svnrevision, $buildnumber, $assemblyInfo)
{     
    #Param
    #(
    #    [string]$svnrevision,
    #    [string]$buildnumber
    #    [string]$assemblyInfo
    #)

    $fileContent = Get-Content $assemblyInfo
    
    if(!$fileContent)
    {
        return "FileError:Update-GlobalAssemblyInfo"
    }

    $matchFound = $fileContent -match $AssemblyFileVersionPattern
    
    if(!$matchFound)
    {
        return "MatchError:Update-GlobalAssemblyInfo"
    }        

    $tmpFile = $fileContent -replace $AssemblyFileVersionPattern, "`$1""`$2.`$3.$svnrevision.$buildnumber"

    $matchVersionFound = $tmpFile -match $AssemblyVersionPattern

    if ($matchVersionFound)
    {
         $tmpFile = $tmpFile -replace $AssemblyVersionPattern, "`$1""`$2.`$3.$svnrevision.$buildnumber"
    }

    if(!$tmpFile)
    {
        return "ReplaceError:Update-GlobalAssemblyInfo"
    }   
    
    $tmpFile | out-file $assemblyInfo
    
    return $null
}

function Get-ProductVersion($assemblyInfo)
{      
    $fileContent = Get-Content $assemblyInfo
    
    if(!$fileContent)
    {
        return "FileError:Get-ProductVersion"
    }
    
    $fileMajorVersion = $fileContent | select-string -pattern $AssemblyFileVersionPattern | %{$_.Matches[0].Groups[2].Value}
    $fileMinfoVersion = $fileContent | select-string -pattern $AssemblyFileVersionPattern | %{$_.Matches[0].Groups[3].Value}
    $fileBuildVersion = $fileContent | select-string -pattern $AssemblyFileVersionPattern | %{$_.Matches[0].Groups[4].Value}
    $fileSvnRevision = $fileContent | select-string -pattern $AssemblyFileVersionPattern | %{$_.Matches[0].Groups[5].Value}
    
    return $fileMajorVersion + "." + $fileMinfoVersion + "." + $fileBuildVersion + "." + $fileSvnRevision
}

function upload-release
{
   [CmdletBinding()]
    param(
        [Parameter(Position=0, Mandatory=$true)][String]$nightly,
        [Parameter(Position=1, Mandatory=$true)][String]$outputDir
    )

    if (!$env:BUILD_UTILS_DIR)
    {
        throw "BUILD_UTILS_DIR not defined"
    }
    
    #see https://svn.pelco.org/repos/buildrelease/tools/scripts/buildtools/upload-release.rb
    $uploadScript = "$env:BUILD_UTILS_DIR\upload-release.rb" 

    $group = "videoexpert"
    #Updated to pass the directory in as a parameter
    #$outputDir = "$baseDir\InstallerBootstrap\bin\$script:config\"

    #set required environment variables
    $env:COMPONENT_NAME = "$componentName"
    $env:VERSION_NUM = "$majorVersion.$minorVersion"
    $env:BUILD_ID = "$env:VERSION_NUM.$env:SVN_REVISION.$env:BUILD_NUMBER"
    $env:ARTIFACT_TYPE = "image"
    $env:BUILD_TYPE = "release"
    $env:NIGHTLY = "$nightly"

    $rubyExe = "ruby"
    $uploadArgs = "$uploadScript", "$group", "$outputDir"

    exec-and-wait -target $rubyExe -arguments $uploadArgs
    
    #expect binary to be uploaded to https://release.pelco.org/?dir=/software/pre-release/current/nightly/products/videoexpert/componentName/majorVersion.minorVersion/majorVersion.minorVersion.SVN_REVISION.BUILD_NUMBER/release
    # or  https://release.pelco.org/?dir=/software/pre-release/current/manual/products/videoexpert/{componentName}/{majorVersion}.{minorVersion}/majorVersion.minorVersion.SVN_REVISION.BUILD_NUMBER/release
}

function Download-File($uri, $filePath) 
{
    $url = [uri]$uri
    $sourceIdentifier = [guid]::NewGuid()
    If (Test-Path $filePath)
    {
        Write-Host "Skipping GET for $filePath" -foregroundcolor "magenta"
    }
    Else 
    {
        Write-Host "$filePath does not exist." -foregroundcolor "magenta"
        Write-Host "Attempting to download $url" -foregroundcolor "magenta"
        $start_time = Get-Date
        $client = New-Object System.Net.WebClient

        try 
        {
            Register-ObjectEvent -InputObject $client -EventName "DownloadFileCompleted" -SourceIdentifier $sourceIdentifier
            $client.DownloadFileAsync($url, $filePath)
            Wait-Event -SourceIdentifier $sourceIdentifier
        }
        finally 
        {
            $client.Dispose()
            Unregister-Event -SourceIdentifier $sourceIdentifier
        }

        Write-Host "Time taken: $((Get-Date).Subtract($start_time).Milliseconds) Milliseconds(s)" -foregroundcolor "magenta"
    }
}

Add-Type -AssemblyName System.IO.Compression.FileSystem
function Extract-Files($source, $destination)
{
    Write-Host "Extracting the files from $source to $destination."
    Remove-Item $destination -recurse -ErrorAction Ignore
    [System.IO.Compression.ZipFile]::ExtractToDirectory($source, $destination)
}

# Fetching build number from http://buildops.pelco.org/api/builds server.
function GetBuildNumber($componentName,$baseVersion,$branch)
{
    #Param
    #(
    #    [string]$componentName,
    #    [string]$baseVersion
    #    [string]$branch
    #)
    $body = @{
      component=$componentName
      version_base=$baseVersion
      branch=$branch
      revision=''
    }
    $json = $body | ConvertTo-Json
    $response = Invoke-RestMethod 'http://buildops.pelco.org/api/builds' -Method Post -Body $json -ContentType 'application/json'
    Write-Host "reponse is "
    Write-Host $response
    return $response.number
}

function Replace-Substring($parentstring,$substring1,$substring2)
{
    $newstring = $parentstring.Replace($substring1, $substring2)
    return $newstring
}
