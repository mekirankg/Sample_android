﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */

#region Namespaces

using Installer.Core.Core;
using Installer.Core.Enums;
using Installer.Core.Interfaces;
using Microsoft.Tools.WindowsInstallerXml.Bootstrapper;
using Microsoft.Win32;
using Newtonsoft.Json;
using OCCCustomInstaller.Constants;
using System;
using System.Diagnostics;
using System.IO;
using System.Linq;

#endregion

namespace OCCCustomInstaller.Model
{
    /// <summary>
    /// Class holds the model for the Bundle.
    /// </summary>
    public class BundleModel : ILogger
    {
        #region Constructor

        public BundleModel(Bundle bundle, BootstrapperApplication app)
        {
            App = app;
            BundleInfo = bundle;
            InstallerExitCode = 0;
            RestartState = ApplyRestart.None;
            InstallInfo = new InstallationInfo();

            VxPlayerInstallFolder = GetProgramFilesFolder(@"Pelco\VideoXpert\VxPlayer");
            OpsCenterInstallFolder = GetProgram64FilesFolder(@"Pelco\VideoXpert\VxOpsCenter");
        }

        #endregion

        #region Properties

        /// <summary>
        /// Retrieves information about the current executing bundle
        /// </summary>
        public Bundle BundleInfo { get; private set; }

        /// <summary>
        /// Retrieves information about and installed OpsCenter instance.
        /// </summary>
        public InstallationInfo InstallInfo { get; private set; }

        /// <summary>
        /// Gets and sets the installation mode.
        /// </summary>
        public InstallationMode InstallMode { get; set; }

        /// <summary>
        /// Gets the OpsCenter installatin info file path.
        /// </summary>
        public string OpsCenterInstallationInfoFile
        {
            get
            {
                var programdataFolder = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
                return Path.Combine(Path.Combine(programdataFolder, @"Pelco\OpsCenter"), "InstallationInfo.xml");
            }
        }

        /// <summary>
        /// Indicates if VxPlayer is currently installed.
        /// </summary>
        public bool IsVxPlayerInstalled
        {
            get
            {
                return InstallInfo.IsApplicationInstalled(Resources.ResourceStrings.Resources.regPlayerPath, InstallerConstants.REGISTRY_KEYNAME_PATH, RegistryHive.CurrentUser);
            }
        }

        /// <summary>
        /// Indicates if OpsCenter is currently installed.
        /// </summary>
        public bool IsOpsCenterInstalled
        {
            get
            {
                return InstallInfo.IsApplicationInstalled(Resources.ResourceStrings.Resources.regPath, InstallerConstants.REGISTRY_KEYNAME_PATH, RegistryHive.CurrentUser);
            }
        }

        /// <summary>
        /// Get the def. installation directory.
        /// </summary>
        public string DefaultInstallationDirectory
        {
            get
            {
                return OpsCenterInstallFolder;
            }
        }

        /// <summary>
        /// Gets and sets the flag indicating if the VxPlayer should be installed.
        /// </summary>
        public bool ShouldInstallVxPlayer
        {
            get
            {
                return Engine.NumericVariables[InstallerConstants.SHOULD_INSTALL_VXPLAYER] == 1;
            }

            set
            {
                Engine.NumericVariables[InstallerConstants.SHOULD_INSTALL_VXPLAYER] = value ? 1 : 0;
            }
        }

        /// <summary>
        /// Gets and sets the installation folder for VxPlayer.
        /// </summary>
        public string VxPlayerInstallFolder
        {
            get
            {
                return Engine.StringVariables[InstallerConstants.VXPLAYER_INSTALL_FOLDER];
            }

            set
            {
                Engine.StringVariables[InstallerConstants.VXPLAYER_INSTALL_FOLDER] = SanitizePath(value);
            }
        }

        /// <summary>
        /// Gets and sets the installation folder for OpsCenter.
        /// </summary>
        public string OpsCenterInstallFolder
        {
            get
            {
                return Engine.StringVariables[InstallerConstants.OPSCENTER_INSTALL_FOLDER];
            }

            set
            {
                Engine.StringVariables[InstallerConstants.OPSCENTER_INSTALL_FOLDER] = SanitizePath(value);
            }
        }

        /// <summary>
        /// Gets and set the exit code to use when exiting the installer.
        /// </summary>
        public int InstallerExitCode { get; set; }

        /// <summary>
        /// Flag indicating if the user has requested to Cancel the installation
        /// </summary>
        public bool IsPerformCancel { get; set; }

        /// <summary>
        /// Gets and sets the installer's restart state.
        /// </summary>
        public ApplyRestart RestartState { get; set; }

        /// <summary>
        /// Flag to indicate is the Enhanced decoder used or not.
        /// </summary>
        public bool IsEnhancedDecoder { get; set; } = true;

        /// <summary>
        /// Indicates if a restart is required.
        /// </summary>
        public bool IsRestartRequired
        {
            get
            {
                return (RestartState == ApplyRestart.RestartInitiated) || (RestartState == ApplyRestart.RestartRequired);
            }
        }

        /// <summary>
        /// The installer's bootstrapper application
        /// </summary>
        public BootstrapperApplication App { get; private set; }

        /// <summary>
        /// The installer's install engine.
        /// </summary>
        public Engine Engine
        {
            get
            {
                return App.Engine;
            }
        }

        #endregion        

        #region ILogger

        /// <summary>
        /// Logs an error message
        /// </summary>
        /// <param name="msg">The message to log</param>
        public void LogError(string msg)
        {
            Log(LogLevel.Error, msg);
        }

        /// <summary>
        /// Logs a standard message
        /// </summary>
        /// <param name="msg">The message to log</param>
        public void LogStandard(string msg)
        {
            Log(LogLevel.Standard, msg);
        }

        /// <summary>
        /// Logs a debug message
        /// </summary>
        /// <param name="msg">The message to log</param>
        public void LogDebug(string msg)
        {
            Log(LogLevel.Debug, msg);
        }

        /// <summary>
        /// Logs a verbose message
        /// </summary>
        /// <param name="msg">The message to log</param>
        public void LogVerbose(string msg)
        {
            Log(LogLevel.Verbose, msg);
        }

        /// <summary>
        /// Logs a standard event.
        /// </summary>
        /// <param name="eventName">The name of the event to log</param>
        /// <param name="args">The event args to log</param>
        public void LogStandardEvent(string eventName, EventArgs args = null)
        {
            LogEvent(LogLevel.Standard, eventName, args);
        }

        /// <summary>
        /// Logs a debug event.
        /// </summary>
        /// <param name="eventName">The name of the event to log</param>
        /// <param name="args">The event args to log</param>
        public void LogDebugEvent(string eventName, EventArgs args = null)
        {
            LogEvent(LogLevel.Debug, eventName, args);
        }

        /// <summary>
        /// Logs a verbose event.
        /// </summary>
        /// <param name="eventName">The name of the event to log</param>
        /// <param name="args">The event args to log</param>
        public void LogVerboseEvent(string eventName, EventArgs args = null)
        {
            LogEvent(LogLevel.Verbose, eventName, args);
        }

        /// <summary>
        /// Logs a message 
        /// </summary>
        /// <param name="level">The log level of the message</param>
        /// <param name="msg">The message to log</param>
        public void Log(LogLevel level, string msg)
        {
            Engine.Log(level, msg);
        }

        /// <summary>
        /// Logs an event.
        /// </summary>
        /// <param name="level">The log level to log at.</param>
        /// <param name="eventName">The name of the event</param>
        /// <param name="args">The event args to log</param>
        public void LogEvent(LogLevel level, string eventName, EventArgs args = null)
        {
            Engine.Log(level, args == null
                    ? string.Format("EVENT: {0}", eventName)
                    : string.Format("EVENT: {0} ({1})", eventName, JsonConvert.SerializeObject(args)));
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Plans (defines) the installation mode.  Planning does not initiate the installation you must
        /// call Apply to start the installation.  Applying is done when a 'PlanComplete' callback is
        /// executed (defined in the ProgressPageViewModel)
        /// </summary>
        public void PlanInstallAction()
        {
            switch (InstallMode)
            {
                case InstallationMode.Uninstall:
                    ShouldInstallVxPlayer = false;
                    Engine.Plan(LaunchAction.Uninstall);
                    break;

                case InstallationMode.Repair:
                    Engine.Plan(LaunchAction.Repair);
                    break;

                case InstallationMode.Modify:
                    Engine.Plan(LaunchAction.Modify);
                    break;

                case InstallationMode.Upgrade:
                    ShouldInstallVxPlayer = true;
                    Engine.Plan(LaunchAction.Install);
                    break;
                case InstallationMode.NewInstall:
                    Engine.Plan(LaunchAction.Install);
                    break;

                default:
                    break; // no-op; should never get here; detect would have to fail.
            }
        }

        /// <summary>
        /// Kill a process locally
        /// </summary>
        /// <param name="process">Name of the process</param>
        /// <returns></returns>
        public void KillProcess(string process)
        {
            var processes = Process.GetProcessesByName(process);
            if (processes.Count() >= 1)
            {
                processes[0].Kill();
            }
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Returns a new path relative to the ProgramFiles directory.
        /// </summary>
        /// <param name="relPath"></param>
        /// <returns></returns>
        private string GetProgramFilesFolder(string relPath)
        {
            var parent = Environment.ExpandEnvironmentVariables(Installer.Core.Core.Constants.ENVIRONMENT_VAR_PRGM_FILES);
            return Path.Combine(parent, relPath);
        }

        /// <summary>
        /// Returns a new path relative to the ProgramFiles directory. 
        /// </summary>
        /// <param name="relPath"></param>
        /// <returns></returns>
        private string GetProgram64FilesFolder(string relPath)
        {
            var parent = Environment.ExpandEnvironmentVariables(Installer.Core.Core.Constants.ENVIRONMENT_VAR_PRGM64_FILES);
            return Path.Combine(parent, relPath);
        }

        /// <summary>
        /// Sanitizes directory path by removing trailing '\' characters.
        /// </summary>
        /// <param name="path">The path to sanitize</param>
        /// <returns>Sanitized path if it is set; otherwise the path passed in is returned</returns>
        private string SanitizePath(string path)
        {
            // Because of the following WIX bug we must also trim the trailing '\' character otherwise we end up with
            // hundreds of bundle processes and the installer eventually fails but the processes keep spawning.
            // https://sourceforge.net/p/wix/bugs/3190/
            return string.IsNullOrEmpty(path) ? path : path.TrimEnd('\\');
        }

        /// <summary>
        /// Returns a new path relative to the ProgramData directory.
        /// </summary>
        /// <param name="relPath"></param>
        /// <returns></returns>
        private string GetProgramDataFolder(string relPath)
        {
            var parent = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
            return Path.Combine(parent, relPath);
        }

        #endregion
    }
}
