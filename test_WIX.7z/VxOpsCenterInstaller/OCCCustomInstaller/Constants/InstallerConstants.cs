﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */

namespace OCCCustomInstaller.Constants
{

    /// <summary>
    /// Class contains the constants used in OCC installer.
    /// </summary>
    public static class InstallerConstants
    {
        #region GUID Constants

        // Application ID
        public const string AppId = "Global\\{0186FB34-4407-4B0A-9F55-5DF7D8263FA4}";
        // Shared memory name (Id)
        public const string SharedMemId = "Update-A9E914E2-6235-4D32-97BF-E7502637FD55";

        #endregion

        #region String Constants

        public const string VXPLAYER_PROCESS_NAME = "VideoXpert VxPlayer";
        public const string PROCESS_NAME = "OpsCenter";
        public const string VXPLAYER_INSTALLED = "VxPlayerInstalled";
        public const string VXPLAYER_APP_NAME = "VxPlayer";
        public const string APP_NAME = "OpsCenter";
        public const string DBG_PROCESS = "Dbg";
        public const string CFGMGR_PROCESS = "CfgMgr";
        public const string OPSCENTER_LICENSE_FILE = "LicenseTerms.txt";
        public const string VXPLAYER_INSTALL_FOLDER = "VxPlayerInstallFolder";
        public const string SHOULD_INSTALL_VXPLAYER = "ShouldInstallVxPlayerExe";
        public const string OPSCENTER_INSTALL_FOLDER = "InstallFolder";
        public const string OPSCENTER_REGISTRY_KEYPATH = @"Software\Pelco\OpsCenter";
        public const string OPSCENTER_DECODER_STATE = "OpsCenterDecoderState";
        public const string EXPORT_PLAYER_PACKAGE = "ExportPlayerPackage";
        public const string OPSCENTER_VERSION_KEY = "OpsCenterVersion";
        public const string ENHANCED_DECODER_STATUS = "UseEnhancedDecoder";
        public const string REGISTRY_KEYNAME_PATH = "Path";
        public const string CURRENT_VER_TEXT = "CurrentVersion";

        #endregion

        #region Numeric Constants

        public const int RESTART_INITIATED = 1641;
        public const int RESTART_REQUIRED = 3010;
        public const int FAILED_NOACTION_REBOOT = 350;

        #endregion

        #region Icon Path

        public const string HOME_PAGE_ICON = "pack://application:,,,/OCCCustomInstaller;component/Resources/vx-installer-header-lg.png";
        public const string INSTALLER_PAGE_ICON = "pack://application:,,,/OCCCustomInstaller;component/Resources/vx-installer-header-sm.png";

        #endregion
    }
}

