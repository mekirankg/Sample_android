properties {
    $componentName = "VxOpsCenterDebug"
    $branch = "master"
    $majorVersion = "2" 
    $minorVersion = "2" 
    $patchVersion = "0"
    $CurrentPath = resolve-path .
    $baseDir = Split-Path -Path $CurrentPath -Parent
    $toolsDir = "$baseDir\tools"
    $nugetPackageDir = "$baseDir\packages"
    $nugetConfigPath = "$baseDir\.nuget\NuGet.config"
    $nugetPath = "$toolsDir\NuGet.exe"
    $GlobalAssembyInfo = "$baseDir\VxOpsCenterInstaller\OCCCustomInstaller\Properties\AssemblyInfo.cs"
    $config = "Debug"
    $platform = "Mixed Platforms"
    $msbuildVerbosity = "minimal" # quiet, minimal, normal, detailed, diagnostic
    $msbuildParallel = $true
    if ([System.Environment]::ProcessorCount -gt 1) {
        $msbuildCpuCount = [System.Environment]::ProcessorCount - 1
    } else {
        # needed for Windows 7 VM
        $msbuildCpuCount = 1
    }

    $env:OldProductVersion = $null
    $env:NewProductVersion = "2.2.0.0"
    if(!$env:BRANCH)
    {
        $env:BRANCH = "master"
    }    

    #Binaries to bundle in the installer
    #.Net
    $dotNetUri = "http://nebulous.pelco.org/artifactory/simple/ext-releases-local/com/microsoft/dotnet/4.6.1/NDP461-KB3102436-x86-x64-AllOS-ENU.exe"
    $dotNetPath = "$baseDir\Resources\dotNET\redist\NDP461-KB3102436-x86-x64-AllOS-ENU.exe"

    #OpsCenter Assemblies
    $nugetVxOpsCenterFeedURL = "http://nebulous.pelco.org/artifactory/api/nuget/vms-opscenter.app-nuget-snapshot"
    $nugetVxOpsCenterPackageURL = "http://nebulous.pelco.org/artifactory/vms-opscenter.app-nuget-snapshot/OpsCenter.UI."
    $nugetVxOpsCenterPath = "$baseDir\VxOpsCenterInstaller\Resources\OpsCenterReleaseBuild.zip"

    #VxPlayer bundle
    $nugetVxPlayerFeedURL = "http://nebulous.pelco.org/artifactory/api/nuget/vms-vxplayer.installer-nuget-snapshot/"
    $nugetVxPlayerPackageURL = "http://nebulous.pelco.org/artifactory/vms-vxplayer.installer-nuget-snapshot/VxPlayer.Installer."
    $nugetVxPlayerPath = "$baseDir\VxOpsCenterInstaller\InstallerBootstrap\VxPlayerInstallerBuild.zip"	

    #Upgrade check
    $upgradeCheckCADllUri="http://nebulous.pelco.org/artifactory/ext-releases-local/wix/UpgradeCheckCustomAction.CA/1.0.0/UpgradeCheckCustomAction.CA-1.1.0.dll"
    $upgradeCheckCADllPath="$baseDir\VxOpsCenterInstaller\Resources\UpgradeCheckCustomAction.CA-1.1.0.dll"

    #Version filter is used to filter the latest nuget package available with major version 2 and minor version 2 
    $nugetVxOpsCenterVersionFilter = "OpsCenter.UI.2.2"
    $nugetVxPlayerVersionFilter = "VxPlayer.Installer.2.2"

    #Login details
    $nugetPelcoToolsFeedUser = "vxintbuild"
    $nugetPelcoToolsFeedPass = "Dyhoahypvoc7"
    $timeoutSeconds = 1200

    #Project Paths
    $CommonViewsProjFile = "$baseDir\CommonWrapper\CommonViews\Installer.Views.Common.csproj"
    $CustomWrapperProjFile = "$baseDir\CommonWrapper\CustomWrapper\Installer.Core.csproj"
    $OCCCustomInstallerProjFile = "$baseDir\VxOpsCenterInstaller\OCCCustomInstaller\OCCCustomInstaller.csproj"
    $PhoenixCustomActionsProjFile = "$baseDir\VxOpsCenterInstaller\PhoenixCustomActions\PhoenixCustomActions.csproj"
    $PhoenixInstallerProjFile = "$baseDir\VxOpsCenterInstaller\PhoenixInstaller\PhoenixInstaller.wixproj"
    $InstallerBootstrapProjFile = "$baseDir\VxOpsCenterInstaller\InstallerBootstrap\InstallerBootstrap.wixproj"

    #Assembly Info
    $AssemblyFileVersionPattern = '(AssemblyFileVersion\()"(\d{1,6}).(\d{1,6}).(\d{1,6}).(\d{1,6})'
    $AssemblyVersionPattern = '(AssemblyVersion\()"(\d{1,6}).(\d{1,6}).(\d{1,6}).(\d{1,6})'

}

# include utility functions
include ".\..\util.ps1"

task Default -depends DebugBuild

task InstallDependencies {
    echo Installing Dependencies
    $packageConfigFiles = @(get-childitem . -include packages.config -recurse)
    Write-Host loop through each package configuration file and install 
    foreach($packageConfig in $packageConfigFiles)
    {
        $nugetArgs = "install", "-output", "$nugetPackageDir", "-configfile", "$nugetConfigPath", "$packageConfig"
        exec-and-wait -target $nugetPath -arguments $nugetArgs 
    }
    #Download-File $dotNetUri $dotNetPath
    Write-Host $GlobalAssembyInfo
    $env:OldProductVersion = Get-ProductVersion $GlobalAssembyInfo
    Write-Host "Detected previous ProductVersion: " $env:OldProductVersion -foregroundcolor "Yellow"

    $baseVersion = "$majorVersion.$minorVersion.$patchVersion"
    $buildNumber = GetBuildNumber $componentName $baseVersion $env:BRANCH
    Write-Host "Build Number : "$buildNumber -foregroundcolor "Yellow"
    Update-GlobalAssemblyInfo $patchVersion $buildNumber $GlobalAssembyInfo

    #Update-GlobalAssemblyInfo $env:SVN_REVISION $env:BUILD_NUMBER $GlobalAssembyInfo
    $env:NewProductVersion = Get-ProductVersion $GlobalAssembyInfo
    Write-Host "Updating to ProductVersion to: " $env:NewProductVersion -foregroundcolor "Green"  

    $nugetVxOpsCenterPackage = exec-and-wait-and-getoutput -target $nugetPath -outputPath $baseDir -arguments "list", $nugetVxOpsCenterVersionFilter, "-Source", "$nugetVxOpsCenterFeedURL", "-NonInteractive"	
    Write-Host "VxOpsCenter Nuget package found - $nugetVxOpsCenterPackage"
    $version = Replace-Substring $nugetVxOpsCenterPackage "OpsCenter.UI " ""
    $env:nugetVxOpsCenterPackageURL = $nugetVxOpsCenterPackageURL + $version + ".nupkg"
    Write-Host "VxOpsCenter Nuget package URL - $env:nugetVxOpsCenterPackageURL" 

    $nugetVxPlayerPackage = exec-and-wait-and-getoutput -target $nugetPath -outputPath $baseDir -arguments "list", $nugetVxPlayerVersionFilter, "-Source", "$nugetVxPlayerFeedURL", "-NonInteractive"	
    Write-Host "VxPlayer Nuget package found - $nugetVxPlayerPackage"
    $version = Replace-Substring $nugetVxPlayerPackage "VxPlayer.Installer " ""
    $env:nugetVxPlayerPackageURL = $nugetVxPlayerPackageURL + $version + ".nupkg"
    Write-Host "VxPlayer Nuget package URL - $env:nugetVxPlayerPackageURL"

}

#Task to download .Net package 
task InstallReleaseDependencies -depends InstallDependencies {
    # Get .Net
    Download-File $dotNetUri $dotNetPath
    #Get VxOpsCenter nuget Package
    Download-File "$env:nugetVxOpsCenterPackageURL" "$nugetVxOpsCenterPath"
    #Get VxPlayer nuget Package
    Download-File "$env:nugetVxPlayerPackageURL" "$nugetVxPlayerPath"
    # Get upgradeCheckCADll
    Download-File $upgradeCheckCADllUri $upgradeCheckCADllPath
    #Extracting NuGet package
    Extract-Files "$baseDir\VxOpsCenterInstaller\Resources\OpsCenterReleaseBuild.zip" "$baseDir\VxOpsCenterInstaller\Resources\OpsCenterReleaseBuild"
    Extract-Files "$baseDir\VxOpsCenterInstaller\InstallerBootstrap\VxPlayerInstallerBuild.zip" "$baseDir\VxOpsCenterInstaller\InstallerBootstrap\VxPlayerInstallerBuild"
}

#Task to clean Packages
task Clean {
    run-msbuild -solution $CommonViewsProjFile -target Clean -configuration Debug -platform $platform
    run-msbuild -solution $CommonViewsProjFile -target Clean -configuration Release -platform $platform
    run-msbuild -solution $CustomWrapperProjFile -target Clean -configuration Debug -platform $platform
    run-msbuild -solution $CustomWrapperProjFile -target Clean -configuration Release -platform $platform
    run-msbuild -solution $OCCCustomInstallerProjFile -target Clean -configuration Debug -platform $platform
    run-msbuild -solution $OCCCustomInstallerProjFile -target Clean -configuration Release -platform $platform
    run-msbuild -solution $PhoenixCustomActionsProjFile -target Clean -configuration Debug -platform $platform
    run-msbuild -solution $PhoenixCustomActionsProjFile -target Clean -configuration Release -platform $platform
    run-msbuild -solution $PhoenixInstallerProjFile -target Clean -configuration Debug -platform $platform
    run-msbuild -solution $PhoenixInstallerProjFile -target Clean -configuration Release -platform $platform
    run-msbuild -solution $InstallerBootstrapProjFile -target Clean -configuration Debug -platform $platform
    run-msbuild -solution $InstallerBootstrapProjFile -target Clean -configuration Release -platform $platform
    #clean first then remove packages...installer needs Wix package to run
    write-host "Removing NuGet packages"
    remove-item -force -recurse "$nugetPackageDir"
}

#Task build common views and wrapper components 
task ReleaseBuildCommonComponent -depends InstallReleaseDependencies {
    # Build configuration release
    $script:config = "Release"
    #run-msbuild -solution $CommonViewsProjFile -target Build -configuration $script:config -platform $platform -productVersion $env:NewProductVersion -signOutput true
    run-msbuild -solution $CustomWrapperProjFile -target Build -configuration $script:config -platform $platform -productVersion $env:NewProductVersion -signOutput true
}

task DebugBuildCommonComponent -depends InstallReleaseDependencies {
    # Build configuration debug
    $script:config = "Debug"
    #run-msbuild -solution $CommonViewsProjFile -target Build -configuration $script:config -platform $platform -productVersion $env:NewProductVersion -signOutput true
    run-msbuild -solution $CustomWrapperProjFile -target Build -configuration $script:config -platform $platform -productVersion $env:NewProductVersion -signOutput true
}

#Task build installer project which includes msi, customInstaller and bootstrapper 
task ReleaseBuild -depends ReleaseBuildCommonComponent {
    # Build configuration release
    $script:config = "Release"
    #Extracting OpsCenter UI
    Extract-Files "$baseDir\VxOpsCenterInstaller\Resources\OpsCenterReleaseBuild\OpsCenterReleaseBuild.zip" "$baseDir\VxOpsCenterInstaller\Resources\OpsCenterUI"
    run-msbuild -solution $InstallerBootstrapProjFile -target Build -configuration $script:config -platform $platform -productVersion $env:NewProductVersion -signOutput true -solutiondir $baseDir\
}

task DebugBuild -depends DebugBuildCommonComponent {
    # Build configuration debug
    $script:config = "Debug"
    #Extracting OpsCenter UI
    Extract-Files "$baseDir\VxOpsCenterInstaller\Resources\OpsCenterReleaseBuild\OpsCenterReleaseBuild.zip" "$baseDir\VxOpsCenterInstaller\Resources\OpsCenterUI"
    run-msbuild -solution $InstallerBootstrapProjFile -target Build -configuration $script:config -platform $platform -productVersion $env:NewProductVersion -signOutput true -solutiondir $baseDir\
}