﻿/**
 * Copyright (c) 2017 Pelco. All rights reserved.
 *
 * This file contains trade secrets of Pelco. No part may be reproduced or
 * transmitted in any form by any means or for any purpose without the express
 * written permission of Pelco.
 */

#region NameSpaces

using System;
using System.IO;
using Microsoft.Deployment.WindowsInstaller;
using Microsoft.Win32;
using Installer.Core.Helper;

#endregion

namespace PhoenixCustomActions
{
    /// <summary>
    /// Methods in this class are entry points for the installer. They must be public static, 
    /// return an ActionResult and be marked as [CustomAction]
    /// </summary>
    public class CustomActions
    {
        #region Private Strings

        private static string commonDataDirPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), @"Pelco\OpsCenter");
        private static string plugins64RegKeyPath = @"Software\Pelco\OpsCenter";
        private static string plugins32RegKeyPath = @"Software\Wow6432Node\Pelco\OpsCenter";
        private static string pluginsDir = "Plugins";
        private static string logsFolder = "Logs";
        private static string sourcePath = @"C:\ProgramData\Pelco\OpsCenter";
        private static string destinationPath = @"C:\ProgramData\Pelco\VxOpsCenter";
        private static string commonDataDir = "backup";
        private static string tombstoneLogsFolder = "TombstoneLogs";
        private static string commonDataRegValueName = "InstallDir";

        #endregion

        #region Custom Actions

        /// <summary>
        /// Restore the files from OpsCenter to VxOpsCenter on upgrade 
        /// if the OpsCenter directory exists.
        /// </summary>
        [CustomAction]
        public static ActionResult RestoreConfigFile(Session session)
        {
            try
            {
                session.Log("Copy configuration.xml to VxOpsCenter Directory.");
                DirectoryInfo dirSource = new DirectoryInfo(sourcePath);
                DirectoryInfo dirTarget = new DirectoryInfo(destinationPath);
                DirectoryInfo dirBackup = new DirectoryInfo(Path.Combine(sourcePath, commonDataDir));

                if (Directory.Exists(sourcePath) && Directory.Exists(destinationPath))
                {
                    var dirHelper = new DirectoryHelper();
                    dirHelper.DeleteBackupDirectory(sourcePath, commonDataDir, dirBackup, dirSource);
                    dirHelper.DeleteLogDirectory(Path.Combine(sourcePath, logsFolder));
                    dirHelper.RestoreFiles(dirSource, dirTarget);
                    dirHelper.DeleteDirectory(sourcePath);
                }
                session.Log("End Copying file.");
            }
            catch (Exception ex)
            {
                session.Log("ERROR in custom action CopyConfigFile {0}", ex.ToString());
                return ActionResult.Failure;
            }
            return ActionResult.Success;
        }

        /// <summary>
        /// Removes all folders and files in the ProgramData\Pelco\OpsCenter directory
        /// except Plugins, Backup and Logs.
        /// </summary>
        [CustomAction]
        public static ActionResult CleanUpCommonData(Session session)
        {
            try
            {
                session.Log("Begin Clean Up Directory.");

                new DirectoryHelper().CleanUpDirectoryWithExemptions(commonDataDirPath, pluginsDir, commonDataDir, logsFolder, tombstoneLogsFolder);

                session.Log("End Clean Up Directory.");
            }
            catch (Exception ex)
            {
                session.Log("ERROR in custom action CleanUpDirectory {0}", ex.ToString());
                return ActionResult.Failure;
            }
            return ActionResult.Success;
        }

        /// <summary>
        /// Creates the Plugins Directory and InstallDir Registry keys 
        /// if they do not exist.
        /// </summary>
        [CustomAction]
        public static ActionResult CreatePluginsDir(Session session)
        {
            try
            {
                session.Log("Begin Create Plugins Dir Custom Action");

                // Create the Directory.
                String commonPluginDirPath = Path.Combine(commonDataDirPath, pluginsDir);
                new DirectoryHelper().CreateFolders(commonPluginDirPath);
                // Create the 64 Bit Registry Key.
                RegistryHelper.SetValue(RegistryHive.LocalMachine, plugins64RegKeyPath, commonDataRegValueName, commonDataDirPath);
                // Create the 32 Bit Registry Key.
                RegistryHelper.SetValue(RegistryHive.LocalMachine, plugins32RegKeyPath, commonDataRegValueName, commonDataDirPath);

                session.Log("End Create Plugins Dir Custom Action");
            }
            catch (Exception ex)
            {
                session.Log("ERROR in custom action CreatePluginsDir {0}", ex.ToString());
                return ActionResult.Failure;
            }
            return ActionResult.Success;
        }

        #endregion
    }
}