package com.melco.sample;

import android.os.RemoteException;
import android.util.Log;

import com.melco.sampleinterface.IUserOption;

public class UserOptionImpl extends IUserOption.Stub {
    @Override
    public int userOperation(int option) throws RemoteException {
        Log.i("SERVICE_TEST", "userOperation");
        return 5;
    }
}
