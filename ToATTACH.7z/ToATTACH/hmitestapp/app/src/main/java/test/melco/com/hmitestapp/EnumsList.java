package test.melco.com.hmitestapp;

public class EnumsList {
    public enum UserOperation {
        CREATE,
        SWITCH,
        DELETE
    }
}
