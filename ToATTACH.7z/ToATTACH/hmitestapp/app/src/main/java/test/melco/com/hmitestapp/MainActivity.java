package test.melco.com.hmitestapp;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.melco.sampleinterface.IUserOption;

public class MainActivity extends AppCompatActivity {

    protected IUserOption mUserOption = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("SERVICE_TEST", "onCreate");
        bindmyservice();
    }

    @Override
    protected void onStart() {
        super.onStart();

    }

    private ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.i("SERVICE_TEST", "onServiceConnected");
            mUserOption = IUserOption.Stub.asInterface(service);
            Toast.makeText(getApplicationContext(), "Service Connected", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mUserOption = null;
            Log.i("SERVICE_TEST", "onServiceDisconnected");
            Toast.makeText(getApplicationContext(), "Service Disconnected", Toast.LENGTH_SHORT).show();
        }
    };

    private void bindmyservice() {
        Intent i = new Intent();
        i.setComponent(new ComponentName("com.melco.sample", "com.melco.sample.SampleService"));
        boolean status = bindService(i, connection, Context.BIND_AUTO_CREATE);
        Log.i("SERVICE_TEST", "statua" + status);
    }

    public void onClickedCreate(View view) {
        Log.i("SERVICE_TEST", "onClickedCreate ");
        int result = 0;
        try {
            result = mUserOption.userOperation(0);
        } catch (RemoteException e) {
            Log.i("SERVICE_TEST", "RemoteException" + e.getMessage());
            e.printStackTrace();
        } catch (Exception e){
            Log.i("SERVICE_TEST", "Exception" + e.getMessage());
        }
        Log.i("SERVICE_TEST", "onClickedCreate result" + result);
    }
}
